"""Filter class test"""

import unittest


class TestFilter(unittest.TestCase):
    """ Filter test"""

    def test_threads(self):
        pass

    def test_check(self):
        pass
    def test_sheme(self):
        pass

    def test_port(self):
        pass

    def test_debug(self):
        pass

    def test_delay(self):
        pass


if __name__ == "__main__":
    unittest.main()
