"""Controller class test"""

import unittest


class TestController(unittest.TestCase):
    """ Controller test"""

    @unittest.skip("update_action")
    def test_update_action(self):
        pass

    @unittest.skip("update_action")
    def test_version_action(self):
        pass

    @unittest.skip("url_action")
    def test_url_action(self):
        pass

    @unittest.skip("examples_action")
    def test_examples_action(self):
        pass


if __name__ == "__main__":
    unittest.main()
