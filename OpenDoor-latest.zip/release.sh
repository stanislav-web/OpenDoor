#!/usr/bin/env bash

if [ -z "${BASH_VERSION:-}" ] || (command -v shopt >/dev/null 2>&1 && shopt -oq posix); then
  echo "[ERROR] release.sh requires bash." >&2
  echo "[ERROR] Run: bash release.sh <version>" >&2
  exit 2
fi

set -euo pipefail

# OpenDoor release pipeline.
#
# Usage:
#   bash release.sh 5.15.1
#   bash release.sh v5.15.1
#   POST_MERGE_ONLY=1 bash release.sh 5.15.1
#
# Default flow:
#   1. preflight guards and early exits
#   2. create/reuse release/vX.Y.Z branch
#   3. run Ruff lint + unit tests + coverage + documentation build + local e2e checks
#   4. build package + validate artifacts
#   5. push release branch
#   6. create/reuse PR into master
#   7. wait PR checks
#   8. merge PR interactively
#   9. create tag from merged master only
#   10. create GitHub Release
#   11. watch publish/build workflows
#
# Recovery flow:
#   POST_MERGE_ONLY=1 creates the missing tag/release from merged master
#   after a PR was merged manually outside this script.
#
# Common overrides:
#   COVERAGE_MIN=99 bash release.sh 5.15.1
#   AUTO_YES=1 bash release.sh 5.15.1
#   AUTO_MERGE_PR=0 bash release.sh 5.15.1
#   WATCH_WORKFLOWS="publish-pypi.yml,docker-image.yml" bash release.sh 5.15.1
#   SKIP_WORKFLOW_WATCH=1 bash release.sh 5.15.1
#   ALLOW_RE_RELEASE=1 bash release.sh 5.15.1
#   SKIP_E2E_CHECKS=1 bash release.sh 5.15.1
#   SKIP_DOCS_CHECKS=1 bash release.sh 5.15.1
#   ADMIN_MERGE_AFTER_CHECKS=1 bash release.sh 5.15.1
#   E2E_DIR=.github/e2e bash release.sh 5.15.1
#   E2E_HOST=127.0.0.1 E2E_PORT=8088 bash release.sh 5.15.1
#   RELEASE_NOTES_DRY_RUN=1 bash release.sh 5.15.1
#   RELEASE_NOTES_OUTPUT=/tmp/release-notes.md RELEASE_NOTES_DRY_RUN=1 bash release.sh 5.15.1
#   RELEASE_NOTES_PREVIEW=0 bash release.sh 5.15.1

VERSION_INPUT="${1:-}"

COVERAGE_MIN="${COVERAGE_MIN:-99}"
AUTO_YES="${AUTO_YES:-0}"

RELEASE_BASE_BRANCH="${RELEASE_BASE_BRANCH:-master}"
RELEASE_BRANCH_PREFIX="${RELEASE_BRANCH_PREFIX:-release}"
RELEASE_BRANCH_DELETE_AFTER_MERGE="${RELEASE_BRANCH_DELETE_AFTER_MERGE:-1}"

AUTO_MERGE_PR="${AUTO_MERGE_PR:-1}"
WAIT_PR_CHECKS="${WAIT_PR_CHECKS:-1}"
REQUIRE_PR_CHECKS_ONLY="${REQUIRE_PR_CHECKS_ONLY:-0}"
MERGE_METHOD="${MERGE_METHOD:-squash}"
ADMIN_MERGE_AFTER_CHECKS="${ADMIN_MERGE_AFTER_CHECKS:-0}"

WATCH_WORKFLOWS="${WATCH_WORKFLOWS:-publish-pypi.yml,docker-image.yml}"
WATCH_TIMEOUT_SEC="${WATCH_TIMEOUT_SEC:-900}"
WATCH_INTERVAL_SEC="${WATCH_INTERVAL_SEC:-15}"
SKIP_WORKFLOW_WATCH="${SKIP_WORKFLOW_WATCH:-0}"

CHANGELOG_FILE="${CHANGELOG_FILE:-CHANGELOG.md}"
RELEASE_NOTES_PREVIEW="${RELEASE_NOTES_PREVIEW:-1}"
RELEASE_NOTES_DRY_RUN="${RELEASE_NOTES_DRY_RUN:-0}"
RELEASE_NOTES_OUTPUT="${RELEASE_NOTES_OUTPUT:-}"
E2E_DIR="${E2E_DIR:-.github/e2e}"
E2E_HOST="${E2E_HOST:-127.0.0.1}"
E2E_PORT="${E2E_PORT:-8088}"
E2E_REPORTS_DIR="${E2E_REPORTS_DIR:-reports}"
E2E_SERVER_WAIT_SEC="${E2E_SERVER_WAIT_SEC:-15}"
E2E_SCAN_TIMEOUT_SEC="${E2E_SCAN_TIMEOUT_SEC:-45}"
E2E_REQUEST_TIMEOUT="${E2E_REQUEST_TIMEOUT:-2}"
E2E_RETRIES="${E2E_RETRIES:-0}"
E2E_KILL_STALE_SERVER="${E2E_KILL_STALE_SERVER:-0}"
E2E_WORDLIST="${E2E_WORDLIST:-}"

EARLY_EXIT_IF_RELEASED="${EARLY_EXIT_IF_RELEASED:-1}"
ALLOW_RE_RELEASE="${ALLOW_RE_RELEASE:-0}"
SKIP_LOCAL_CHECKS="${SKIP_LOCAL_CHECKS:-0}"
SKIP_DOCS_CHECKS="${SKIP_DOCS_CHECKS:-0}"
SKIP_E2E_CHECKS="${SKIP_E2E_CHECKS:-0}"
POST_MERGE_ONLY="${POST_MERGE_ONLY:-0}"
POST_MERGE_RECOVERY="${POST_MERGE_RECOVERY:-1}"

if [[ -z "${VERSION_INPUT}" ]]; then
  echo "Usage: $0 <version>"
  echo "Example: $0 5.15.1"
  exit 1
fi

VERSION="${VERSION_INPUT#v}"
TAG="v${VERSION}"
RELEASE_BRANCH="${RELEASE_BRANCH_PREFIX}/${TAG}"

START_TS="$(date +%s)"
STEP_START_TS="${START_TS}"
PR_NUMBER=""
PR_URL=""
RELEASE_URL=""
PR_CHECKS_WATCHED_OK="0"
E2E_HTTP_SERVER_PID=""
E2E_HTTP_TEMP_DIR=""
RELEASE_NOTES_TEMP_FILES=()

info() {
  echo "[INFO] $*"
}

warn() {
  echo "[WARN] $*"
}

error() {
  echo "[ERROR] $*" >&2
}

cleanup_e2e_http_fixture() {
  if [[ -n "${E2E_HTTP_SERVER_PID:-}" ]]; then
    kill "${E2E_HTTP_SERVER_PID}" >/dev/null 2>&1 || true
    wait "${E2E_HTTP_SERVER_PID}" >/dev/null 2>&1 || true
    E2E_HTTP_SERVER_PID=""
  fi

  if [[ -n "${E2E_HTTP_TEMP_DIR:-}" && -d "${E2E_HTTP_TEMP_DIR}" ]]; then
    rm -rf "${E2E_HTTP_TEMP_DIR}"
    E2E_HTTP_TEMP_DIR=""
  fi
}

cleanup_release_notes_files() {
  local file

  for file in "${RELEASE_NOTES_TEMP_FILES[@]}"; do
    if [[ -n "${file}" && -f "${file}" ]]; then
      rm -f "${file}"
    fi
  done

  RELEASE_NOTES_TEMP_FILES=()
}

cleanup_runtime() {
  cleanup_e2e_http_fixture
  cleanup_release_notes_files
}

trap cleanup_runtime EXIT
trap 'cleanup_runtime; exit 130' INT TERM

section() {
  echo
  echo "========================================"
  echo "$*"
  echo "========================================"
}

elapsed() {
  local from="${1}"
  local now
  now="$(date +%s)"
  echo "$((now - from))s"
}

start_step() {
  STEP_START_TS="$(date +%s)"
  info "$*"
}

finish_step() {
  info "Completed in $(elapsed "${STEP_START_TS}")"
}

have_tty() {
  [[ -r /dev/tty ]]
}

confirm() {
  local prompt="${1}"
  local answer=""

  if [[ "${AUTO_YES}" == "1" ]]; then
    info "${prompt} -> auto-yes enabled"
    return 0
  fi

  if have_tty; then
    read -r -p "${prompt} [Y/n]: " answer < /dev/tty || true
  else
    warn "No interactive TTY available. Aborting instead of continuing automatically."
    warn "Use AUTO_YES=1 only when you intentionally want non-interactive mode."
    exit 1
  fi

  case "${answer:-}" in
    ""|y|Y|yes|YES)
      return 0
      ;;
    n|N|no|NO)
      echo "Aborted by user."
      exit 1
      ;;
    *)
      warn "Unrecognized answer '${answer}'. Aborting for safety."
      exit 1
      ;;
  esac
}

require_cmd() {
  local cmd="${1}"

  if ! command -v "${cmd}" >/dev/null 2>&1; then
    error "${cmd} is required"
    exit 1
  fi
}

require_python_modules() {
  SKIP_DOCS_CHECKS="${SKIP_DOCS_CHECKS}" python - <<'PY'
import importlib.util
import os
import sys

required = ["coverage", "build", "twine", "ruff"]

if os.environ.get("SKIP_DOCS_CHECKS", "0") != "1":
    required.append("mkdocs")

missing = [name for name in required if importlib.util.find_spec(name) is None]

if missing:
    print("Missing Python modules: " + ", ".join(missing), file=sys.stderr)
    print("Install runtime release dependencies: python -m pip install -r requirements-dev.txt", file=sys.stderr)
    if "mkdocs" in missing:
        print("Install documentation dependencies: python -m pip install -r docs/requirements.txt", file=sys.stderr)
    raise SystemExit(1)
PY
}

current_branch() {
  git rev-parse --abbrev-ref HEAD
}

current_commit() {
  git rev-parse --short HEAD
}

current_full_commit() {
  git rev-parse HEAD
}

remote_tag_exists() {
  git ls-remote --tags origin "refs/tags/${TAG}" | grep -q "refs/tags/${TAG}$"
}

remote_branch_exists() {
  git ls-remote --heads origin "${RELEASE_BRANCH}" | grep -q "refs/heads/${RELEASE_BRANCH}$"
}

local_tag_exists() {
  git rev-parse "${TAG}" >/dev/null 2>&1
}

github_release_exists() {
  gh release view "${TAG}" >/dev/null 2>&1
}

release_url() {
  gh release view "${TAG}" --json url --jq '.url' 2>/dev/null || true
}

commits_ahead_count() {
  local base_ref="${1}"
  local head_ref="${2}"

  git rev-list --count "${base_ref}..${head_ref}"
}

trim() {
  xargs
}

project_version_from_ref() {
  local ref="${1}"

  git show "${ref}:VERSION" 2>/dev/null | head -n 1 | tr -d '[:space:]' || true
}

project_version_from_worktree() {
  if [[ ! -f VERSION ]]; then
    error "VERSION file not found"
    exit 1
  fi

  head -n 1 VERSION | tr -d '[:space:]'
}

ensure_project_version_matches() {
  local project_version

  project_version="$(project_version_from_worktree)"

  if [[ "${project_version}" != "${VERSION}" ]]; then
    error "VERSION mismatch. Expected ${VERSION}, got ${project_version}."
    error "Refusing to tag/release the wrong commit."
    exit 1
  fi
}

can_run_post_merge_recovery() {
  local base_version

  if remote_tag_exists || github_release_exists; then
    return 1
  fi

  base_version="$(project_version_from_ref "origin/${RELEASE_BASE_BRANCH}")"

  [[ "${base_version}" == "${VERSION}" ]]
}

print_dist_artifacts() {
  if [[ ! -d dist ]]; then
    warn "dist directory not found"
    return 0
  fi

  info "Built artifacts:"
  ls -lh dist/* 2>/dev/null | awk '{print "  " $9 " (" $5 ")"}' || true
}

print_recent_workflows() {
  local workflow

  if [[ -z "${WATCH_WORKFLOWS}" ]]; then
    return 0
  fi

  echo
  info "Recent workflow runs:"

  IFS=',' read -r -a workflows <<< "${WATCH_WORKFLOWS}"

  for workflow in "${workflows[@]}"; do
    workflow="$(echo "${workflow}" | trim)"
    [[ -z "${workflow}" ]] && continue

    echo
    echo "Workflow: ${workflow}"
    gh run list --workflow "${workflow}" --limit 5 || true
  done
}

print_existing_release_status() {
  local url

  section "Existing release status"

  if remote_tag_exists; then
    info "Remote tag exists: ${TAG}"
    git ls-remote --tags origin "refs/tags/${TAG}" || true
  else
    warn "Remote tag does not exist: ${TAG}"
  fi

  if github_release_exists; then
    url="$(release_url)"
    info "GitHub Release exists: ${url:-${TAG}}"
  else
    warn "GitHub Release does not exist: ${TAG}"
  fi

  print_recent_workflows
}

ensure_clean_worktree() {
  if [[ -n "$(git status --porcelain)" ]]; then
    error "Working tree has uncommitted changes or untracked files. Commit or remove them before release."
    git status --short
    exit 1
  fi
}

ensure_changelog() {
  if [[ ! -f "${CHANGELOG_FILE}" ]]; then
    if [[ -f "CHANGELOG" ]]; then
      CHANGELOG_FILE="CHANGELOG"
    else
      error "CHANGELOG.md or CHANGELOG not found"
      exit 1
    fi
  fi
}

build_release_notes_file() {
  local output_file="${1}"

  python - "${CHANGELOG_FILE}" "${TAG}" "${output_file}" <<'PY'
from pathlib import Path
import re
import sys

changelog_path = Path(sys.argv[1])
tag = sys.argv[2]
output_path = Path(sys.argv[3])

version_header_re = re.compile(rf"^{re.escape(tag)}(?:\s|\(|$)")
next_version_header_re = re.compile(
    r"^v\d+\.\d+\.\d+(?:[.-][0-9A-Za-z]+)?(?:\s|\(|$)"
)
underline_re = re.compile(r"^-{3,}$")

lines = changelog_path.read_text(encoding="utf-8").splitlines()
started = False
skip_underline = False
release_lines: list[str] = []

for raw_line in lines:
    line = raw_line.rstrip()
    stripped = line.strip()
    normalized_header = re.sub(r"^#{1,6}\s+", "", stripped)

    if not started:
        if version_header_re.match(normalized_header):
            started = True
            skip_underline = True
        continue

    if next_version_header_re.match(normalized_header):
        break

    if skip_underline and underline_re.fullmatch(stripped):
        skip_underline = False
        continue

    skip_underline = False
    release_lines.append(line)

while release_lines and not release_lines[0].strip():
    release_lines.pop(0)

while release_lines and not release_lines[-1].strip():
    release_lines.pop()

if not started:
    print(
        f"Release notes section for {tag} was not found in {changelog_path}",
        file=sys.stderr,
    )
    raise SystemExit(1)

content_lines = [line for line in release_lines if line.strip()]
if not content_lines:
    print(
        f"Release notes section for {tag} is empty in {changelog_path}",
        file=sys.stderr,
    )
    raise SystemExit(1)

output_path.write_text("\n".join(release_lines) + "\n", encoding="utf-8")
PY
}

validate_release_notes_file() {
  local notes_file="${1}"
  local first_line

  if [[ ! -s "${notes_file}" ]]; then
    error "Generated release notes file is empty: ${notes_file}"
    exit 1
  fi

  if grep -Eq '^CHANGELOG\s*$' "${notes_file}"; then
    error "Generated release notes unexpectedly contain the top-level CHANGELOG heading."
    error "Refusing to publish the full changelog as release notes."
    exit 1
  fi

  if grep -Eq '^(#{1,6}[[:space:]]*)?v[0-9]+\.[0-9]+\.[0-9]+([.-][0-9A-Za-z]+)?([[:space:]]|\(|$)' "${notes_file}"; then
    error "Generated release notes contain another version header."
    error "Refusing to publish more than the current changelog section."
    exit 1
  fi
}

print_release_notes_preview() {
  local notes_file="${1}"

  if [[ "${RELEASE_NOTES_PREVIEW}" != "1" ]]; then
    warn "Release notes preview skipped by RELEASE_NOTES_PREVIEW=${RELEASE_NOTES_PREVIEW}"
    return 0
  fi

  section "GitHub Release notes preview"
  echo "Release: ${TAG}"
  echo "Source:  ${CHANGELOG_FILE}"
  echo
  cat "${notes_file}"
  section "End of GitHub Release notes preview"
}

prepare_release_notes_file() {
  local notes_file

  notes_file="$(mktemp)"
  RELEASE_NOTES_TEMP_FILES+=("${notes_file}")

  build_release_notes_file "${notes_file}"
  validate_release_notes_file "${notes_file}"

  echo "${notes_file}"
}

preview_release_notes_only() {
  local notes_file

  ensure_version_format
  ensure_changelog

  notes_file="$(prepare_release_notes_file)"
  print_release_notes_preview "${notes_file}"

  if [[ -n "${RELEASE_NOTES_OUTPUT}" ]]; then
    cp "${notes_file}" "${RELEASE_NOTES_OUTPUT}"
    info "Release notes written to ${RELEASE_NOTES_OUTPUT}"
  fi

  info "Release notes dry run completed for ${TAG}. No tag or GitHub Release was created."
  exit 0
}

ensure_version_format() {
  if [[ ! "${VERSION}" =~ ^[0-9]+\.[0-9]+\.[0-9]+([.-][0-9A-Za-z]+)?$ ]]; then
    error "Invalid version '${VERSION_INPUT}'. Expected something like 5.15.1 or v5.15.1."
    exit 1
  fi
}

preflight() {
  start_step "[0/15] Preflight guards"

  require_cmd git
  require_cmd python
  require_cmd gh

  if [[ ! -d .git ]]; then
    error "current directory is not a git repository"
    exit 1
  fi

  ensure_version_format
  ensure_changelog
  ensure_clean_worktree

  if [[ "${POST_MERGE_ONLY}" != "1" && "${SKIP_LOCAL_CHECKS}" != "1" ]]; then
    require_python_modules
  fi

  gh auth status >/dev/null

  git fetch origin --tags

  if [[ "${ALLOW_RE_RELEASE}" != "1" ]]; then
    if remote_tag_exists || github_release_exists; then
      print_existing_release_status

      if [[ "${EARLY_EXIT_IF_RELEASED}" == "1" ]]; then
        warn "Release ${TAG} already exists. Nothing to do."
        warn "Use ALLOW_RE_RELEASE=1 only if you intentionally want to rerun local checks/build."
        exit 0
      fi

      error "Release ${TAG} already exists. Refusing to continue."
      exit 1
    fi
  else
    warn "ALLOW_RE_RELEASE=1, skipping already-released guard."
  fi

  if [[ "$(current_branch)" != "${RELEASE_BASE_BRANCH}" && "$(current_branch)" != "${RELEASE_BRANCH}" ]]; then
    error "Current branch must be '${RELEASE_BASE_BRANCH}' or '${RELEASE_BRANCH}'. Current: $(current_branch)"
    error "Switch to '${RELEASE_BASE_BRANCH}', commit your changes, then run: bash release.sh ${VERSION}"
    exit 1
  fi

  finish_step
}

sync_base_branch() {
  start_step "[1/15] Sync base branch"

  if [[ "$(current_branch)" != "${RELEASE_BASE_BRANCH}" ]]; then
    info "Switching to ${RELEASE_BASE_BRANCH}"
    git checkout "${RELEASE_BASE_BRANCH}"
  fi

  if ! git pull --ff-only origin "${RELEASE_BASE_BRANCH}"; then
    error "Cannot fast-forward ${RELEASE_BASE_BRANCH} from origin/${RELEASE_BASE_BRANCH}."
    error "Resolve divergence manually, usually with: git fetch origin && git rebase origin/${RELEASE_BASE_BRANCH}"
    exit 1
  fi

  finish_step
}

ensure_commits_to_release() {
  local count

  count="$(commits_ahead_count "origin/${RELEASE_BASE_BRANCH}" "HEAD")"

  if [[ "${count}" == "0" ]]; then
    section "Nothing to release"
    warn "No commits between origin/${RELEASE_BASE_BRANCH} and current HEAD."
    warn "This usually means the version is already merged/released, or you started from a clean base branch."

    echo
    info "Current branch: $(current_branch)"
    info "Current commit: $(current_commit)"
    info "Base ref: origin/${RELEASE_BASE_BRANCH}"

    echo
    info "Recent commits:"
    git log --oneline --decorate -5 || true

    echo
    info "Diff check:"
    git log --oneline --decorate "origin/${RELEASE_BASE_BRANCH}..HEAD" || true

    if [[ "${POST_MERGE_RECOVERY}" == "1" ]] && can_run_post_merge_recovery; then
      echo
      warn "${RELEASE_BASE_BRANCH} already contains VERSION=${VERSION}, but ${TAG} is not released yet."
      confirm "Run post-merge recovery and create tag/release from ${RELEASE_BASE_BRANCH}?"
      post_merge_recovery_flow
    fi

    exit 0
  fi

  info "Commits to release: ${count}"
}

create_or_reuse_release_branch() {
  start_step "[2/15] Create or reuse release branch"

  if remote_branch_exists; then
    warn "Remote release branch already exists: origin/${RELEASE_BRANCH}"

    if git show-ref --verify --quiet "refs/heads/${RELEASE_BRANCH}"; then
      git checkout "${RELEASE_BRANCH}"
      git pull --ff-only origin "${RELEASE_BRANCH}"
    else
      git checkout -b "${RELEASE_BRANCH}" "origin/${RELEASE_BRANCH}"
    fi

    ensure_commits_to_release
    finish_step
    return 0
  fi

  ensure_commits_to_release

  if git show-ref --verify --quiet "refs/heads/${RELEASE_BRANCH}"; then
    warn "Local branch ${RELEASE_BRANCH} already exists. Reusing it."
    git checkout "${RELEASE_BRANCH}"
  else
    git checkout -b "${RELEASE_BRANCH}"
  fi

  ensure_commits_to_release
  finish_step
}

run_documentation_check() {
  local docs_site_dir
  local docs_status

  if [[ "${SKIP_LOCAL_CHECKS}" == "1" ]]; then
    warn "Skipping documentation build by SKIP_LOCAL_CHECKS=1"
    return 0
  fi

  if [[ "${SKIP_DOCS_CHECKS}" == "1" ]]; then
    warn "Skipping documentation build by SKIP_DOCS_CHECKS=1"
    return 0
  fi

  start_step "[6/15] Build documentation"

  if [[ ! -f mkdocs.yml ]]; then
    error "mkdocs.yml not found"
    exit 1
  fi

  docs_site_dir="$(mktemp -d)"

  set +e
  python -m mkdocs build --strict --site-dir "${docs_site_dir}"
  docs_status="$?"
  set -e

  rm -rf "${docs_site_dir}"

  if [[ "${docs_status}" != "0" ]]; then
    error "Documentation build failed with exit code ${docs_status}"
    exit "${docs_status}"
  fi

  finish_step
}

run_tests_and_build() {
  if [[ "${SKIP_LOCAL_CHECKS}" == "1" ]]; then
    warn "Skipping local tests/build by SKIP_LOCAL_CHECKS=1"
    return 0
  fi

  start_step "[3/15] Run Ruff lint checks"
  python -m ruff check .
  finish_step

  echo
  start_step "[4/15] Run unit tests with coverage"
  python -m coverage run -m unittest discover -s tests -p "test_*.py"
  finish_step

  echo
  start_step "[5/15] Enforce coverage threshold"
  python -m coverage report -m --fail-under="${COVERAGE_MIN}"
  finish_step

  echo
  run_documentation_check

  echo
  run_e2e_checks

  echo
  start_step "[8/15] Clean build artifacts"
  rm -rf dist build ./*.egg-info
  finish_step

  echo
  start_step "[9/15] Build package"
  python -m build
  print_dist_artifacts
  finish_step

  echo
  start_step "[10/15] Validate package"
  python -m twine check dist/*
  finish_step
}

find_e2e_report_validator() {
  local candidate

  for candidate in \
    "${E2E_DIR}/validate_reports.py" \
    "${E2E_DIR}/validate_report.py" \
    "${E2E_DIR}/validator.py" \
    "${E2E_DIR}/validate.py"; do
    if [[ -f "${candidate}" ]]; then
      echo "${candidate}"
      return 0
    fi
  done

  while IFS= read -r candidate; do
    if grep -Eq 'validate_json_report|EXPECTED_SUCCESS_PATHS|Validate OpenDoor GitHub Actions E2E reports' "${candidate}"; then
      echo "${candidate}"
      return 0
    fi
  done < <(find "${E2E_DIR}" -maxdepth 1 -type f ! -name '.*' -name '*.py' ! -name 'server.py' | sort)

  return 1
}

select_e2e_wordlist() {
  local candidate
  local fallback_file="${1}"

  if [[ -n "${E2E_WORDLIST}" ]]; then
    if [[ ! -f "${E2E_WORDLIST}" ]]; then
      error "Configured E2E_WORDLIST does not exist: ${E2E_WORDLIST}"
      exit 1
    fi

    echo "${E2E_WORDLIST}"
    return 0
  fi

  for candidate in \
    "${E2E_DIR}/wordlist.txt" \
    "${E2E_DIR}/directories.txt" \
    "${E2E_DIR}/paths.txt" \
    "${E2E_DIR}/e2e-wordlist.txt" \
    "${E2E_DIR}/directories.dat"; do
    if [[ -f "${candidate}" ]]; then
      echo "${candidate}"
      return 0
    fi
  done

  printf '%s\n' \
    admin \
    backup \
    health \
    uploads \
    login \
    forbidden \
    auth-required \
    redirect \
    nonexistent \
    ghost \
    random-miss \
    doesnotexist \
    > "${fallback_file}"

  echo "${fallback_file}"
}

print_e2e_port_owner() {
  local port="${1}"

  if command -v lsof >/dev/null 2>&1; then
    lsof -nP -iTCP:"${port}" -sTCP:LISTEN >&2 || true
  elif command -v ss >/dev/null 2>&1; then
    ss -ltnp "sport = :${port}" >&2 || true
  elif command -v netstat >/dev/null 2>&1; then
    netstat -anp tcp 2>/dev/null | grep "[.:]${port} .*LISTEN" >&2 || true
  fi
}

kill_e2e_port_owner_if_requested() {
  local port="${1}"
  local pids=""

  if [[ "${E2E_KILL_STALE_SERVER}" != "1" ]]; then
    return 0
  fi

  if ! command -v lsof >/dev/null 2>&1; then
    warn "E2E_KILL_STALE_SERVER=1 requested, but lsof is not available."
    return 0
  fi

  pids="$(lsof -tiTCP:"${port}" -sTCP:LISTEN 2>/dev/null || true)"
  if [[ -z "${pids}" ]]; then
    return 0
  fi

  warn "Killing stale e2e listener(s) on port ${port}: ${pids}"
  # shellcheck disable=SC2086
  kill ${pids} >/dev/null 2>&1 || true
  sleep 1
}

ensure_e2e_port_available() {
  local host="${1}"
  local port="${2}"

  kill_e2e_port_owner_if_requested "${port}"

  if python -c 'import socket, sys; socket.create_connection((sys.argv[1], int(sys.argv[2])), timeout=0.5).close()' "${host}" "${port}" >/dev/null 2>&1; then
    error "E2E port is already in use: ${host}:${port}"
    error "A stale e2e server from an interrupted release may still be running."
    print_e2e_port_owner "${port}"
    error "Stop it manually or rerun once with E2E_KILL_STALE_SERVER=1."
    exit 1
  fi
}

run_with_timeout() {
  local timeout_sec="${1}"
  local command_pid
  local deadline

  shift

  "${@}" &
  command_pid="$!"
  deadline=$(( $(date +%s) + timeout_sec ))

  while kill -0 "${command_pid}" >/dev/null 2>&1; do
    if (( $(date +%s) >= deadline )); then
      kill "${command_pid}" >/dev/null 2>&1 || true
      sleep 1
      kill -9 "${command_pid}" >/dev/null 2>&1 || true
      wait "${command_pid}" >/dev/null 2>&1 || true
      return 124
    fi

    sleep 1
  done

  wait "${command_pid}"
}

wait_for_e2e_server() {
  local host="${1}"
  local port="${2}"
  local deadline

  deadline=$(( $(date +%s) + E2E_SERVER_WAIT_SEC ))

  while (( $(date +%s) <= deadline )); do
    if python -c 'import socket, sys; socket.create_connection((sys.argv[1], int(sys.argv[2])), timeout=0.5).close()' "${host}" "${port}" >/dev/null 2>&1; then
      return 0
    fi

    sleep 0.2
  done

  return 1
}

run_e2e_http_fixture_checks() {
  local server_file="${E2E_DIR}/server.py"
  local validator_file
  local wordlist_file
  local server_log
  local scan_status=0
  local validator_status=0

  if [[ ! -f "${server_file}" ]]; then
    return 1
  fi

  if ! validator_file="$(find_e2e_report_validator)"; then
    error "E2E HTTP fixture found, but report validator was not found in ${E2E_DIR}"
    error "Expected validate_reports.py or a Python file containing validate_json_report()."
    exit 1
  fi

  ensure_e2e_port_available "${E2E_HOST}" "${E2E_PORT}"

  E2E_HTTP_TEMP_DIR="$(mktemp -d)"
  wordlist_file="$(select_e2e_wordlist "${E2E_HTTP_TEMP_DIR}/wordlist.txt")"
  server_log="${E2E_HTTP_TEMP_DIR}/server.log"

  info "Running GitHub Actions-style e2e HTTP fixture"
  info "E2E server: ${server_file}"
  info "E2E validator: ${validator_file}"
  info "E2E wordlist: ${wordlist_file}"
  info "E2E target: http://${E2E_HOST}:${E2E_PORT}"
  info "E2E request timeout: ${E2E_REQUEST_TIMEOUT}s"
  info "E2E retries: ${E2E_RETRIES}"
  info "E2E scan timeout: ${E2E_SCAN_TIMEOUT_SEC}s"

  rm -rf "${E2E_REPORTS_DIR%/}/${E2E_HOST}"

  python "${server_file}" > "${server_log}" 2>&1 &
  E2E_HTTP_SERVER_PID="$!"

  sleep 0.2
  if ! kill -0 "${E2E_HTTP_SERVER_PID}" >/dev/null 2>&1; then
    error "E2E HTTP server exited before becoming ready."
    cat "${server_log}" >&2 || true
    exit 1
  fi

  if ! wait_for_e2e_server "${E2E_HOST}" "${E2E_PORT}"; then
    error "E2E HTTP server did not become ready at ${E2E_HOST}:${E2E_PORT}"
    if [[ -f "${server_log}" ]]; then
      cat "${server_log}" >&2 || true
    fi

    cleanup_e2e_http_fixture
    exit 1
  fi

  set +e
  run_with_timeout "${E2E_SCAN_TIMEOUT_SEC}" \
    python opendoor.py \
      --host "http://${E2E_HOST}" \
      --port "${E2E_PORT}" \
      --method GET \
      --threads 1 \
      --timeout "${E2E_REQUEST_TIMEOUT}" \
      --retries "${E2E_RETRIES}" \
      --header "Connection: close" \
      --scan directories \
      --wordlist "${wordlist_file}" \
      --crawl \
      --reports json,sarif \
      --reports-dir "${E2E_REPORTS_DIR}" \
      --exclude-status 404
  scan_status="$?"

  if [[ "${scan_status}" == "0" ]]; then
    python "${validator_file}"
    validator_status="$?"
  fi
  set -e

  if [[ -f "${server_log}" ]]; then
    info "E2E server log:"
    sed 's/^/[E2E SERVER] /' "${server_log}" || true
  fi

  cleanup_e2e_http_fixture

  if [[ "${scan_status}" == "124" ]]; then
    error "OpenDoor e2e scan timed out after ${E2E_SCAN_TIMEOUT_SEC}s"
    error "This usually means the local HTTP fixture is stuck or the port is occupied by a stale server."
    error "Check listeners with: lsof -nP -iTCP:${E2E_PORT} -sTCP:LISTEN"
    exit 124
  fi

  if [[ "${scan_status}" != "0" ]]; then
    error "OpenDoor e2e scan failed with exit code ${scan_status}"
    exit "${scan_status}"
  fi

  if [[ "${validator_status}" != "0" ]]; then
    error "OpenDoor e2e report validation failed with exit code ${validator_status}"
    exit "${validator_status}"
  fi

  return 0
}

run_e2e_checks() {
  local test_file
  local runnable=0

  if [[ "${SKIP_LOCAL_CHECKS}" == "1" ]]; then
    warn "Skipping local e2e checks by SKIP_LOCAL_CHECKS=1"
    return 0
  fi

  if [[ "${SKIP_E2E_CHECKS}" == "1" ]]; then
    warn "Skipping local e2e checks by SKIP_E2E_CHECKS=1"
    return 0
  fi

  start_step "[7/15] Run local e2e checks"

  if [[ ! -d "${E2E_DIR}" ]]; then
    error "E2E directory not found: ${E2E_DIR}"
    error "Expected release-blocking e2e tests in ${E2E_DIR}"
    exit 1
  fi

  if [[ -f "${E2E_DIR}/run.sh" ]]; then
    runnable=1
    info "Running e2e runner: ${E2E_DIR}/run.sh"
    bash "${E2E_DIR}/run.sh"
  else
    while IFS= read -r test_file; do
      [[ -z "${test_file}" ]] && continue
      runnable=1
      info "Running e2e shell test: ${test_file}"
      bash "${test_file}"
    done < <(find "${E2E_DIR}" -maxdepth 1 -type f ! -name '.*' -name '*.sh' | sort)

    if [[ -n "$(find "${E2E_DIR}" -maxdepth 1 -type f ! -name '.*' -name 'test_*.py' -print -quit)" ]]; then
      runnable=1
      info "Running e2e Python unittest discovery: ${E2E_DIR}/test_*.py"
      python -m unittest discover -s "${E2E_DIR}" -p "test_*.py"
    fi

    while IFS= read -r test_file; do
      [[ -z "${test_file}" ]] && continue
      runnable=1
      info "Running e2e executable test: ${test_file}"
      "${test_file}"
    done < <(find "${E2E_DIR}" -maxdepth 1 -type f ! -name '.*' ! -name '*.sh' ! -name '*.py' -perm -111 | sort)

    if [[ "${runnable}" != "1" ]] && [[ -f "${E2E_DIR}/server.py" ]]; then
      runnable=1
      run_e2e_http_fixture_checks
    fi
  fi

  if [[ "${runnable}" != "1" ]]; then
    error "No runnable e2e tests found in ${E2E_DIR}"
    error "Expected ${E2E_DIR}/run.sh, *.sh, test_*.py, executable test files, or server.py + report validator."
    error "Helper server.py is used as a background HTTP fixture, not executed as a foreground test."
    error "Set SKIP_E2E_CHECKS=1 only for emergency recovery."
    exit 1
  fi

  finish_step
}

push_release_branch() {
  start_step "[11/15] Push release branch"

  confirm "Push release branch '${RELEASE_BRANCH}' to origin?"
  git push -u origin "${RELEASE_BRANCH}"

  finish_step
}

get_existing_pr_number() {
  gh pr list \
    --head "${RELEASE_BRANCH}" \
    --base "${RELEASE_BASE_BRANCH}" \
    --state open \
    --json number \
    --jq '.[0].number // empty'
}

create_or_get_pr() {
  local pr_number
  local pr_url

  start_step "[12/15] Create or reuse release PR"

  ensure_commits_to_release

  pr_number="$(get_existing_pr_number)"

  if [[ -n "${pr_number}" ]]; then
    warn "Open PR already exists: #${pr_number}"
  else
    confirm "Create release PR '${RELEASE_BRANCH}' -> '${RELEASE_BASE_BRANCH}'?"

    pr_url="$(
      gh pr create \
        --base "${RELEASE_BASE_BRANCH}" \
        --head "${RELEASE_BRANCH}" \
        --title "Release ${TAG}" \
        --body "Release ${TAG}

Checks:
- lint: python -m ruff check .
- coverage floor: ${COVERAGE_MIN}%
- documentation build: python -m mkdocs build --strict
- package build: python -m build
- package validation: twine check
- local e2e: ${E2E_DIR}/*

Tag and GitHub Release will be created only after this PR is merged."
    )"

    info "Created PR: ${pr_url}"

    pr_number="$(
      gh pr view "${RELEASE_BRANCH}" \
        --json number \
        --jq '.number'
    )"
  fi

  PR_NUMBER="${pr_number}"
  PR_URL="$(
    gh pr view "${PR_NUMBER}" \
      --json url \
      --jq '.url'
  )"

  info "Release PR: #${PR_NUMBER}"
  info "URL: ${PR_URL}"

  finish_step
}

wait_pr_checks() {
  if [[ "${WAIT_PR_CHECKS}" != "1" ]]; then
    warn "Skipping PR checks wait by WAIT_PR_CHECKS=${WAIT_PR_CHECKS}"
    return 0
  fi

  start_step "[13/15] Watch PR checks"

  if [[ "${REQUIRE_PR_CHECKS_ONLY}" == "1" ]]; then
    gh pr checks "${PR_NUMBER}" --required --watch --fail-fast --interval "${WATCH_INTERVAL_SEC}"
  else
    gh pr checks "${PR_NUMBER}" --watch --fail-fast --interval "${WATCH_INTERVAL_SEC}"
  fi

  PR_CHECKS_WATCHED_OK="1"

  finish_step
}

run_pr_merge_command() {
  local admin_mode="${1}"
  local head_sha="${2}"
  local admin_flag=()

  shift 2

  if [[ "${admin_mode}" == "admin" ]]; then
    admin_flag=(--admin)
  fi

  case "${MERGE_METHOD}" in
    squash)
      gh pr merge "${PR_NUMBER}" --squash "$@" "${admin_flag[@]}" --match-head-commit "${head_sha}"
      ;;
    merge)
      gh pr merge "${PR_NUMBER}" --merge "$@" "${admin_flag[@]}" --match-head-commit "${head_sha}"
      ;;
    rebase)
      gh pr merge "${PR_NUMBER}" --rebase "$@" "${admin_flag[@]}" --match-head-commit "${head_sha}"
      ;;
    *)
      error "Unsupported MERGE_METHOD=${MERGE_METHOD}. Use squash, merge, or rebase."
      exit 1
      ;;
  esac
}

merge_pr() {
  local head_sha
  local delete_flag=()
  local merge_status=0
  local prompt

  if [[ "${AUTO_MERGE_PR}" != "1" ]]; then
    warn "AUTO_MERGE_PR=${AUTO_MERGE_PR}. Stop here."
    warn "Merge manually, then create tag/release from ${RELEASE_BASE_BRANCH}."
    warn "PR: ${PR_URL}"
    exit 0
  fi

  start_step "[14/15] Merge release PR"

  head_sha="$(
    gh pr view "${PR_NUMBER}" \
      --json headRefOid \
      --jq '.headRefOid'
  )"

  if [[ "${RELEASE_BRANCH_DELETE_AFTER_MERGE}" == "1" ]]; then
    delete_flag=(--delete-branch)
  fi

  prompt="Merge PR #${PR_NUMBER} with method '${MERGE_METHOD}'?"
  if [[ "${ADMIN_MERGE_AFTER_CHECKS}" == "1" ]]; then
    if [[ "${PR_CHECKS_WATCHED_OK}" != "1" ]]; then
      error "ADMIN_MERGE_AFTER_CHECKS=1 requires a successful [13/15] PR checks watch in this release run."
      error "Refusing to use administrator merge privileges without verified release checks."
      exit 1
    fi

    prompt="${prompt} Standard merge is attempted first; --admin fallback is enabled after successful checks."
  fi

  confirm "${prompt}"

  set +e
  run_pr_merge_command standard "${head_sha}" "${delete_flag[@]}"
  merge_status="$?"
  set -e

  if [[ "${merge_status}" != "0" ]]; then
    if [[ "${ADMIN_MERGE_AFTER_CHECKS}" != "1" ]]; then
      error "PR merge failed with exit code ${merge_status}."
      error "If branch protection blocks immediate admin-owned local release merges, rerun with ADMIN_MERGE_AFTER_CHECKS=1."
      exit "${merge_status}"
    fi

    warn "Standard PR merge failed after successful checks. Retrying with administrator privileges (--admin)."
    run_pr_merge_command admin "${head_sha}" "${delete_flag[@]}"
  fi

  finish_step
}

checkout_merged_base() {
  start_step "[15/15] Checkout merged base branch"

  git fetch origin --tags
  git checkout "${RELEASE_BASE_BRANCH}"

  if ! git pull --ff-only origin "${RELEASE_BASE_BRANCH}"; then
    error "Cannot fast-forward ${RELEASE_BASE_BRANCH} after merge."
    exit 1
  fi

  info "Release commit on ${RELEASE_BASE_BRANCH}: $(current_commit)"

  finish_step
}

create_tag_and_release() {
  local url
  local release_notes_file

  start_step "[post-merge] Create tag and GitHub Release"

  git fetch origin --tags
  ensure_project_version_matches

  if remote_tag_exists; then
    error "Remote tag ${TAG} already exists after merge. Refusing to continue."
    exit 1
  fi

  if github_release_exists; then
    error "GitHub Release ${TAG} already exists after merge. Refusing to continue."
    exit 1
  fi

  if local_tag_exists; then
    warn "Local tag ${TAG} exists. Recreating it at merged ${RELEASE_BASE_BRANCH} HEAD."
    confirm "Delete and recreate local tag '${TAG}'?"
    git tag -d "${TAG}"
  fi

  confirm "Create and push tag '${TAG}' at $(current_commit)?"
  git tag -a "${TAG}" -m "${TAG}"
  git push origin "refs/tags/${TAG}"

  release_notes_file="$(prepare_release_notes_file)"
  print_release_notes_preview "${release_notes_file}"

  confirm "Publish these release notes to GitHub Release '${TAG}'?"
  gh release create "${TAG}"     --target "${RELEASE_BASE_BRANCH}"     --title "${TAG}"     --notes-file "${release_notes_file}"

  url="$(release_url)"
  if [[ -n "${url}" ]]; then
    info "GitHub release: ${url}"
  fi

  RELEASE_URL="${url}"

  finish_step
}

post_merge_recovery_flow() {
  section "Post-merge release recovery"

  warn "This mode assumes the release PR was already merged into ${RELEASE_BASE_BRANCH}."
  warn "It will create the missing tag and GitHub Release from the current ${RELEASE_BASE_BRANCH} HEAD."

  sync_base_branch
  create_tag_and_release
  watch_workflows
  cleanup_release_branch_if_leftover
  print_summary
  exit 0
}

latest_run_value() {
  local workflow="${1}"
  local jq_expr="${2}"

  gh run list \
    --workflow "${workflow}" \
    --branch "${TAG}" \
    --limit 1 \
    --json databaseId,status,conclusion,displayTitle,event,headBranch,createdAt,url \
    --jq "${jq_expr}" 2>/dev/null || true
}

watch_workflow() {
  local workflow="${1}"
  local deadline
  local run_id
  local status
  local conclusion
  local url
  local title
  local event
  local branch

  deadline=$(( $(date +%s) + WATCH_TIMEOUT_SEC ))

  info "Watching workflow: ${workflow}"

  while true; do
    run_id="$(latest_run_value "${workflow}" '.[0].databaseId // ""')"

    if [[ -n "${run_id}" ]]; then
      status="$(latest_run_value "${workflow}" '.[0].status // ""')"
      conclusion="$(latest_run_value "${workflow}" '.[0].conclusion // ""')"
      url="$(latest_run_value "${workflow}" '.[0].url // ""')"
      title="$(latest_run_value "${workflow}" '.[0].displayTitle // ""')"
      event="$(latest_run_value "${workflow}" '.[0].event // ""')"
      branch="$(latest_run_value "${workflow}" '.[0].headBranch // ""')"

      info "  run=${run_id} status=${status:-unknown} conclusion=${conclusion:-pending} event=${event:-unknown} branch=${branch:-unknown}"
      info "  title=${title:-unknown}"
      info "  url=${url:-unknown}"

      case "${status}" in
        completed)
          case "${conclusion}" in
            success)
              info "Workflow ${workflow} completed successfully."
              return 0
              ;;
            failure|cancelled|timed_out|action_required)
              error "Workflow ${workflow} completed with conclusion=${conclusion}"
              return 1
              ;;
            *)
              error "Workflow ${workflow} completed with conclusion=${conclusion:-unknown}"
              return 1
              ;;
          esac
          ;;
      esac
    else
      warn "No run found yet for workflow=${workflow} branch/tag=${TAG}"
    fi

    if (( $(date +%s) >= deadline )); then
      error "Timed out waiting for workflow ${workflow}"
      return 1
    fi

    sleep "${WATCH_INTERVAL_SEC}"
  done
}

watch_workflows() {
  local workflow
  local failed=0

  if [[ "${SKIP_WORKFLOW_WATCH}" == "1" ]]; then
    warn "Workflow watch skipped by SKIP_WORKFLOW_WATCH=1"
    return 0
  fi

  if [[ -z "${WATCH_WORKFLOWS}" ]]; then
    warn "No workflows configured for watching."
    return 0
  fi

  section "GitHub workflow status"

  IFS=',' read -r -a workflows <<< "${WATCH_WORKFLOWS}"

  for workflow in "${workflows[@]}"; do
    workflow="$(echo "${workflow}" | trim)"
    [[ -z "${workflow}" ]] && continue

    if ! watch_workflow "${workflow}"; then
      failed=1
    fi

    echo
  done

  print_recent_workflows

  if [[ "${failed}" == "1" ]]; then
    error "One or more watched workflows failed."
    exit 1
  fi
}

cleanup_release_branch_if_leftover() {
  if [[ "$(current_branch)" == "${RELEASE_BRANCH}" ]]; then
    warn "You are still on ${RELEASE_BRANCH}. Switching back to ${RELEASE_BASE_BRANCH}."
    git checkout "${RELEASE_BASE_BRANCH}" || true
  fi
}

print_summary() {
  section "Release summary"
  echo "Version:         ${VERSION}"
  echo "Tag:             ${TAG}"
  echo "Base branch:     ${RELEASE_BASE_BRANCH}"
  echo "Commit:          $(current_commit)"
  echo "PR:              ${PR_URL:-unknown}"
  echo "Release URL:     ${RELEASE_URL:-unknown}"
  echo "Total time:      $(elapsed "${START_TS}")"
  echo
  print_dist_artifacts

  echo
  info "Release flow completed for ${TAG}"
}

section "OpenDoor release pipeline"
echo "Version:             ${VERSION}"
echo "Tag:                 ${TAG}"
echo "Base branch:         ${RELEASE_BASE_BRANCH}"
echo "Release branch:      ${RELEASE_BRANCH}"
echo "Coverage floor:      ${COVERAGE_MIN}%"
echo "Changelog file:      ${CHANGELOG_FILE}"
echo "E2E dir:             ${E2E_DIR}"
echo "E2E host:            ${E2E_HOST}"
echo "E2E port:            ${E2E_PORT}"
echo "E2E reports dir:     ${E2E_REPORTS_DIR}"
echo "E2E scan timeout:   ${E2E_SCAN_TIMEOUT_SEC}s"
echo "Auto merge PR:       ${AUTO_MERGE_PR}"
echo "Merge method:        ${MERGE_METHOD}"
echo "Admin merge after checks: ${ADMIN_MERGE_AFTER_CHECKS}"
echo "Watch PR checks:     ${WAIT_PR_CHECKS}"
echo "Watch workflows:     ${WATCH_WORKFLOWS:-none}"
echo "Auto yes:            ${AUTO_YES}"
echo "Skip e2e checks:     ${SKIP_E2E_CHECKS}"
echo "Skip docs checks:    ${SKIP_DOCS_CHECKS}"
echo "Early exit released: ${EARLY_EXIT_IF_RELEASED}"
echo "Post-merge only:     ${POST_MERGE_ONLY}"
echo "Post-merge recovery: ${POST_MERGE_RECOVERY}"
echo "Release notes preview: ${RELEASE_NOTES_PREVIEW}"
echo "Release notes dry run: ${RELEASE_NOTES_DRY_RUN}"
echo "Release notes output:  ${RELEASE_NOTES_OUTPUT:-none}"
echo

if [[ "${RELEASE_NOTES_DRY_RUN}" == "1" ]]; then
  preview_release_notes_only
fi

preflight

if [[ "${POST_MERGE_ONLY}" == "1" ]]; then
  post_merge_recovery_flow
fi

sync_base_branch
create_or_reuse_release_branch
run_tests_and_build
push_release_branch
create_or_get_pr
wait_pr_checks
merge_pr
checkout_merged_base
create_tag_and_release
watch_workflows
cleanup_release_branch_if_leftover
print_summary
