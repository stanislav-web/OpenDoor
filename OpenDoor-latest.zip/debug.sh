coverage erase
coverage run -m unittest discover -s tests -p "test_*.py"
coverage report -m --precision=2 --fail-under=99
python -m ruff check .
vulture src tests --min-confidence 65