#!/bin/sh
"exec" "python3" "$0" "$@"
# -*- coding: utf-8 -*-

"""
Compare two line-based files and report candidate lines missing from reference.

This file intentionally supports two launch modes:
    python3 scripts/compare_missing.py ...
    sh scripts/compare_missing.py ...
"""

import argparse
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, NoReturn, Set


@dataclass(frozen=True)
class CompareResult:
    """
    Comparison result.

    @param missing_lines {List[str]} Lines from candidate file missing in reference file.
    @param reference_total {int} Total lines read from reference file.
    @param candidate_total {int} Total lines read from candidate file.
    @param ignored_total {int} Candidate lines ignored by skip rules.
    @param duplicate_missing_total {int} Duplicate missing candidate lines skipped from report.
    """

    missing_lines: List[str]
    reference_total: int
    candidate_total: int
    ignored_total: int
    duplicate_missing_total: int


class Colors:
    """
    Terminal colors helper.

    @param enabled {bool} Whether ANSI colors should be used.
    """

    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled

    def red(self, value: str) -> str:
        """
        Colorize text as red.

        @param value {str} Text value.
        @return {str} Colorized or original text.
        """
        return self._wrap(value, "31")

    def green(self, value: str) -> str:
        """
        Colorize text as green.

        @param value {str} Text value.
        @return {str} Colorized or original text.
        """
        return self._wrap(value, "32")

    def yellow(self, value: str) -> str:
        """
        Colorize text as yellow.

        @param value {str} Text value.
        @return {str} Colorized or original text.
        """
        return self._wrap(value, "33")

    def blue(self, value: str) -> str:
        """
        Colorize text as blue.

        @param value {str} Text value.
        @return {str} Colorized or original text.
        """
        return self._wrap(value, "34")

    def bold(self, value: str) -> str:
        """
        Make text bold.

        @param value {str} Text value.
        @return {str} Styled or original text.
        """
        return self._wrap(value, "1")

    def _wrap(self, value: str, code: str) -> str:
        """
        Wrap text into ANSI color sequence.

        @param value {str} Text value.
        @param code {str} ANSI color code.
        @return {str} Styled or original text.
        """
        if not self.enabled:
            return value

        return f"\033[{code}m{value}\033[0m"


def should_use_colors() -> bool:
    """
    Detect whether terminal colors should be enabled.

    @return {bool} True if colors should be used.
    """
    if "--no-color" in sys.argv:
        return False

    if os.getenv("NO_COLOR"):
        return False

    return sys.stdout.isatty() or sys.stderr.isatty()


COLORS = Colors(should_use_colors())


class UserFriendlyArgumentParser(argparse.ArgumentParser):
    """
    Argument parser with user-friendly colored errors.
    """

    def error(self, message: str) -> NoReturn:
        """
        Print friendly CLI error and exit.

        @param message {str} Error message.
        @return {NoReturn} Never returns.
        """
        print("", file=sys.stderr)
        print(COLORS.red("❌ CLI error"), file=sys.stderr)
        print(COLORS.red(f"   {message}"), file=sys.stderr)
        print("", file=sys.stderr)
        print(COLORS.bold("Usage:"), file=sys.stderr)
        print("   python3 scripts/compare_missing.py <reference_file> <candidate_file>", file=sys.stderr)
        print("", file=sys.stderr)
        print(COLORS.bold("Example:"), file=sys.stderr)
        print("   python3 scripts/compare_missing.py ./data/directories.dat ./scripts/list.txt", file=sys.stderr)
        print("", file=sys.stderr)
        print(COLORS.bold("Meaning:"), file=sys.stderr)
        print("   reference_file = base file where lines should already exist", file=sys.stderr)
        print("   candidate_file = file that will be checked", file=sys.stderr)
        print("", file=sys.stderr)
        print("Run with --help to see full documentation.", file=sys.stderr)

        raise SystemExit(2)


def print_error(message: str) -> None:
    """
    Print colored error message.

    @param message {str} Error message.
    @return {None} Nothing.
    """
    print(COLORS.red(f"❌ {message}"), file=sys.stderr)


def print_warning(message: str) -> None:
    """
    Print colored warning message.

    @param message {str} Warning message.
    @return {None} Nothing.
    """
    print(COLORS.yellow(f"⚠️  {message}"))


def print_success(message: str) -> None:
    """
    Print colored success message.

    @param message {str} Success message.
    @return {None} Nothing.
    """
    print(COLORS.green(f"✅ {message}"))


def print_info(label: str, value: object) -> None:
    """
    Print colored info line.

    @param label {str} Info label.
    @param value {object} Info value.
    @return {None} Nothing.
    """
    print(f"{COLORS.blue(label.ljust(30))} {value}")


def read_lines(file_path: Path) -> List[str]:
    """
    Read file lines preserving order and removing only line break characters.

    @param file_path {Path} Path to the input file.
    @return {List[str]} File lines without trailing newline characters.
    """
    with file_path.open("r", encoding="utf-8") as file:
        return [line.rstrip("\r\n") for line in file]


def remove_bom(line: str) -> str:
    """
    Remove UTF-8 BOM from a line if present.

    @param line {str} Original line.
    @return {str} Line without BOM.
    """
    return line.replace("\ufeff", "")


IGNORED_SUBSTRINGS = (
    "%ext%",
    "{ext}",
    "%s",
    ".php?",
    "$",
    "%",
    "^",
    "&",
    "!",
    "@",
    "+",
    "#",
    "\"",
)

IGNORED_FILE_EXTENSIONS = (
    ".brf",
    ".php5",
    ".tpl",
    ".inc",
    ".raw",
    ".jpg",
    ".js",
    ".lst",
    ".vts",
    ".afp",
    ".cgi",
    ".cfm",
    ".asp",
    ".htc",
    ".dos",
    ".opt",
    ".htw",
    ".wmf",
    ".mid",
    ".swf",
    ".fr",
    ".en",
    ".java",
    ".class",
    ".war",
    ".ear",
    ".net",
    ".com",
    ".org",
    ".edu",
    ".gov",
    ".mil",
    ".html",
    ".shtml",
    ".ca",
    ".rt",
    ".doc",
    ".docx",
    ".htr",
    ".pl",
    ".wav",
    ".nsf",
    ".mdb",
    ".xsql",
    ".pack",
    ".asa",
    ".printer",
    ".GIF",
    ".fmx",
    ".xsd",
    ".ps",
    ".NT",
    ".as",
    ".xsl",
    ".5as",
    ".41x",
    ".pkg",
    ".ru",
    ".ser",
    ".lasso",
    ".i",
    ".so",
    ".gif",
    ".tif",
    ".c",
    ".aas",
    ".tsk",
    ".lproj",
    ".dll",
    ".e",
    ".z",
)

def should_ignore_candidate_line(line: str) -> bool:
    """
    Check whether a candidate file line should be ignored.

    Ignore rules:
    - contains ignored technical substrings
    - contains ignored file extensions as substrings
    - consists only of digits
    - starts with a digit and ends with a digit
    - ends with any digit

    Numeric checks are applied after lightweight normalization:
    - remove UTF-8 BOM
    - trim surrounding whitespace
    - remove leading/trailing "/" characters

    @param line {str} Original line from the candidate file.
    @return {bool} True if the line should be ignored.
    """
    normalized_line = remove_bom(line).strip()
    normalized_lower_line = normalized_line.lower()

    if any(pattern in normalized_lower_line for pattern in IGNORED_SUBSTRINGS):
        return True

    if any(extension in normalized_lower_line for extension in IGNORED_FILE_EXTENSIONS):
        return True

    normalized_numeric_line = normalized_line.strip("/").strip()

    if not normalized_numeric_line:
        return False

    if normalized_numeric_line.isdigit():
        return True

    if normalized_numeric_line[0].isdigit() and normalized_numeric_line[-1].isdigit():
        return True

    return normalized_numeric_line[-1].isdigit()

def normalize_candidate_line(line: str) -> str:
    """
    Normalize candidate file line for comparison and report.

    Rules:
    - remove UTF-8 BOM
    - remove leading "/" characters
    - remove trailing "/" characters
    - preserve internal "/" characters

    @param line {str} Original line from the candidate file.
    @return {str} Normalized candidate line.
    """
    return remove_bom(line).strip("/")


def build_compare_key(line: str) -> str:
    """
    Build normalized comparison key.

    Rules:
    - remove UTF-8 BOM
    - trim surrounding whitespace

    @param line {str} Original or normalized line.
    @return {str} Comparison key.
    """
    return remove_bom(line).strip()


def validate_input_file(file_path: Path, label: str) -> bool:
    """
    Validate input file path.

    @param file_path {Path} File path.
    @param label {str} User-facing file label.
    @return {bool} True when file is valid.
    """
    if not file_path.exists():
        print_error(f"{label} does not exist: {file_path}")
        return False

    if not file_path.is_file():
        print_error(f"{label} is not a file: {file_path}")
        return False

    try:
        with file_path.open("r", encoding="utf-8"):
            pass
    except PermissionError:
        print_error(f"{label} is not readable. Permission denied: {file_path}")
        return False
    except UnicodeDecodeError:
        print_error(f"{label} is not valid UTF-8 text file: {file_path}")
        return False
    except OSError as error:
        print_error(f"{label} cannot be opened: {file_path}")
        print_error(str(error))
        return False

    return True


def validate_output_path(output_path: Path) -> bool:
    """
    Validate output report path.

    @param output_path {Path} Output report path.
    @return {bool} True when output path is valid.
    """
    if output_path.exists() and output_path.is_dir():
        print_error(f"Output path points to a directory, expected file path: {output_path}")
        return False

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        print_error(f"Cannot create output directory. Permission denied: {output_path.parent}")
        return False
    except OSError as error:
        print_error(f"Cannot create output directory: {output_path.parent}")
        print_error(str(error))
        return False

    return True


def compare_files(reference_file: Path, candidate_file: Path) -> CompareResult:
    """
    Find lines that exist in the candidate file but do not exist in the reference file.

    @param reference_file {Path} File where lines are expected to already exist.
    @param candidate_file {Path} File whose lines should be checked.
    @return {CompareResult} Comparison result.
    """
    reference_lines = read_lines(reference_file)
    candidate_lines = read_lines(candidate_file)

    reference_compare_keys: Set[str] = {
        build_compare_key(line)
        for line in reference_lines
    }

    missing_lines: List[str] = []
    seen_missing_compare_keys: Set[str] = set()

    ignored_total = 0
    duplicate_missing_total = 0

    for raw_line in candidate_lines:
        if should_ignore_candidate_line(raw_line):
            ignored_total += 1
            continue

        normalized_line = normalize_candidate_line(raw_line)
        compare_key = build_compare_key(normalized_line)

        if compare_key in reference_compare_keys:
            continue

        if compare_key in seen_missing_compare_keys:
            duplicate_missing_total += 1
            continue

        missing_lines.append(normalized_line)
        seen_missing_compare_keys.add(compare_key)

    return CompareResult(
        missing_lines=missing_lines,
        reference_total=len(reference_lines),
        candidate_total=len(candidate_lines),
        ignored_total=ignored_total,
        duplicate_missing_total=duplicate_missing_total,
    )


def write_report(report_path: Path, missing_lines: List[str]) -> bool:
    """
    Write missing lines to report file.

    @param report_path {Path} Path to output report file.
    @param missing_lines {List[str]} Missing lines to write.
    @return {bool} True when report was written.
    """
    try:
        report_path.parent.mkdir(parents=True, exist_ok=True)

        with report_path.open("w", encoding="utf-8") as file:
            if missing_lines:
                file.write("\n".join(missing_lines))
                file.write("\n")

        return True
    except PermissionError:
        print_error(f"Cannot write report. Permission denied: {report_path}")
        return False
    except OSError as error:
        print_error(f"Cannot write report: {report_path}")
        print_error(str(error))
        return False


def build_parser() -> argparse.ArgumentParser:
    """
    Build CLI argument parser.

    @return {argparse.ArgumentParser} Configured argument parser.
    """
    parser = UserFriendlyArgumentParser(
        prog="compare_missing.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=(
            "Find lines that are present in candidate_file "
            "but missing in reference_file."
        ),
        epilog="""
How it works:
  1. Reads reference_file.
  2. Reads candidate_file.
  3. Checks every candidate line against the reference file.
  4. Writes missing candidate lines to the report.

Argument meaning:
  reference_file = base file / existing list / where lines should already exist
  candidate_file = new file / checked list / where missing lines are taken from

Normalization rules:
  - surrounding spaces are ignored during comparison
  - UTF-8 BOM is removed
  - candidate lines are reported without leading/trailing "/"
  - candidate lines containing %EXT%, {ext}, %ext%, %s, .php? are ignored
  - duplicate missing lines are written only once

Examples:
  python3 scripts/compare_missing.py ./data/directories.dat ./scripts/list.txt
  sh scripts/compare_missing.py ./data/directories.dat ./scripts/list.txt
  python3 scripts/compare_missing.py ./data/directories.dat ./scripts/list.txt -o reports/missing.txt
  python3 scripts/compare_missing.py ./data/directories.dat ./scripts/list.txt --show-missing
  python3 scripts/compare_missing.py ./data/directories.dat ./scripts/list.txt --dry-run
  python3 scripts/compare_missing.py ./data/directories.dat ./scripts/list.txt --fail-on-missing

Exit codes:
  0 = success
  1 = missing lines found when --fail-on-missing is used
  2 = invalid CLI arguments or validation error
""",
    )

    parser.add_argument(
        "reference_file",
        metavar="reference_file",
        type=Path,
        help="Base file where lines are expected to already exist.",
    )
    parser.add_argument(
        "candidate_file",
        metavar="candidate_file",
        type=Path,
        help="File to check. Missing lines will be taken from this file.",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("./missing.txt"),
        help="Output report path. Default: missing.txt",
    )
    parser.add_argument(
        "--show-missing",
        action="store_true",
        help="Print missing lines to terminal after comparison.",
    )
    parser.add_argument(
        "--fail-on-missing",
        action="store_true",
        help="Return exit code 1 when at least one missing line is found.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run comparison without writing report file.",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colored terminal output.",
    )

    return parser


def main() -> int:
    """
    Run CLI script.

    @return {int} Exit code.
    """
    parser = build_parser()
    args = parser.parse_args()

    if args.reference_file.resolve() == args.candidate_file.resolve():
        print_error("reference_file and candidate_file point to the same file.")
        print_warning("Use two different files: base file first, checked file second.")
        return 2

    is_valid = True
    is_valid = validate_input_file(args.reference_file, "Reference file") and is_valid
    is_valid = validate_input_file(args.candidate_file, "Candidate file") and is_valid

    if not args.dry_run:
        is_valid = validate_output_path(args.output) and is_valid

    if not is_valid:
        print("")
        print_warning("Comparison was not started because validation failed.")
        print("")
        print(COLORS.bold("Correct command example:"))
        print("   python3 scripts/compare_missing.py ./data/directories.dat ./scripts/list.txt")
        return 2

    try:
        result = compare_files(args.reference_file, args.candidate_file)
    except UnicodeDecodeError as error:
        print_error("Failed to read file as UTF-8 text.")
        print_error(str(error))
        return 2
    except OSError as error:
        print_error("Failed to read input files.")
        print_error(str(error))
        return 2

    if not args.dry_run and not write_report(args.output, result.missing_lines):
        return 2

    print("")
    print_success("Comparison finished")
    print(COLORS.bold("-------------------"))
    print_info("Reference file:", args.reference_file)
    print_info("Candidate file:", args.candidate_file)
    print_info("Reference lines loaded:", result.reference_total)
    print_info("Candidate lines checked:", result.candidate_total)
    print_info("Ignored candidate lines:", result.ignored_total)
    print_info("Duplicate missing skipped:", result.duplicate_missing_total)
    print_info("Missing lines found:", len(result.missing_lines))

    if args.dry_run:
        print_warning("Report was not written because --dry-run was used.")
    else:
        print_info("Report saved to:", args.output)

    if args.show_missing and result.missing_lines:
        print("")
        print(COLORS.bold("Missing lines"))
        print(COLORS.bold("-------------"))

        for line in result.missing_lines:
            print(line)

    if result.missing_lines:
        print("")
        print_warning("Some candidate lines are missing in the reference file.")
    else:
        print("")
        print_success("No missing lines found.")

    if args.fail_on_missing and result.missing_lines:
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())