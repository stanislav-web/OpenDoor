#!/bin/sh
"exec" "python3" "$0" "$@"
# -*- coding: utf-8 -*-

"""
Clean dictionary file:
- remove empty lines
- remove duplicate lines
- optionally sort lines
- write result to a new file
- never modify source file directly

Supported launch modes:
    python3 scripts/cleanup_dictionaries.py ...
    sh scripts/cleanup_dictionaries.py ...
    zsh scripts/cleanup_dictionaries.py ...
    /bin/zsh scripts/cleanup_dictionaries.py ...
"""

import argparse
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, NoReturn, Optional, Set, Tuple


@dataclass(frozen=True)
class CleanupResult:
    """
    Dictionary cleanup result.

    @param total_lines {int} Total input lines count.
    @param removed_duplicates {int} Removed duplicate lines count.
    @param removed_empty_lines {int} Removed empty lines count.
    @param final_unique_lines {int} Final unique non-empty lines count.
    """

    total_lines: int
    removed_duplicates: int
    removed_empty_lines: int
    final_unique_lines: int


class Colors:
    """
    Terminal colors helper.

    @param enabled {bool} Whether ANSI colors should be used.
    """

    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled

    def red(self, value: str) -> str:
        """
        Colorize text as red.

        @param value {str} Text value.
        @return {str} Colorized or original text.
        """
        return self._wrap(value, "31")

    def green(self, value: str) -> str:
        """
        Colorize text as green.

        @param value {str} Text value.
        @return {str} Colorized or original text.
        """
        return self._wrap(value, "32")

    def yellow(self, value: str) -> str:
        """
        Colorize text as yellow.

        @param value {str} Text value.
        @return {str} Colorized or original text.
        """
        return self._wrap(value, "33")

    def blue(self, value: str) -> str:
        """
        Colorize text as blue.

        @param value {str} Text value.
        @return {str} Colorized or original text.
        """
        return self._wrap(value, "34")

    def bold(self, value: str) -> str:
        """
        Make text bold.

        @param value {str} Text value.
        @return {str} Styled or original text.
        """
        return self._wrap(value, "1")

    def _wrap(self, value: str, code: str) -> str:
        """
        Wrap text into ANSI color sequence.

        @param value {str} Text value.
        @param code {str} ANSI color code.
        @return {str} Styled or original text.
        """
        if not self.enabled:
            return value

        return f"\033[{code}m{value}\033[0m"


def should_use_colors() -> bool:
    """
    Detect whether terminal colors should be enabled.

    @return {bool} True if colors should be used.
    """
    if "--no-color" in sys.argv:
        return False

    if os.getenv("NO_COLOR"):
        return False

    return sys.stdout.isatty() or sys.stderr.isatty()


COLORS = Colors(should_use_colors())


class UserFriendlyArgumentParser(argparse.ArgumentParser):
    """
    Argument parser with user-friendly colored errors.
    """

    def error(self, message: str) -> NoReturn:
        """
        Print friendly CLI error and exit.

        @param message {str} Error message.
        @return {NoReturn} Never returns.
        """
        print("", file=sys.stderr)
        print(COLORS.red("❌ CLI error"), file=sys.stderr)
        print(COLORS.red(f"   {message}"), file=sys.stderr)
        print("", file=sys.stderr)
        print(COLORS.bold("Usage:"), file=sys.stderr)
        print("   python3 scripts/cleanup_dictionaries.py <input_file>", file=sys.stderr)
        print("   python3 scripts/cleanup_dictionaries.py <input_file> -o <output_file>", file=sys.stderr)
        print("", file=sys.stderr)
        print(COLORS.bold("Example:"), file=sys.stderr)
        print("   python3 scripts/cleanup_dictionaries.py ./data/directories.dat", file=sys.stderr)
        print("", file=sys.stderr)
        print("Run with --help to see full documentation.", file=sys.stderr)

        raise SystemExit(2)


def print_error(message: str) -> None:
    """
    Print colored error message.

    @param message {str} Error message.
    @return {None} Nothing.
    """
    print(COLORS.red(f"❌ {message}"), file=sys.stderr)


def print_warning(message: str) -> None:
    """
    Print colored warning message.

    @param message {str} Warning message.
    @return {None} Nothing.
    """
    print(COLORS.yellow(f"⚠️  {message}"))


def print_success(message: str) -> None:
    """
    Print colored success message.

    @param message {str} Success message.
    @return {None} Nothing.
    """
    print(COLORS.green(f"✅ {message}"))


def print_info(label: str, value: object) -> None:
    """
    Print colored info line.

    @param label {str} Info label.
    @param value {object} Info value.
    @return {None} Nothing.
    """
    print(f"{COLORS.blue(label.ljust(30))} {value}")


def build_parser() -> argparse.ArgumentParser:
    """
    Build CLI argument parser.

    @return {argparse.ArgumentParser} Configured argument parser.
    """
    parser = UserFriendlyArgumentParser(
        prog="cleanup_dictionaries.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=(
            "Clean dictionary file: remove empty lines, remove duplicate lines, "
            "sort result, and write to a new file."
        ),
        epilog="""
How it works:
  1. Reads input_file line by line.
  2. Removes empty lines.
  3. Removes duplicate lines.
  4. Sorts result if --sort natural is used.
  5. Writes cleaned content to output file.

Important:
  The source file is never modified directly.

Default output:
  ./data/directories.dat -> ./data/directories_deduplicated.dat

Sorting modes:
  none     = keep first occurrence order
  natural  = sort alphabetically with numeric chunks as numbers

Natural sort examples:
  1, 2, 10
  file1, file2, file10

Examples:
  python3 scripts/cleanup_dictionaries.py ./data/directories.dat
  sh scripts/cleanup_dictionaries.py ./data/directories.dat
  zsh scripts/cleanup_dictionaries.py ./data/directories.dat
  /bin/zsh scripts/cleanup_dictionaries.py ./data/directories.dat

  python3 scripts/cleanup_dictionaries.py ./data/directories.dat -o ./data/directories_clean.dat
  python3 scripts/cleanup_dictionaries.py ./data/directories.dat --sort none
  python3 scripts/cleanup_dictionaries.py ./data/directories.dat --sort natural
  python3 scripts/cleanup_dictionaries.py ./data/directories.dat --dry-run

Exit codes:
  0 = success
  2 = invalid CLI arguments or validation error
""",
    )

    parser.add_argument(
        "input_file",
        metavar="input_file",
        type=Path,
        help="Path to the dictionary file that should be cleaned.",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        help=(
            "Path to output file. "
            "Default: <input_file_stem>_deduplicated<input_file_suffix>"
        ),
    )
    parser.add_argument(
        "--sort",
        choices=("none", "natural"),
        default="natural",
        help="Sorting mode for output lines. Default: natural",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run cleanup and show statistics without writing output file.",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colored terminal output.",
    )

    return parser


def build_default_output_path(input_file: Path) -> Path:
    """
    Build default output path for the cleaned file.

    Example:
    - data/list.txt -> data/list_deduplicated.txt
    - data/list -> data/list_deduplicated

    @param input_file {Path} Source file path.
    @return {Path} Default output file path.
    """
    return input_file.with_name(f"{input_file.stem}_deduplicated{input_file.suffix}")


def natural_sort_key(line: str) -> List[object]:
    """
    Build a natural sort key for a line.

    Numeric chunks are converted to integers, text chunks are compared
    case-insensitively.

    @param line {str} Input line.
    @return {List[object]} Natural sort key.
    """
    normalized_line = line.rstrip("\r\n")
    parts = re.split(r"(\d+)", normalized_line)

    return [
        int(part) if part.isdigit() else part.lower()
        for part in parts
    ]


def sort_lines(lines: List[str], sort_mode: str) -> List[str]:
    """
    Sort lines according to the requested sorting mode.

    @param lines {List[str]} Input lines.
    @param sort_mode {str} Sorting mode.
    @return {List[str]} Sorted lines.
    """
    if sort_mode == "none":
        return lines

    return sorted(lines, key=natural_sort_key)


def is_empty_line(line: str) -> bool:
    """
    Check whether a line is empty or contains only whitespace.

    @param line {str} Input line.
    @return {bool} True if the line is empty.
    """
    return line.strip() == ""


def validate_input_file(input_file: Path) -> bool:
    """
    Validate input file path.

    @param input_file {Path} Input file path.
    @return {bool} True when input file is valid.
    """
    if not input_file.exists():
        print_error(f"Input file does not exist: {input_file}")
        return False

    if not input_file.is_file():
        print_error(f"Input path is not a file: {input_file}")
        return False

    try:
        with input_file.open("r", encoding="utf-8"):
            pass
    except PermissionError:
        print_error(f"Input file is not readable. Permission denied: {input_file}")
        return False
    except UnicodeDecodeError:
        print_error(f"Input file is not valid UTF-8 text file: {input_file}")
        return False
    except OSError as error:
        print_error(f"Input file cannot be opened: {input_file}")
        print_error(str(error))
        return False

    return True


def validate_output_file(input_file: Path, output_file: Path, dry_run: bool) -> bool:
    """
    Validate output file path.

    @param input_file {Path} Input file path.
    @param output_file {Path} Output file path.
    @param dry_run {bool} Whether dry-run mode is enabled.
    @return {bool} True when output path is valid.
    """
    if input_file.resolve() == output_file.resolve():
        print_error("Output file must be different from input file.")
        print_warning("The script never modifies source file directly.")
        return False

    if dry_run:
        return True

    if output_file.exists() and output_file.is_dir():
        print_error(f"Output path points to a directory, expected file path: {output_file}")
        return False

    try:
        output_file.parent.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        print_error(f"Cannot create output directory. Permission denied: {output_file.parent}")
        return False
    except OSError as error:
        print_error(f"Cannot create output directory: {output_file.parent}")
        print_error(str(error))
        return False

    return True


def collect_unique_lines(input_file: Path) -> Tuple[int, int, int, int, List[str]]:
    """
    Read input file and collect unique non-empty lines.

    Rules:
    - empty lines are skipped
    - duplicate lines are removed
    - first occurrence order is preserved before optional sorting
    - duplicate comparison is exact by full line content

    @param input_file {Path} Source file path.
    @return {Tuple[int, int, int, int, List[str]]} Tuple of:
        - total input lines
        - removed duplicate lines
        - removed empty lines
        - total unique non-empty lines
        - unique non-empty lines list
    """
    seen_lines: Set[str] = set()
    unique_lines: List[str] = []
    total_lines = 0
    removed_duplicates = 0
    removed_empty_lines = 0

    with input_file.open("r", encoding="utf-8") as source:
        for line in source:
            total_lines += 1

            if is_empty_line(line):
                removed_empty_lines += 1
                continue

            if line in seen_lines:
                removed_duplicates += 1
                continue

            seen_lines.add(line)
            unique_lines.append(line)

    return (
        total_lines,
        removed_duplicates,
        removed_empty_lines,
        len(unique_lines),
        unique_lines,
    )


def write_lines(output_file: Path, lines: List[str]) -> bool:
    """
    Write lines to output file.

    @param output_file {Path} Destination file path.
    @param lines {List[str]} Lines to write.
    @return {bool} True when output file was written.
    """
    try:
        output_file.parent.mkdir(parents=True, exist_ok=True)

        with output_file.open("w", encoding="utf-8") as destination:
            destination.writelines(lines)

        return True
    except PermissionError:
        print_error(f"Cannot write output file. Permission denied: {output_file}")
        return False
    except OSError as error:
        print_error(f"Cannot write output file: {output_file}")
        print_error(str(error))
        return False


def cleanup_dictionary(input_file: Path, output_file: Optional[Path], sort_mode: str, dry_run: bool) -> int:
    """
    Run dictionary cleanup.

    @param input_file {Path} Input dictionary file.
    @param output_file {Optional[Path]} Output file path.
    @param sort_mode {str} Sorting mode.
    @param dry_run {bool} Whether dry-run mode is enabled.
    @return {int} Exit code.
    """
    resolved_output_file = output_file or build_default_output_path(input_file)

    is_valid = True
    is_valid = validate_input_file(input_file) and is_valid
    is_valid = validate_output_file(input_file, resolved_output_file, dry_run) and is_valid

    if not is_valid:
        print("")
        print_warning("Cleanup was not started because validation failed.")
        print("")
        print(COLORS.bold("Correct command example:"))
        print("   python3 scripts/cleanup_dictionaries.py ./data/directories.dat")
        return 2

    try:
        (
            total_lines,
            removed_duplicates,
            removed_empty_lines,
            unique_count,
            unique_lines,
        ) = collect_unique_lines(input_file)
    except UnicodeDecodeError as error:
        print_error("Failed to read input file as UTF-8 text.")
        print_error(str(error))
        return 2
    except OSError as error:
        print_error("Failed to read input file.")
        print_error(str(error))
        return 2

    sorted_lines = sort_lines(
        lines=unique_lines,
        sort_mode=sort_mode,
    )

    if not dry_run and not write_lines(resolved_output_file, sorted_lines):
        return 2

    print("")
    print_success("Dictionary cleanup finished")
    print(COLORS.bold("---------------------------"))
    print_info("Input file:", input_file)
    print_info("Output file:", resolved_output_file if not dry_run else "not written because --dry-run was used")
    print_info("Sort mode:", sort_mode)
    print_info("Initial lines:", total_lines)
    print_info("Removed duplicate lines:", removed_duplicates)
    print_info("Removed empty lines:", removed_empty_lines)
    print_info("Final unique non-empty lines:", unique_count)

    if removed_duplicates > 0 or removed_empty_lines > 0:
        print("")
        print_warning("Dictionary was changed in the output file.")
    else:
        print("")
        print_success("No duplicates or empty lines found.")

    return 0


def main() -> int:
    """
    Run CLI script.

    @return {int} Exit code.
    """
    parser = build_parser()
    args = parser.parse_args()

    return cleanup_dictionary(
        input_file=args.input_file,
        output_file=args.output,
        sort_mode=args.sort,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    raise SystemExit(main())