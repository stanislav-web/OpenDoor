# OpenDoor Roadmap

Status date: 2026-06-13
Current baseline: OpenDoor `5.17.0`
Next planned release: OpenDoor `5.18.0`

## Purpose

This roadmap tracks only incomplete work planned after the current `5.17.0` baseline.

Completed capabilities are intentionally omitted from active roadmap scope. Completed work belongs in `CHANGELOG.md`, release notes, documentation, and tests.

The priority model remains **architecture compatibility first**, then user-visible security value. Features should be ordered by how cleanly they compose with existing scanner, sniffer, report, session, transport, and packaging contracts.

Traffic-flow tooling ideas, including ideas inspired by mitmproxy, may be used only as architectural patterns for OpenDoor. They must not turn OpenDoor into an intercepting proxy, MITM proxy, request editor, repeater, or traffic modification tool. Useful ideas should be adapted as internal flow objects, passive analysis hooks, offline import/export workflows, decoding helpers, and request identity policies.

---

## Current release boundary

`5.18.0` should be the next minor release.

Current `5.18.0` target:

```text
TLS context foundation + mTLS/client certificate support
```

The goal is to centralize target TLS context construction and add opt-in mutual TLS support without changing default HTTPS behavior.

Do not start broader transport observability, VHost mode, browser identity profiles, MCP, XML import/export, HTTP/2, async engine, or bypass expansion until the TLS context contract is explicit and covered by deterministic tests.

---

## SemVer policy

### Patch releases: `5.x.y`

Patch releases are reserved for:

- bug fixes;
- security fixes that do not add new public behavior;
- documentation corrections;
- deterministic tests;
- packaging/build fixes;
- internal refactors with no public CLI, storage, scan-mode, or output-contract change;
- additive bounded metadata for existing report items when existing fields, buckets, filenames, formats, detection semantics, and request volume are preserved;
- performance fixes that preserve behavior and output contracts.

Patch releases must not introduce:

- new CLI flags;
- new `--sniff` values;
- new report buckets;
- new required/top-level report fields intended as a new integration contract;
- new report formats;
- new scan modes;
- new target import modes;
- new integration modes;
- changed default scan behavior.

### Minor releases: `5.18.0`, `5.19.0`, ...

Minor releases are required for backward-compatible public features, including:

- new CLI flags;
- new `--sniff` values;
- new opt-in scan behavior;
- new passive or active sniffer capabilities;
- new documented report schema surfaces intended as integration contracts;
- new report buckets;
- new output formats;
- new target import formats;
- new offline report tools;
- new optional integrations such as MCP;
- new transport capabilities such as mTLS when backward-compatible and opt-in.

### Major releases: `6.0.0`

Major releases are required for incompatible changes, including:

- removing, renaming, or changing public CLI flags;
- changing default scan behavior in a way that materially changes request volume, scheduling, or output;
- incompatible JSON/SQLite/XML report schema changes;
- storage migrations that old tools cannot read safely;
- changing existing finding meaning or severity semantics incompatibly;
- replacing the request engine or transport model if observable behavior changes;
- making optional dependencies mandatory for existing use cases.

---

## Architecture compatibility path

Use this order when deciding what to build next:

1. **Transport authentication before transport observability**: mTLS/client-cert support must exist before safe transport metadata reports client-certificate mode.
2. **TLS context before VHost**: Host/SNI separation must wait until target TLS context and SNI semantics are explicit and tested.
3. **Request identity after header validation**: browser profiles depend on stable custom-header normalization and override behavior.
4. **WAF/CDN certainty after transport foundation**: passive WAF/CDN provider attribution should build on the existing WAF runtime classifier and later transport metadata, using explainable certainty labels without changing request volume, blocked-response semantics, WAF guard behavior, or bypass behavior.
5. **HTTP metrics before resource-risk sniffing**: response timing, body-size and baseline latency metadata should exist before adding load-risk heuristics.
6. **Report metadata before bounded active sniffers**: URL patterns and stable structured metadata should come before sniffers that add contextual report metadata or limited follow-up validation.
7. **Bounded sniffers before offline tooling**: response/probe sniffers such as EAR and passive resource-risk sniffers should have stable evidence metadata before report query, report rescan, merge, and MCP expose the data.
8. **Offline tools before MCP**: report query/rescan/merge should exist before MCP exposes them as structured tools.
9. **VHost after TLS/SNI foundation**: VHost mode depends on clear connect target, HTTP Host header and SNI handling.
10. **Bypass expansion last**: bypass variants, OAST callback checks, raw HTTP work, callback providers and intrusive payload work are higher-risk and should follow lower-risk passive/report/transport foundations.

---

## Prioritized implementation waves

| Wave | Release target | Theme | Architecture role | SemVer class | Risk |
|---:|---|---|---|---|---|
| P1 | `5.18.0` | TLS context foundation + mTLS | Centralize target TLS context before transport observation and VHost work | Minor | Medium |
| P2 | `5.19.0` | Request identity profiles | Browser profiles, anti-cache policy, and cookie-policy ergonomics | Minor | Low/medium |
| P3 | `5.20.0` | Transport observability + WAF/CDN certainty | TLS/HTTP metadata and passive WAF/CDN certainty normalization after TLS context semantics are clear | Minor | Medium |
| P4 | `5.21.0` | URL pattern metadata | Stable report metadata before bounded active sniffers and query/merge/MCP tooling | Minor | Low/medium |
| P5 | `5.22.0` | Bounded EAR sniffer | Optional `--sniff ear` after URL/report metadata, using passive analysis and safe GET/HEAD validation only | Minor | Medium |
| P6 | `5.23.0` | Load-risk sniffer | Optional `--sniff loadrisk` after HTTP metrics and URL/report metadata, using passive latency and response-evidence heuristics only | Minor | Medium |
| P7 | `5.24.0` | Report query/rescan/merge | Offline report tooling and passive re-analysis | Minor | Medium |
| P8 | `5.25.0` | MCP stdio | Expose approved local scan, report query, rescan, diff and merge workflows after offline contracts exist | Minor | Medium |
| P9 | `5.26.0` | XML + target import/export | XML reports, Nmap XML, HAR/mitmproxy import/export | Minor | Low/medium |
| P10 | `5.27.0` | VHost mode | Host/SNI separation after TLS/SNI/report metadata mature | Minor | Medium |
| P11 | `5.28.0+` | Bypass expansion | Controlled bypass architecture after lower-risk foundations | Minor | Medium/high |
| P12 | `6.0.0 candidate` | Raw HTTP bypass engine | Wire-level control; major-candidate unless fully isolated | Major candidate | High |
| Later | `5.x minor` | JSONL logs, passive recon, replay integrations, PostgreSQL sink, additional wordlist-source extensions, OAST provider abstraction | Broader observability/import/callback workflows | Minor unless breaking | Medium |
| Experimental | `5.x experimental` / `6.0.0 candidate` | HTTP/2, async engine, Swarm Mode, OpenTelemetry | Engine/transport research | Minor if isolated, major if behavior-changing | High |

Recommended next implementation: **`5.18.0` = TLS context foundation + mTLS/client certificate support**.

Why this should go next:

- it is a clean architecture foundation for later transport observability and VHost mode;
- it composes with existing direct HTTPS, HTTP CONNECT proxy, SOCKS and `--tls-legacy` paths;
- it is security-relevant for authorized internal scans;
- it is lower risk than VHost, bypass expansion, raw HTTP, MCP, async engine or HTTP/2 work;
- it avoids adding another request-volume feature in the next release.

---

# 1. `5.18.0` — TLS context foundation and mTLS/client certificate support

Status: **Next accepted release scope**

## 1.1 User-facing CLI

Separate certificate and key:

```bash
opendoor \
  --host https://internal.example.com \
  --client-cert ./client.crt \
  --client-key ./client.key
```

Single combined PEM:

```bash
opendoor \
  --host https://internal.example.com \
  --client-cert ./client.pem
```

Encrypted private key through environment variable reference only:

```bash
OPENDOOR_CLIENT_KEY_PASSWORD='...' opendoor \
  --host https://internal.example.com \
  --client-cert ./client.crt \
  --client-key ./client.key \
  --client-key-password-env OPENDOOR_CLIENT_KEY_PASSWORD
```

## 1.2 Scope

Accepted:

- shared TLS context factory for target HTTPS requests;
- `--client-cert`;
- `--client-key`;
- `--client-key-password-env`;
- direct HTTPS mTLS;
- HTTP CONNECT proxy HTTPS mTLS;
- SOCKS HTTPS mTLS;
- compatibility with `--tls-legacy`;
- session save/load for certificate path, key path and password environment variable name only;
- wizard/config support for the same fields if config parity is desired;
- privacy tests proving passwords, private keys and certificate contents are not persisted/logged.

Out of scope:

- TLS impersonation;
- JA3/JA4 spoofing;
- certificate generation;
- certificate pinning UI;
- MITM behavior;
- proxy interception;
- client certificate content in reports/logs/sessions;
- making mTLS mandatory for existing HTTPS scans;
- broad transport observability metadata beyond a minimal client-cert mode flag if needed internally.

## 1.3 Design rules

- Default HTTPS behavior must remain unchanged when mTLS flags are absent.
- `--tls-legacy` must remain opt-in and keep its existing weak-DH compatibility purpose.
- mTLS must use stdlib/OpenSSL/urllib3 primitives already available in the project stack.
- No new runtime dependency should be added unless stdlib and existing urllib3 cannot support the required behavior safely.
- `--client-key-password-env` stores only the environment variable name, never the resolved password value.
- Missing files, directories instead of files, unreadable cert/key paths and missing password environment variables must fail early with actionable messages.
- Debug output may say that client certificate mode is enabled, but must not print key material, certificate body, password value, or proxy credentials.
- Session snapshots may persist paths and env variable names because they are configuration, but must never persist file contents or secret values.

## 1.4 Implementation order

1. Extract a shared TLS context factory in `src/core/http/tls.py`.
2. Preserve current default HTTPS and `--tls-legacy` behavior with regression tests before adding new CLI flags.
3. Add client certificate option parsing in `src/core/options/options.py`.
4. Add input validation and normalization in `src/core/options/filter.py`.
5. Add runtime config fields in `src/lib/browser/config.py`.
6. Add privacy-safe session serialization/deserialization in `src/lib/browser/session.py` if session snapshots store runtime params there.
7. Wire the TLS context factory into direct HTTPS request provider.
8. Wire the same factory into HTTP CONNECT proxy HTTPS paths.
9. Wire the same factory into SOCKS HTTPS paths.
10. Add debug/status messages that confirm mode without exposing secrets.
11. Add README, docs and changelog updates.
12. Run full release verification gates.

## 1.5 Suggested internal API shape

Candidate helper object:

```python
@dataclass(frozen=True)
class TLSClientAuthConfig:
    client_cert: str | None = None
    client_key: str | None = None
    client_key_password_env: str | None = None
```

Candidate factory functions:

```python
def build_target_ssl_context(
    *,
    tls_legacy: bool = False,
    client_cert: str | None = None,
    client_key: str | None = None,
    client_key_password_env: str | None = None,
) -> ssl.SSLContext | None:
    ...
```

```python
def tls_pool_kwargs(ssl_context: ssl.SSLContext | None) -> dict:
    ...
```

The current `tls_pool_kwargs()` style can remain the single integration point for urllib3 pool constructors.

## 1.6 Required tests

Core TLS helper tests:

- default context factory returns current default/no custom context when all flags are absent, if that is the preserved contract;
- legacy TLS context still disables hostname verification and uses `DEFAULT:!DHE` as before;
- client certificate is loaded when `--client-cert` is provided;
- client cert/key pair is loaded when both paths are provided;
- encrypted key password is resolved from env when `--client-key-password-env` is provided;
- missing env variable fails early;
- password value is not included in exception strings, debug strings, reports, or session data.

CLI/config/session tests:

- `--client-cert` parses successfully;
- `--client-cert --client-key` parses successfully;
- `--client-key` without `--client-cert` fails validation;
- missing cert/key path fails validation;
- directory path fails validation;
- wizard/config values normalize the same way as CLI values;
- session-loaded values normalize the same way as CLI values;
- explicit CLI values override wizard/session values;
- password environment variable name is preserved, password value is not.

Transport/request provider tests:

- direct HTTPS provider receives the TLS pool kwargs;
- HTTP CONNECT proxy provider receives the same TLS pool kwargs;
- SOCKS proxy provider receives the same TLS pool kwargs;
- `--tls-legacy` plus mTLS does not drop cert/key settings;
- connection pool reuse still works with identical mTLS configuration;
- proxy credential masking remains unchanged.

Regression tests:

- existing HTTPS scan path without mTLS still behaves as before;
- existing HTTP scan path is unaffected;
- existing proxy/proxy-list/proxy-pool behavior is unaffected when mTLS is absent;
- existing `--tls-legacy` diagnostics remain stable;
- reports do not add raw secret-bearing fields.

## 1.7 Documentation requirements

Update:

- `README.md` quick usage or advanced transport/authenticated scanning section;
- `docs/Usage.md` CLI reference;
- `docs/transports/tls.md` or equivalent TLS compatibility page;
- `opendoor.conf` with commented examples and privacy warning;
- `CHANGELOG.md` under `v5.18.0`.

Documentation must state:

- mTLS is for authorized internal/client-certificate protected targets;
- certificate/key files are read from local disk;
- encrypted key password values should be provided through environment variables;
- OpenDoor stores only paths and env variable names in session/config contexts;
- OpenDoor does not generate certificates, intercept TLS, or impersonate browser TLS fingerprints.

## 1.8 Acceptance criteria

- mTLS works for direct HTTPS.
- mTLS composes with HTTP CONNECT proxy HTTPS.
- mTLS composes with SOCKS HTTPS.
- mTLS composes with `--tls-legacy`.
- No behavior changes when mTLS flags are absent.
- No password value, private key content or certificate body is written to logs, reports, debug output or sessions.
- Invalid inputs fail early with actionable errors.
- Deterministic unit tests cover CLI, config, session, TLS helper and request provider wiring.
- Full release verification baseline passes.

---

# 2. `5.19.0` — Request identity ergonomics

Status: **Accepted / candidates split by risk**

Accepted:

- named browser request profiles.

Candidate:

- `--anticache`;
- explicit cookie policy (`none`, `accept`, `sticky`) after separate design.

Rules:

- explicit `--header` wins;
- no JA3/JA4 spoofing;
- no hidden request-volume changes;
- no cookie values in reports/logs/sessions;
- profiles should only affect HTTP header identity, not TLS fingerprint impersonation.

---

# 3. `5.20.0` — Transport observability and WAF/CDN certainty foundation

Status: **Accepted after mTLS**

Data candidates:

- TLS protocol version;
- cipher;
- ALPN;
- certificate subject/issuer/expiry;
- HTTP protocol version where available;
- HTTP/3 advertisement through `Alt-Svc`;
- client-cert mode flag without cert content;
- response timing metadata required by later passive sniffers, at minimum `elapsed_ms`, `body_bytes`, status, content type and retry/timeout markers;
- optional server-provided timing headers such as `Server-Timing`, `X-Runtime`, `X-Response-Time`, `X-Request-Duration`, `X-Backend-Time` and upstream response-time headers, stored only as bounded metadata;
- passive WAF/CDN/provider evidence categories from already-observed headers, cookies, body markers, TLS metadata, CNAME metadata and optional injected CIDR datasets where those inputs are available;
- explainable WAF/CDN certainty labels such as `behavioral_only`, `possible`, `likely` and `confirmed`, derived from bounded evidence classes rather than pseudo-precise floating-point confidence.

Non-goals:

- TLS impersonation;
- browser-matching claims;
- JA3/JA4 controls;
- HTTP/3 client;
- load testing or repeated endpoint verification;
- stress-test semantics for response timing metrics;
- WAF bypass, bypass recommendation engines, or request mutation;
- claiming a concrete WAF/CDN provider from block/challenge behavior alone;
- changing existing WAF guard, WAF safe-mode, blocked bucket, calibration or request scheduling semantics.

## 3.1 WAF/CDN fingerprint certainty normalization

Status: **Accepted after mTLS as part of transport observability**

Goal: preserve OpenDoor's existing WAF-aware scanner behavior while making WAF/CDN/provider attribution more explainable and deterministic.

This work must not replace the current WAF runtime classifier, WAF safe-mode, WAF guard, blocked-response classification, or passive CDN/header handling. It should add a thin normalization layer that converts existing and future evidence into discrete certainty metadata.

Accepted:

- keep passive CDN/infrastructure presence separate from active WAF/blocking behavior;
- keep `cf-ray`, CDN headers and similar passive markers from turning otherwise normal responses into `blocked` findings by themselves;
- introduce signal strengths such as `weak`, `strong` and `definitive` for provider evidence;
- introduce result certainty labels such as `behavioral_only`, `possible`, `likely` and `confirmed`;
- count distinct evidence classes rather than duplicate raw markers, so repeated headers from the same source do not inflate certainty;
- support `behavioral_only` when OpenDoor observes WAF/block/challenge behavior but cannot safely attribute it to a concrete provider;
- allow current numeric confidence fields to remain as legacy/display metadata where required, but prefer structured certainty for new report/debug surfaces;
- support future transport evidence such as TLS issuer/certificate metadata, CNAME suffixes and optional CIDR dataset matches after the required observability inputs exist;
- emit bounded, redacted evidence reasons such as `definitive_header:cf-ray` or `behavior:waf_challenge` without raw secrets, cookies, authorization headers, certificate bodies or private key material.

Out of scope:

- adding a new public `--sniff` value;
- adding a new scan mode;
- adding request volume;
- probing for WAF identity;
- bypass payloads, bypass suggestions or bypass scoring;
- changing WAF safe-mode or WAF guard thresholds;
- changing blocked bucket semantics;
- claiming `confirmed` vendor attribution from behavior-only evidence;
- storing full headers, raw cookies, authorization values, private keys, client certificates or secret values in reports, sessions or logs.

Suggested certainty model:

```text
any definitive provider evidence        -> confirmed
>= 2 strong distinct evidence classes   -> confirmed
1 strong evidence class                 -> likely
>= 2 weak distinct evidence classes     -> likely
1 weak evidence class                   -> possible
WAF/challenge behavior without provider -> behavioral_only
no bounded evidence                     -> none
```

Distinct evidence classes may include:

```text
header
cookie
body_marker
tls_issuer
tls_certificate
cname_suffix
ip_cidr
runtime_behavior
```

Runtime behavior such as WAF challenges, rate limiting, 403/429 denial clusters or connection denial may increase confidence only when a provider already has independent evidence. Runtime behavior alone should produce `behavioral_only`, not a concrete provider claim.

Suggested additive metadata:

```json
{
  "waf_cdn_fingerprint": {
    "provider": "cloudflare",
    "certainty": "confirmed",
    "behavior": "active_block",
    "evidence_strength": "definitive",
    "evidence_classes": ["header", "runtime_behavior"],
    "reasons": ["definitive_header:cf-ray", "behavior:waf_challenge"]
  }
}
```

If no concrete provider is safely identified:

```json
{
  "waf_cdn_fingerprint": {
    "provider": null,
    "certainty": "behavioral_only",
    "behavior": "active_block",
    "evidence_classes": ["runtime_behavior"],
    "reasons": ["behavior:waf_challenge"]
  }
}
```

Required tests:

- passive CDN headers on normal `200` responses do not create `blocked` findings;
- active WAF/blocking behavior can produce `behavioral_only` without provider attribution;
- one weak signal produces `possible`;
- two weak distinct evidence classes produce `likely`;
- one strong signal produces `likely`;
- two strong distinct evidence classes produce `confirmed`;
- one definitive signal produces `confirmed`;
- duplicate markers from the same evidence class do not inflate certainty;
- runtime WAF behavior does not claim a concrete provider without independent provider evidence;
- runtime WAF behavior may promote an already-supported provider certainty within documented bounds;
- JSON/SQLite/SARIF/HTML metadata remains additive and bounded;
- no raw secrets, cookies, authorization values, proxy credentials, certificate bodies, private keys or client-key passwords are persisted;
- no additional HTTP requests are issued by the certainty normalizer;
- WAF guard, WAF safe-mode, blocked bucket and calibration behavior remain unchanged.

---

# 4. `5.21.0` — URL pattern metadata foundation

Status: **Deferred foundation**

Goal: add report-level URL pattern metadata without changing scheduling or findings.

Rules:

- no standalone `--url-pattern-dedupe` MVP;
- preserve original URL evidence;
- no request skipping;
- no destructive finding merge;
- JSON/SQLite additive metadata only where safe.

---

# 5. `5.22.0` — Bounded EAR sniffer

Status: **Accepted after URL pattern metadata**

Goal: add a dedicated `--sniff ear` detector for Execution-After-Redirect style exposure without turning OpenDoor into an offensive workflow or state-changing DAST engine.

## 5.1 User-facing CLI

Single opt-in interface only:

```bash
opendoor --host https://example.com --sniff ear
```

Rules:

- no additional EAR-specific public flags;
- no default scan behavior change;
- no effect on unrelated sniffers when `ear` is not requested;
- no impact on baseline request scheduling unless `--sniff ear` is explicitly enabled.

## 5.2 Scope

Accepted:

- passive analysis of existing `3xx` responses with `Location` headers;
- redirect body exposure detection for non-trivial response bodies;
- correlation with existing `secret`, `stacktrace`, admin-content and endpoint-style evidence where reusable detector cores exist;
- bounded safe-method validation using `GET` and `HEAD` only;
- differential comparison between the original redirect response and the redirect target response;
- observable non-destructive confirmation when evidence is available from headers or safe responses;
- additive JSON/SQLite/SARIF/HTML report metadata;
- concise CLI output with richer structured report evidence;
- deduplication/linking so `secret` evidence inside an EAR finding does not create noisy duplicate top-level findings for the same redirect response.

Out of scope:

- `POST`, `PUT`, `PATCH`, or `DELETE` requests generated by OpenDoor for EAR validation;
- automatic form submission;
- credential guessing;
- authentication bypass payload generation;
- parameter mutation for bypass testing;
- destructive side-effect verification;
- workflow/state mutation;
- request editor, repeater, intruder, MITM, or proxy-interception behavior;
- claiming confirmed destructive EAR when only redirect body exposure is observed.

## 5.3 Detection levels

`--sniff ear` should expose one public sniffer while reporting internal evidence levels:

| Level | Report confidence | Meaning | Allowed behavior |
|---:|---|---|---|
| 1 | `potential` | Redirect response contains sensitive or protected-looking body evidence. | Passive analysis only |
| 2 | `likely` | Safe differential validation confirms the redirect body differs from the destination and contains protected evidence. | Bounded `GET`/`HEAD` only |
| 3 | `confirmed_observable` | Non-destructive observable behavior shows execution-after-redirect style effects without synthetic state mutation. | Headers or safe responses only |

Level 3 must not mean destructive side-effect confirmation. It must be reserved for observable, non-destructive evidence such as redirect responses that set stateful headers or expose server-reported execution results without requiring OpenDoor to mutate application workflows.

## 5.4 Design rules

- `--sniff ear` must be implemented as a standalone response/probe sniffer, not inside `openredirect`.
- `openredirect` remains focused on attacker-controlled redirect targets.
- `ear` focuses on redirect control-flow exposure and redirect-body evidence.
- Extra validation requests must use the same target request provider, proxy settings, headers, timeout, retry, TLS context and mTLS configuration as the parent scan.
- Extra validation requests must be bounded to a small per-candidate budget.
- The sniffer must never synthesize state-changing requests.
- The sniffer must never store raw secret values, cookies, authorization headers, full sensitive bodies, client certificates, private keys, or password values in reports/sessions/logs.
- Findings should link correlated evidence instead of duplicating related sniffer output.

## 5.5 Suggested internal architecture

Candidate plugin:

```text
src/core/http/plugins/response/ear.py
```

Candidate bounded probe helper:

```text
src/core/http/probes/ear.py
```

Candidate responsibilities:

```text
ear.py
  - classify 3xx + Location responses
  - inspect redirect body evidence
  - call reusable detector cores for secret/stacktrace/admin-content signals
  - create contextual EAR findings

ear.py / probes/ear.py
  - run bounded GET/HEAD differential checks for candidates
  - promote confidence where safe validation succeeds
  - preserve request provider, proxy, TLS, mTLS and rate-limit semantics
```

## 5.6 Report metadata

Additive structured fields may include:

```json
{
  "sniffer": "ear",
  "type": "execution_after_redirect",
  "level": 2,
  "confidence": "likely",
  "category": "differential_redirect_exposure",
  "redirect_status": 302,
  "location": "/login",
  "body_size": 18420,
  "signals": ["secret", "stacktrace"],
  "safe_validation": {
    "methods": ["GET", "HEAD"],
    "extra_requests": 2
  }
}
```

All sensitive evidence must be redacted. Raw secret values and full sensitive bodies must not be persisted.

## 5.7 Required tests

- `--sniff ear` is accepted as a new sniffer value.
- EAR is inactive when `--sniff ear` is absent.
- Passive detection works for `3xx + Location + sensitive body`.
- Small framework fallback redirect bodies do not create noisy findings.
- Safe differential validation uses only `GET` and `HEAD`.
- The detector never issues `POST`, `PUT`, `PATCH`, or `DELETE`.
- The detector never submits forms or mutates parameters.
- Request budget is bounded per candidate.
- Existing proxy/TLS/mTLS configuration is preserved for validation requests.
- Secret evidence inside EAR is redacted and does not create duplicate noisy top-level findings for the same redirect response.
- JSON/SQLite/SARIF/HTML output remains additive and backward-compatible.

---

# 6. `5.23.0` — Load-risk sniffer

Status: **Accepted after HTTP metrics, URL pattern metadata and bounded EAR sniffer**

Goal: add a dedicated `--sniff loadrisk` detector for potential resource-amplifying endpoints without turning OpenDoor into a load tester, stress tester, request mutator, or offensive availability-testing tool.

## 6.1 User-facing CLI

Single opt-in interface only:

```bash
opendoor --host https://example.com --sniff loadrisk
```

Rules:

- no additional loadrisk-specific public flags in the first implementation;
- no default scan behavior change;
- no effect on unrelated sniffers when `loadrisk` is not requested;
- no extra verification requests in v1;
- no reliance on hardcoded endpoint path names or dictionary-specific keywords.

## 6.2 Scope

Accepted:

- passive analysis of responses already observed during the scan;
- latency anomaly detection using HTTP timing metrics such as `elapsed_ms` and later `ttfb_ms` when available;
- baseline-aware scoring using target-level and category-level latency statistics;
- calibration-aware negative evidence so soft404/error templates do not become noisy load-risk findings;
- bounded parsing of server-provided timing headers such as `Server-Timing`, `X-Runtime`, `X-Response-Time`, `X-Request-Duration`, `X-Backend-Time` and upstream timing headers;
- response metadata evidence such as status, content type, body size, content length, retry/timeout-near-miss markers and async/job-style headers;
- optional body-marker evidence for server-reported queued/processing/generated/updated work, without relying on URL path names;
- dedicated `loadrisk` report bucket with structured evidence metrics;
- concise CLI output for medium/high-confidence findings and richer JSON/SQLite/SARIF/HTML metadata;
- linking/correlation with `endpoint`, `file`, `skipempty`, `collation` and calibration results where available.

Out of scope:

- `POST`, `PUT`, `PATCH`, or `DELETE` requests generated by OpenDoor for load-risk validation;
- repeated calls to the same endpoint to verify load;
- concurrency, stress, saturation, or benchmark testing;
- mutating query parameters such as adding large `limit`, `pageSize`, `force`, `all`, `full` or similar values;
- automatic form submission;
- credential guessing;
- authentication bypass payload generation;
- claiming confirmed database amplification or SQL query counts without backend telemetry;
- path-name hardcoding as a primary detection strategy;
- request editor, repeater, intruder, MITM, or proxy-interception behavior.

## 6.3 Detection model

`--sniff loadrisk` should classify potential resource-amplifying endpoints through behavior and metrics rather than endpoint names.

Primary evidence:

```text
latency_outlier
server_timing_high_backend_duration
server_timing_high_db_duration
near_timeout_completed_response
large_body_with_high_latency
async_job_response_metadata
calibration_aware_non_soft404_response
```

Example scoring inputs:

```text
elapsed_ms
baseline_median_ms
baseline_p95_ms
median_ratio
p95_ratio
body_bytes
content_length
status
content_type
retry_count
timeout_near_miss
server_timing.app_ms
server_timing.db_ms
```

Candidate severity should be derived from score and confidence:

| Condition | Severity | Confidence |
|---|---|---|
| Strong latency outlier plus server timing or async/job evidence | High | High/medium |
| Strong latency outlier with stable baseline and non-soft404 response | Medium | Medium |
| Large body plus high latency without other evidence | Low/medium | Low/medium |
| Suspicious timing on calibrated soft404/error template | Suppressed or info | Low |

The detector must report `Potential resource-amplifying endpoint`, not confirmed DDoS, confirmed database amplification, or confirmed backend query count.

## 6.4 Baseline and metrics preparation

Required foundation before implementation:

- response objects must expose at least `elapsed_ms`, `body_bytes`, status and content type to response plugins and reports;
- the scan runtime should maintain latency statistics such as count, median, p90, p95 and p99;
- baseline statistics should avoid being polluted by obvious outliers, transport failures, calibrated soft404 pages and denied responses;
- if URL pattern metadata exists, pattern-level aggregation may be used as additional evidence, but single-response detection must not depend on URL pattern availability;
- timing metadata must remain passive and must not create additional request volume by itself.

## 6.5 Suggested internal architecture

Candidate plugin:

```text
src/core/http/plugins/response/loadrisk.py
```

Candidate metrics helpers:

```text
src/core/http/metrics.py
src/core/http/timing.py
```

Candidate responsibilities:

```text
loadrisk.py
  - consume observed response timing and metadata
  - compare response latency against baseline statistics
  - parse bounded server timing headers
  - suppress calibrated soft404/error-template noise
  - create contextual loadrisk findings with structured evidence

metrics.py / timing.py
  - expose passive response timing fields
  - maintain runtime latency baselines
  - provide median/p90/p95/p99 snapshots to response plugins
```

## 6.6 Report metadata

Additive structured fields may include:

```json
{
  "bucket": "loadrisk",
  "sniffer": "loadrisk",
  "type": "potential_resource_amplifying_endpoint",
  "severity": "medium",
  "confidence": "medium",
  "metrics": {
    "elapsed_ms": 18500,
    "body_bytes": 86000,
    "baseline_median_ms": 380,
    "baseline_p95_ms": 2100,
    "median_ratio": 48.68,
    "p95_ratio": 8.81
  },
  "evidence": [
    "latency_outlier",
    "backend_wait_suspected"
  ],
  "safety": {
    "stress_test_performed": false,
    "repeated_requests_performed": false,
    "state_changing_method_generated": false
  }
}
```

All evidence must be bounded. Raw cookies, authorization headers, request bodies, full sensitive response bodies, client certificates, private keys and secret values must not be persisted.

## 6.7 Required tests

- `--sniff loadrisk` is accepted as a new sniffer value.
- Loadrisk is inactive when `--sniff loadrisk` is absent.
- Passive latency outlier detection works without extra HTTP requests.
- The detector does not rely on hardcoded endpoint path names.
- Calibrated soft404/error templates are suppressed or downgraded.
- Server timing headers are parsed as bounded metadata.
- The detector never issues `POST`, `PUT`, `PATCH`, or `DELETE`.
- The detector never repeats a request for stress or confirmation.
- The detector never mutates parameters or submits forms.
- JSON/SQLite/SARIF/HTML output includes additive `loadrisk` bucket metadata.
- Low-confidence findings do not flood concise CLI output.
- No raw secret values, cookies, authorization headers or full sensitive bodies are written to reports/logs/sessions.

---

# 7. `5.24.0` — Report query, report rescan, and report merge tooling

Status: **Accepted after bounded EAR and load-risk sniffer metadata**

## Report query / lookup DSL

CLI:

```bash
opendoor --report-query reports/example.sqlite --where "bucket=success&status=200&path~admin"
opendoor --report-query reports/example.json --where "url_pattern=/api/users/{int}"
```

Rules:

- offline only;
- no raw SQL;
- no Python/shell expressions;
- deterministic output.

## Report rescan

CLI:

```bash
opendoor --report-rescan reports/example.sqlite --sniff secret,malware,stacktrace,endpoint
```

Rules:

- offline only;
- zero network calls;
- append additive passive findings;
- preserve original findings.

## Report merge

CLI:

```bash
opendoor --report-merge ./reports/*.sqlite --output merged.sqlite
```

Rules:

- offline only;
- preserve host context and original evidence;
- deterministic ordering.

---

# 8. `5.25.0` — MCP stdio integration

Status: **Accepted after report query/rescan/merge**

MVP:

```bash
opendoor --mcp
opendoor --mcp --mcp-transport stdio
```

Rules:

- stdio only;
- local process only;
- no HTTP listener;
- no arbitrary shell command;
- redacted and bounded finding reads.

---

# 9. `5.26.0` — Reporting and target import integrations

Accepted:

- native XML report format;
- Nmap XML target import;
- HAR target/path import;
- mitmproxy dump target/path import if dependency-light;
- replayable request-list export.

Rules:

- offline import/export only;
- no embedded proxy;
- no MITM;
- no credential replay;
- no request body/cookie/auth header import by default.

---

# 10. `5.27.0` — VHost mode

Status: **Accepted after TLS/SNI/report metadata mature**

CLI:

```bash
opendoor --host https://1.2.3.4 --vhost-list hosts.txt
opendoor --connect 1.2.3.4:443 --scheme https --vhost-list hosts.txt
```

Required SNI modes:

```bash
--sni-mode host
--sni-mode vhost
--sni-mode none
```

Rules:

- keep Host header, SNI, connect target and report target explicit;
- no implicit VHost brute force from unrelated discovery modes;
- host-surface expansion requires separate design approval before it can compose with other discovery modes.

---

# 11. Bypass expansion track

Status: **Deferred**

Do not start before lower-risk input/report/transport work.

Potential scope:

- pluggable bypass technique engine;
- method mutation;
- encoding mutation;
- Unicode encoding;
- scoring tiers;
- calibration and replay stability;
- bounded variant runner.

Raw HTTP bypass engine remains a **`6.0.0` candidate** unless fully isolated and explicitly experimental.

---

# 12. Later candidates

- JSONL runtime event logs;
- pause menu expansion with new commands only;
- passive recon mode;
- SPA hints;
- additional wordlist-source extensions;
- Burp/Caido/ZAP offline history import after HAR/import primitives;
- PostgreSQL report sink;
- takeover hints, never confirmed takeover;
- OAST/callback provider abstraction after separate threat model;
- internal ScanFlow / ResponseFlow model;
- internal sniffer lifecycle hooks;
- passive CORS response-header analysis after separate product-fit review;
- cookie security grading after separate product-fit review.

---

# 13. Experimental / hold

Experimental:

- HTTP/2 transport mode;
- async engine research;
- Swarm Mode;
- Ethical Rate Adaptation;
- OpenTelemetry traces.

Hold / not recommended for stable `5.x`:

- TLS fingerprint impersonation;
- HTTP/3 client;
- heavy browser automation dependency;
- embedded proxy/daemon mode;
- MITM interception/proxy behavior;
- interactive request editor/repeater mode;
- unauthenticated MCP HTTP listener;
- generic Intruder/brute-force mode.

---

# 14. Remaining checklist

## P1 — `5.18.0`

- [ ] Shared TLS context factory.
- [ ] Preserve direct HTTPS default behavior.
- [ ] Preserve HTTP default behavior.
- [ ] Preserve proxy HTTPS behavior.
- [ ] Preserve SOCKS HTTPS behavior.
- [ ] Preserve `--tls-legacy` behavior.
- [ ] `--client-cert` CLI option.
- [ ] `--client-key` CLI option.
- [ ] `--client-key-password-env` CLI option.
- [ ] Direct HTTPS mTLS.
- [ ] HTTP CONNECT proxy HTTPS mTLS.
- [ ] SOCKS HTTPS mTLS.
- [ ] Session save/load for cert/key paths and password env name.
- [ ] Config/wizard support if parity is required.
- [ ] Privacy tests proving passwords are not persisted/logged.
- [ ] Docs and changelog.
- [ ] Full release verification baseline.

## P2 — `5.19.0`

- [ ] Named browser request profiles.
- [ ] Optional `--anticache` decision.
- [ ] Explicit cookie policy decision.
- [ ] Privacy tests for cookie handling.

## P3 — `5.20.0`

- [ ] Transport fingerprint observation.
- [ ] HTTP version telemetry.
- [ ] HTTP/3 advertisement detection.
- [ ] mTLS-safe transport metadata.
- [ ] WAF/CDN certainty normalization layer.
- [ ] `behavioral_only` state for WAF behavior without safe provider attribution.
- [ ] Distinct evidence-class counting for WAF/CDN provider certainty.
- [ ] Tests proving passive CDN headers do not become blocked findings by themselves.
- [ ] Tests proving the certainty normalizer adds no request volume and does not change WAF guard/safe-mode behavior.

## P4 — `5.21.0`

- [ ] URL pattern normalizer module.
- [ ] JSON/SQLite pattern metadata decision.
- [ ] Regression tests proving no request skipping.

## P5 — `5.22.0`

- [ ] `--sniff ear` sniffer value.
- [ ] Passive 3xx redirect-body exposure detection.
- [ ] Secret/stacktrace/admin-content evidence correlation.
- [ ] Bounded GET/HEAD differential validation.
- [ ] Observable non-destructive confirmation metadata.
- [ ] Deduplication/linking for correlated secret evidence.
- [ ] JSON/SQLite/SARIF/HTML additive report metadata.
- [ ] Tests proving no POST/PUT/PATCH/DELETE, no form submission and no baseline behavior change.

## P6 — `5.23.0`

- [ ] `--sniff loadrisk` sniffer value.
- [ ] Passive response timing metrics available to response plugins.
- [ ] Runtime latency baseline snapshots: median, p90, p95 and p99.
- [ ] Latency outlier scoring without hardcoded endpoint path names.
- [ ] Server timing header parsing as bounded metadata.
- [ ] Calibration-aware suppression/downgrade for soft404/error templates.
- [ ] Dedicated `loadrisk` report bucket with evidence metrics.
- [ ] Tests proving no repeated verification calls, no request mutation, no form submission and no state-changing methods.

## P7 — `5.24.0`

- [ ] Report query DSL.
- [ ] SQLite query input.
- [ ] JSON query input.
- [ ] `--report-rescan`.
- [ ] JSON report rescan.
- [ ] SQLite report rescan.
- [ ] Zero-network passive re-analysis tests.
- [ ] `--report-merge`.
- [ ] JSON report merge.
- [ ] SQLite report merge.
- [ ] Deterministic ordering.

## P8+ — later

- [ ] MCP stdio.
- [ ] XML report format.
- [ ] Nmap XML import.
- [ ] HAR / mitmproxy import.
- [ ] Replayable request-list export.
- [ ] VHost mode.
- [ ] Bypass expansion track.

---

# 15. Suggested implementation tickets

## Ticket 1 — TLS context factory foundation

Release target: `5.18.0`

Scope:

- centralize TLS context creation;
- preserve existing direct HTTPS behavior;
- preserve existing proxy HTTPS behavior;
- preserve SOCKS HTTPS behavior;
- preserve `--tls-legacy` behavior;
- avoid public behavior change before mTLS flags are added.

Required tests:

- direct HTTPS context creation;
- legacy TLS context behavior;
- proxy HTTPS context behavior;
- SOCKS HTTPS context behavior;
- no client-cert behavior when flags are absent.

## Ticket 2 — mTLS CLI/config/session plumbing

Release target: `5.18.0`

Scope:

- add `--client-cert`;
- add `--client-key`;
- add `--client-key-password-env`;
- validate cert/key paths;
- preserve paths and password env name in session/config flows;
- never persist password values.

Required tests:

- CLI parsing;
- invalid/missing paths;
- env var lookup;
- session save/load privacy;
- wizard/config override behavior.

## Ticket 3 — mTLS transport integration

Release target: `5.18.0`

Scope:

- direct HTTPS;
- HTTP CONNECT proxy HTTPS;
- SOCKS HTTPS;
- `--tls-legacy` composition.

Required tests:

- direct provider receives cert configuration;
- proxy provider receives cert configuration;
- SOCKS provider receives cert configuration;
- legacy TLS + mTLS does not overwrite cert settings;
- no secret values in debug output.

## Ticket 4 — Documentation and release verification

Release target: `5.18.0`

Scope:

- README/docs examples;
- changelog line;
- final release verification gates.

Required checks:

- markdown review;
- `python -m ruff check .`;
- full unittest and coverage gate;
- package and CLI smoke checks.

## Ticket 5 — Transport observability foundation

Release target: `5.20.0`

Scope:

- expose bounded TLS/HTTP metadata after the TLS context contract is stable;
- include mTLS-safe client-cert mode metadata without certificate content;
- expose HTTP protocol metadata where available;
- expose passive response timing and body-size metadata required by later sniffers;
- keep all metadata additive and avoid request-volume changes.

Required tests:

- TLS/HTTP metadata is additive and bounded;
- mTLS mode can be represented without cert/key/password content;
- default HTTPS behavior is unchanged;
- no raw secret values, cookies, authorization headers, client certificates or private keys are persisted.

## Ticket 6 — WAF/CDN certainty normalization

Release target: `5.20.0`

Scope:

- preserve the existing OpenDoor WAF runtime classifier, WAF safe-mode, WAF guard and blocked bucket behavior;
- add passive WAF/CDN/provider certainty labels: `behavioral_only`, `possible`, `likely`, `confirmed`;
- classify evidence strengths as `weak`, `strong` and `definitive`;
- count distinct evidence classes rather than duplicate raw markers;
- keep passive infrastructure markers separate from active WAF/block behavior;
- emit bounded, redacted evidence reasons in report/debug metadata;
- support future TLS/CNAME/CIDR evidence only when those passive inputs are available.

Required tests:

- passive CDN headers on normal responses do not create blocked findings;
- behavior-only WAF/challenge responses do not claim a concrete provider;
- weak/strong/definitive evidence maps to deterministic certainty labels;
- duplicate same-class markers do not inflate certainty;
- runtime behavior can promote only already-supported provider attribution within documented bounds;
- no extra HTTP requests are issued;
- no WAF guard, WAF safe-mode, blocked bucket or calibration semantics change;
- no raw secrets, cookies, authorization values, certificate bodies, private keys or password values are persisted.

## Ticket 7 — EAR sniffer foundation

Release target: `5.22.0`

Scope:

- add `ear` as a new `--sniff` value;
- detect `3xx + Location` redirect-body exposure;
- correlate with existing secret/stacktrace/admin-content evidence;
- emit contextual EAR findings without noisy duplicate findings where possible;
- keep `openredirect` separate and unchanged.

Required tests:

- passive detection fixtures;
- small fallback redirect body suppression;
- correlated evidence redaction;
- no behavior change when `--sniff ear` is absent.

## Ticket 8 — EAR safe differential validation

Release target: `5.22.0`

Scope:

- run bounded `GET`/`HEAD` validation only for EAR candidates;
- compare original redirect body with redirect target response;
- promote confidence from potential to likely where differential evidence is present;
- preserve proxy, timeout, retry, TLS and mTLS request-provider behavior.

Required tests:

- only `GET` and `HEAD` are issued;
- no form submission;
- no parameter mutation;
- bounded extra requests per candidate;
- validation requests reuse existing transport configuration.

## Ticket 9 — EAR reporting and release verification

Release target: `5.22.0`

Scope:

- additive JSON/SQLite/SARIF/HTML metadata;
- concise CLI output;
- redacted evidence;
- release documentation and changelog.

Required tests:

- no raw secret values in reports/logs/sessions;
- no destructive side-effect claims;
- no top-level report schema breakage;
- full verification baseline.

## Ticket 10 — HTTP timing metrics foundation for LoadRisk

Release target: `5.23.0`

Scope:

- expose passive response timing metadata to response plugins;
- provide at minimum `elapsed_ms`, `body_bytes`, status and content type;
- parse bounded server timing headers where present;
- maintain runtime latency baseline snapshots for later scoring;
- avoid any additional request volume.

Required tests:

- response timing metadata exists for successful, redirected, denied and calibrated responses;
- timing metadata is additive in reports;
- server timing parsing is bounded and malformed-safe;
- no secrets, cookies or authorization headers are copied into timing metadata.

## Ticket 11 — LoadRisk passive scoring plugin

Release target: `5.23.0`

Scope:

- add `loadrisk` as a new `--sniff` value;
- detect latency outliers using baseline-aware metrics;
- do not rely on hardcoded endpoint path names;
- suppress or downgrade calibrated soft404/error-template responses;
- classify findings as `Potential resource-amplifying endpoint`.

Required tests:

- passive latency outlier fixture produces a loadrisk finding;
- generic URLs such as `/page.php` or `/item.php` can be classified by behavior;
- suspicious path names alone do not create findings;
- soft404/error-template fixtures are suppressed or downgraded;
- no extra HTTP request is issued by the plugin.

## Ticket 12 — LoadRisk reporting and release verification

Release target: `5.23.0`

Scope:

- add dedicated `loadrisk` bucket;
- emit structured evidence metrics in JSON/SQLite/SARIF/HTML;
- keep TXT/CLI output concise;
- document safe defensive scope and non-goals;
- add changelog entry.

Required tests:

- `loadrisk` bucket is additive and backward-compatible;
- low-confidence findings do not flood concise CLI output;
- no raw sensitive values are written to reports/logs/sessions;
- tests prove no POST/PUT/PATCH/DELETE, no request repetition, no parameter mutation and no form submission;
- full verification baseline.

---

# 16. Implementation discipline

For each roadmap item:

1. follow strict SemVer classification before assigning a release target;
2. keep public CLI behavior backward-compatible unless explicitly approved for a major release;
3. add deterministic unit tests before manual scans;
4. avoid live internet dependencies in tests;
5. document user-visible flags in README and docs;
6. update changelog for user-visible behavior;
7. run local release checks before release PRs;
8. explicitly report adjacent functionality affected by shared runtime changes;
9. prefer additive report metadata over breaking schema changes;
10. do not store secrets, private keys, client certificate passwords, proxy credentials, raw secret values, cookie values, callback secrets, or full sensitive file bodies in reports/sessions/logs;
11. run benchmark comparison for normalization, sniffer, report merge, or scan queue hot-path changes;
12. keep report rescan offline-only and prove zero network calls;
13. keep OAST/callback features disabled by default and behind separate approved design;
14. avoid new dependencies unless stdlib/current dependencies cannot implement safely;
15. do not ship new public features in patch releases;
16. keep passive sniffer stdout concise and structured report metadata richer;
17. avoid duplicating findings across related sniffers; use linked metadata;
18. keep sniffers standalone by default: do not add per-sniffer CLI arguments unless the maintainer explicitly approves the new public semantics;
19. prefer extending existing test modules that already cover the affected component or behavior; do not create new test files only to raise coverage unless there is no suitable existing module, the new behavior represents a distinct subsystem, or the maintainer explicitly approves a new test module.

Required verification baseline:

```bash
python -m ruff check .
vulture src tests --min-confidence 65
python -m unittest
coverage erase
coverage run -m unittest discover -s tests -p "test_*.py"
coverage report -m --precision=2 --fail-under=99
python -m pip install -e .
python -m build
python -m twine check dist/*
opendoor --help
opendoor --version
python opendoor.py --help
python opendoor.py --version
```
