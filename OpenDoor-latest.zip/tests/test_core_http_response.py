# -*- coding: utf-8 -*-

import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from urllib3.response import HTTPResponse
from urllib.parse import urlparse

from src.core.http.providers.response import ResponseProvider
from src.core.http.response import Response
from src.core.http.redirect_classifier import RedirectClassifier
from src.core.http.plugins.response_plugin import ResponsePlugin
from src.core.http.plugins.exceptions import ResponsePluginError
from src.core.http.plugins.response.collation import CollationResponsePlugin
from src.core.http.plugins.response.file import FileResponsePlugin
from src.core.http.plugins.response.indexof import IndexofResponsePlugin
from src.core.http.plugins.response.skipempty import SkipemptyResponsePlugin
from src.core.http.plugins.response.skipsizes import SkipSizesResponsePlugin
from src.core.http.plugins.response.provider.provider import ResponsePluginProvider
from src.core.http.exceptions import ResponseError


class TestResponsePluginProvider(unittest.TestCase):
    """TestResponsePluginProvider class."""

    def test_process_decodes_body(self):
        """ResponsePluginProvider.process() should decode byte bodies."""

        provider = ResponsePluginProvider()
        response = HTTPResponse(status=200, body='тест'.encode('cp1251'), headers={'X-Test': '1'})

        provider.process(response)

        self.assertEqual(provider._status, 200)
        self.assertEqual(provider._headers['X-Test'], '1')
        self.assertEqual(provider._body, 'тест')

    def test_process_keeps_string_body_untouched(self):
        """ResponsePluginProvider.process() should leave string bodies untouched."""

        provider = ResponsePluginProvider()
        response = SimpleNamespace(status='200.0', headers={'X-Test': '1'}, data='plain-text')

        provider.process(response)

        self.assertEqual(provider._status, 200)
        self.assertEqual(provider._headers['X-Test'], '1')
        self.assertEqual(provider._body, '')


class TestResponsePlugins(unittest.TestCase):
    """TestResponsePlugins class."""

    def make_response(self, status=200, body=b'', headers=None):
        return HTTPResponse(status=status, body=body, headers=headers or {})

    def test_file_plugin_detects_large_files(self):
        """FileResponsePlugin should classify large responses as files."""

        plugin = FileResponsePlugin(None)
        response = self.make_response(body=b'x' * 10, headers={'Content-Length': str(1000000)})

        self.assertEqual(plugin.process(response), 'file')

    def test_file_plugin_detects_large_body_when_header_is_lower(self):
        """FileResponsePlugin should also detect files by decoded body length when header is lower."""

        plugin = FileResponsePlugin(None)
        response = self.make_response(body=b'x' * 1000000, headers={'Content-Length': '1'})

        self.assertEqual(plugin.process(response), 'file')

    def test_file_plugin_returns_none_for_small_allowed_response(self):
        """FileResponsePlugin should ignore small responses with allowed statuses."""

        plugin = FileResponsePlugin(None)
        response = self.make_response(body=b'small', headers={'Content-Length': '5'})

        self.assertIsNone(plugin.process(response))

    def test_file_plugin_returns_none_for_unsupported_status(self):
        """FileResponsePlugin should ignore unsupported statuses even for large responses."""

        plugin = FileResponsePlugin(None)
        response = self.make_response(status=404, body=b'x' * 1000000, headers={'Content-Length': str(1000000)})

        self.assertIsNone(plugin.process(response))

    def test_indexof_plugin_detects_index_page(self):
        """IndexofResponsePlugin should detect real Index Of pages."""

        plugin = IndexofResponsePlugin(None)
        response = self.make_response(
            body=(
                b'<html>'
                b'<head><title>Index of /backup/</title></head>'
                b'<body>'
                b'<h1>Index of /backup/</h1>'
                b'<a href="../">Parent Directory</a>'
                b'<a href="dump.sql">dump.sql</a>'
                b'</body>'
                b'</html>'
            )
        )

        self.assertEqual(plugin.process(response), 'indexof')

    def test_skipempty_plugin_detects_empty_success_page(self):
        """SkipemptyResponsePlugin should skip near-empty success pages."""

        plugin = SkipemptyResponsePlugin(None)
        response = self.make_response(body=b'a', headers={'Content-Length': '10'})

        self.assertEqual(plugin.process(response), 'skip')

    def test_skipsizes_plugin_detects_matching_size(self):
        """SkipSizesResponsePlugin should skip configured response sizes."""

        plugin = SkipSizesResponsePlugin('1:2')
        response = self.make_response(body=b'a' * 2048, headers={'Content-Length': '2048'})

        self.assertEqual(plugin.process(response), 'skip')

    def test_collation_plugin_detects_false_positive_pages(self):
        """CollationResponsePlugin should mark identical long pages as failed."""

        plugin = CollationResponsePlugin(None)
        first = self.make_response(body=b'a' * 150, headers={'Content-Length': '150'})
        second = self.make_response(body=b'a' * 150, headers={'Content-Length': '150'})

        self.assertIsNone(plugin.process(first))
        self.assertEqual(plugin.process(second), 'failed')

    def test_collation_plugin_uses_ratio_match(self):
        """CollationResponsePlugin should also detect near-identical bodies by ratio."""

        plugin = CollationResponsePlugin(None)
        body1 = ('A' * 120 + 'B' * 30).encode()
        body2 = ('A' * 119 + 'B' * 31).encode()

        self.assertIsNone(plugin.process(self.make_response(body=body1, headers={'Content-Length': str(len(body1))})))
        self.assertEqual(plugin.process(self.make_response(body=body2, headers={'Content-Length': str(len(body2))})), 'failed')

    def test_collation_plugin_ignores_short_content(self):
        """CollationResponsePlugin should ignore short successful bodies."""

        plugin = CollationResponsePlugin(None)
        response = self.make_response(body=b'a' * 50, headers={'Content-Length': '50'})

        self.assertIsNone(plugin.process(response))
        self.assertEqual(plugin.previous_item, {})
        self.assertEqual(plugin.current_item, {})

    def test_collation_plugin_ignores_zero_content_length_header(self):
        """CollationResponsePlugin should ignore zero-length headers even when body exists."""

        plugin = CollationResponsePlugin(None)
        response = self.make_response(body=b'x' * 1000, headers={'Content-Length': '0'})

        self.assertIsNone(plugin.process(response))
        self.assertEqual(plugin.previous_item, {})

    def test_collation_plugin_uses_current_item_ratio_equality_branch(self):
        """CollationResponsePlugin should detect repeated ratios using current_item comparison."""

        plugin = CollationResponsePlugin(None)

        first = self.make_response(body=b'A' * 130, headers={'Content-Length': '130'})
        second = self.make_response(body=b'B' * 140, headers={'Content-Length': '140'})
        third = self.make_response(body=b'C' * 141, headers={'Content-Length': '141'})

        self.assertIsNone(plugin.process(first))
        self.assertIsNone(plugin.process(second))
        self.assertEqual(plugin.process(third), 'failed')

    def test_collation_plugin_returns_none_for_unsupported_status(self):
        """CollationResponsePlugin should ignore unsupported statuses."""

        plugin = CollationResponsePlugin(None)
        response = self.make_response(status=404, body=b'A' * 200, headers={'Content-Length': '200'})

        self.assertIsNone(plugin.process(response))


class TestResponsePluginLoader(unittest.TestCase):
    """TestResponsePluginLoader class."""

    def test_load_known_plugin_with_value(self):
        """ResponsePlugin.load() should load plugins with optional values."""

        plugin = ResponsePlugin.load('skipsizes=1:2')

        self.assertIsInstance(plugin, SkipSizesResponsePlugin)
        self.assertEqual(plugin.SIZE_VALUES, ['1KB', '2KB'])

    def test_load_raises_for_unknown_plugin(self):
        """ResponsePlugin.load() should reject unknown plugins."""

        with self.assertRaises(ResponsePluginError):
            ResponsePlugin.load('unknown')

    def test_load_wraps_import_error(self):
        """ResponsePlugin.load() should wrap import errors."""

        with patch('src.core.http.plugins.response_plugin.importlib.import_module', side_effect=ImportError):
            with self.assertRaises(ResponsePluginError):
                ResponsePlugin.load('file')


class TestRedirectClassifier(unittest.TestCase):
    """Passive redirect classifier test cases."""

    def classify(self, source, status=302, location='/login'):
        """Classify a redirect in tests."""

        return RedirectClassifier.classify(source, status, location)

    def test_classifies_common_redirect_markers(self):
        """Should classify common redirect shapes conservatively."""

        samples = [
            ('https://localhost/api', 301, 'https://localhost/api/', 'canonical'),
            ('https://localhost/old', 302, '/new', 'internal'),
            ('https://localhost/admin', 302, '/login?next=/admin', 'login'),
            ('https://localhost/logout', 302, '/login?logged_out=1', 'login'),
            ('https://localhost/logout', 302, '/logout', 'logout'),
            ('https://localhost/oauth', 302, 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize', 'external'),
            ('http://localhost/api', 308, 'https://localhost/api', 'scheme'),
            ('https://localhost/logo', 302, '/static/logo.png', 'asset'),
            ('https://localhost/panel', 302, '/cdn-cgi/challenge-platform/h/b/orchestrate/chl_page/v1', 'waf'),
            ('https://localhost/x', 302, '/y', 'internal'),
        ]

        for source, status, location, expected in samples:
            with self.subTest(source=source, location=location):
                self.assertEqual(self.classify(source, status, location)['type'], expected)

    def test_handles_invalid_missing_and_unsupported_redirects(self):
        """Should keep invalid or unsupported redirect values bounded."""

        self.assertEqual(self.classify('https://localhost/', 302, '')['type'], 'invalid')
        self.assertEqual(self.classify('https://localhost/', 200, '/login'), {})
        self.assertEqual(self.classify('', 302, '/login')['type'], 'invalid')

    def test_normalizes_scheme_relative_and_redacts_sensitive_query_values(self):
        """Should normalize protocol-relative targets and redact sensitive query values."""

        external = self.classify('https://localhost/', 302, '//cdn.example.com/app')
        self.assertEqual(external['type'], 'external')
        self.assertEqual(external['target_url'], 'https://cdn.example.com/app')
        self.assertEqual(external['target_host'], 'cdn.example.com')
        self.assertEqual(external['display'], 'https://cdn.example.com/app')

        redacted = self.classify(
            'https://localhost/admin',
            302,
            '/login?token=abcdef123456&next=/admin&state=xyz987654',
        )
        self.assertEqual(redacted['type'], 'login')
        self.assertIn('token=abcd****', redacted['location'])
        self.assertIn('state=xyz9****', redacted['location'])
        self.assertIn('next=/admin', redacted['location'])

    def test_external_redirect_display_preserves_scheme_without_changing_scheme_redirects(self):
        """External redirect runtime display should include protocol while scheme redirects stay unchanged."""

        external = self.classify(
            'https://www.uralopera.ru/?view=phpinfo',
            302,
            'https://uralopera.ru',
        )
        self.assertEqual(external['type'], 'external')
        self.assertEqual(external['display'], 'https://uralopera.ru')

        redacted_external = self.classify(
            'https://localhost/start',
            302,
            'https://cdn.example.com/cb?token=abcdef123456&next=/home',
        )
        self.assertEqual(redacted_external['type'], 'external')
        self.assertIn('https://cdn.example.com/cb?token=abcd****', redacted_external['display'])
        self.assertNotIn('abcdef123456', redacted_external['display'])

        scheme = self.classify('http://localhost/api', 308, 'https://localhost/api')
        self.assertEqual(scheme['type'], 'scheme')
        self.assertEqual(scheme['display'], 'https://localhost/api')

    def test_get_location_supports_native_header_fallback_and_invalid_headers(self):
        """Should extract Location from native response helpers and mapping headers."""

        native = SimpleNamespace(get_redirect_location=MagicMock(return_value=' /native '), headers={})
        self.assertEqual(RedirectClassifier.get_location(native), '/native')

        broken_native = SimpleNamespace(
            get_redirect_location=MagicMock(side_effect=AttributeError),
            headers={'Location': ' /header '},
        )
        self.assertEqual(RedirectClassifier.get_location(broken_native), '/header')

        non_mapping = SimpleNamespace(headers=['Location', '/bad'])
        self.assertEqual(RedirectClassifier.get_location(non_mapping), '')

        missing = SimpleNamespace(get_redirect_location=MagicMock(return_value=False), headers={'X-Test': '1'})
        self.assertEqual(RedirectClassifier.get_location(missing), '')

    def test_helper_edges_keep_redirect_contract_deterministic(self):
        """Should cover edge branches for marker, redaction and path helpers."""

        self.assertEqual(RedirectClassifier.classify('https://localhost/', 'bad', '/login'), {})
        self.assertEqual(RedirectClassifier.marker({'type': 'login'}), 'R(login)')
        self.assertEqual(RedirectClassifier.marker(None), 'R(unknown)')
        self.assertEqual(
            RedirectClassifier.sanitize_location('/cb?code=abc&flag#frag'),
            '/cb?code=****&flag#frag',
        )
        self.assertEqual(RedirectClassifier._host_port(urlparse('/relative')), '')
        self.assertEqual(RedirectClassifier._host_port(urlparse('https://localhost:8443/a')), 'localhost:8443')
        self.assertFalse(RedirectClassifier._is_canonical_redirect('/api', '/api'))
        self.assertEqual(RedirectClassifier._redact_value('abc'), '****')

        oauth = self.classify('https://localhost/start', 302, 'https://idp.example.com/oauth/authorize')
        self.assertEqual(oauth['type'], 'external')
        self.assertEqual(oauth['reason'], 'sso_redirect')

        asset = self.classify('https://localhost/download', 302, '/assets/')
        self.assertEqual(asset['type'], 'asset')

    def test_truncates_long_locations(self):
        """Should bound stored and displayed Location values."""

        location = '/login?next=/{0}'.format('a' * 400)
        classification = self.classify('https://localhost/admin', 302, location)

        self.assertLessEqual(len(classification['location']), RedirectClassifier.MAX_LOCATION_LENGTH)
        self.assertLessEqual(len(classification['display']), RedirectClassifier.MAX_DISPLAY_LENGTH)
        self.assertTrue(classification['location'].endswith('...'))

    def test_classifies_unusual_netloc_without_hostname_as_unknown(self):
        """Should keep unusual absolute redirect targets deterministic."""

        classification = self.classify(
            'https://localhost/start',
            302,
            'https://:443/odd',
        )

        self.assertEqual(classification['type'], 'unknown')
        self.assertEqual(classification['reason'], 'unclassified_redirect')
        self.assertFalse(classification['same_origin'])
        self.assertTrue(classification['cross_origin'])


class TestResponseProvider(unittest.TestCase):
    """TestResponseProvider class."""

    def make_response(self, status=200, body=b'', headers=None):
        return HTTPResponse(status=status, body=body, headers=headers or {})

    def test_get_redirect_url_handles_absolute_and_relative(self):
        """ResponseProvider._get_redirect_url() should resolve absolute and relative locations."""

        response = self.make_response(status=301, headers={'Location': 'https://other.test/path'})
        self.assertEqual(ResponseProvider._get_redirect_url('http://example.com/a', response), 'https://other.test/path')

        response = self.make_response(status=301, headers={'Location': '/login'})
        self.assertEqual(ResponseProvider._get_redirect_url('http://example.com/a', response), 'http://example.com/login')

    def test_detect_maps_builtin_statuses(self):
        """ResponseProvider.detect() should classify standard HTTP statuses."""

        provider = ResponseProvider(SimpleNamespace())
        self.assertEqual(provider.detect('http://example.com', self.make_response(status=200)), 'success')
        self.assertEqual(provider.detect('http://example.com', self.make_response(status=404)), 'failed')
        self.assertEqual(provider.detect('http://example.com', self.make_response(status=401)), 'auth')
        self.assertEqual(provider.detect('http://example.com', self.make_response(status=403)), 'forbidden')
        self.assertEqual(provider.detect('http://example.com', self.make_response(status=400)), 'bad')
        self.assertEqual(provider.detect('http://example.com', self.make_response(status=496)), 'certificate')

    def test_detect_uses_plugins_first(self):
        """ResponseProvider.detect() should prefer plugin verdicts."""

        provider = ResponseProvider(SimpleNamespace())
        plugin = MagicMock()
        plugin.process.return_value = 'indexof'
        provider._response_plugins.append(plugin)

        self.assertEqual(provider.detect('http://example.com', self.make_response(status=200)), 'indexof')

    def test_detect_handles_redirect_and_unknown_status(self):
        """ResponseProvider.detect() should classify redirects and reject unknown statuses."""

        provider = ResponseProvider(SimpleNamespace())
        redirect_response = self.make_response(status=301, headers={'Location': '/next'})
        self.assertEqual(provider.detect('http://example.com/path', redirect_response), 'redirect')

        with self.assertRaises(Exception):
            provider.detect('http://example.com', self.make_response(status=999))

    def test_get_content_size_uses_header_or_body(self):
        """ResponseProvider._get_content_size() should use either Content-Length or body length."""

        header_response = self.make_response(body=b'abc', headers={'Content-Length': '2048'})
        body_response = self.make_response(body=b'abc', headers={})

        self.assertEqual(ResponseProvider._get_content_size(header_response), '2KB')
        self.assertEqual(ResponseProvider._get_content_size(body_response), '3B')


class TestResponse(unittest.TestCase):
    """TestResponse class."""

    def make_cfg(self, **kwargs):
        base = {'is_sniff': False, 'sniffers': [], 'SUBDOMAINS_SCAN': 'subdomains', 'scan': 'directories'}
        base.update(kwargs)
        return SimpleNamespace(**base)

    def make_debug(self, level=0):
        return SimpleNamespace(
            level=level,
            debug_load_sniffer_plugin=MagicMock(),
            debug_response=MagicMock(),
            debug_request_uri=MagicMock(),
        )

    def make_response(self, status=200, body=b'', headers=None):
        return HTTPResponse(status=status, body=body, headers=headers or {})

    def test_init_loads_plugins_when_sniff_enabled(self):
        """Response should load sniff plugins when enabled."""

        cfg = self.make_cfg(is_sniff=True, sniffers=['file'])
        debug = self.make_debug(level=1)

        response = Response(cfg, debug, tpl=MagicMock())

        self.assertEqual(len(response._response_plugins), 1)
        debug.debug_load_sniffer_plugin.assert_called_once()

    def test_init_wraps_plugin_errors(self):
        """Response.__init__() should wrap plugin loading failures."""

        cfg = self.make_cfg(is_sniff=True, sniffers=['unknown'])
        with self.assertRaises(ResponseError):
            Response(cfg, self.make_debug(), tpl=MagicMock())

    def test_handle_attaches_request_url_for_file_sniffer_db_path_detection(self):
        """Response.handle() should expose request URL to response sniffers."""

        cfg = self.make_cfg(is_sniff=True, sniffers=['file'], scan='directories')
        debug = self.make_debug(level=0)
        response_handler = Response(cfg, debug, tpl=MagicMock())
        response = self.make_response(
            status=200,
            body=b'',
            headers={'Content-Length': '0'},
        )

        status, url, size, code = response_handler.handle(
            response,
            'http://example.com/assets/custom-cache.db',
            1,
            2,
            [],
        )

        self.assertEqual(
            (status, url, size, code),
            ('file', 'http://example.com/assets/custom-cache.db', '0B', '200')
        )
        self.assertEqual(response.opendoor_request_url, 'http://example.com/assets/custom-cache.db')

    def test_handle_directory_success_and_redirect(self):
        """Response.handle() should process success and redirect directory responses."""

        cfg = self.make_cfg(scan='directories')
        debug = self.make_debug(level=3)
        response_handler = Response(cfg, debug, tpl=MagicMock())

        response = self.make_response(status=200, body=b'ok', headers={'Content-Length': '2'})
        status, url, size, code = response_handler.handle(response, 'http://example.com/path', 1, 2, [])
        self.assertEqual((status, url, size, code), ('success', 'http://example.com/path', '2B', '200'))
        debug.debug_request_uri.assert_called()

        redirect = self.make_response(status=301, body=b'', headers={'Location': '/next', 'Content-Length': '0'})
        status, url, size, code = response_handler.handle(redirect, 'http://example.com/path', 1, 2, [])
        self.assertEqual((status, url, size, code), ('redirect', 'http://example.com/next', '0B', '301'))
        classification = getattr(redirect, 'opendoor_redirect_classification')
        self.assertEqual(classification['type'], 'internal')
        self.assertEqual(classification['display'], '/next')
        self.assertEqual(debug.debug_request_uri.call_args.kwargs['redirect_classification']['type'], 'internal')

    def test_handle_redirect_becomes_failed_when_ignored(self):
        """Response.handle() should downgrade redirects to failed when target path is ignored."""

        cfg = self.make_cfg(scan='directories')
        debug = self.make_debug(level=0)
        response_handler = Response(cfg, debug, tpl=MagicMock())

        redirect = self.make_response(status=301, body=b'', headers={'Location': '/admin', 'Content-Length': '0'})
        status, url, size, code = response_handler.handle(redirect, 'http://example.com/path', 1, 2, ['admin'])

        self.assertEqual((status, url, size, code), ('failed', 'http://example.com/admin', '0B', '301'))

    def test_handle_redirect_continues_when_classification_metadata_cannot_be_attached(self):
        """Response.handle() should tolerate frozen response objects."""

        class FrozenRedirectResponse(object):
            __slots__ = ('status', 'headers', 'data')

            def __init__(self):
                self.status = 302
                self.headers = {'Location': '/login', 'Content-Length': '0'}
                self.data = b''

            def get_redirect_location(self):
                return self.headers.get('Location')

        cfg = self.make_cfg(scan='directories')
        debug = self.make_debug(level=0)
        response_handler = Response(cfg, debug, tpl=MagicMock())
        redirect = FrozenRedirectResponse()

        status, url, size, code = response_handler.handle(
            redirect,
            'http://example.com/admin',
            1,
            2,
            [],
        )

        self.assertEqual((status, url, size, code), ('redirect', 'http://example.com/login', '0B', '302'))
        self.assertFalse(hasattr(redirect, 'opendoor_redirect_classification'))

    def test_handle_redirect_allows_empty_classifier_result(self):
        """Response.handle() should keep redirects when classifier returns no metadata."""

        cfg = self.make_cfg(scan='directories')
        debug = self.make_debug(level=0)
        response_handler = Response(cfg, debug, tpl=MagicMock())
        redirect = self.make_response(status=302, body=b'', headers={'Location': '/next', 'Content-Length': '0'})

        with patch('src.core.http.response.RedirectClassifier.classify', return_value={}):
            status, url, size, code = response_handler.handle(
                redirect,
                'http://example.com/start',
                1,
                2,
                [],
            )

        self.assertEqual((status, url, size, code), ('redirect', 'http://example.com/next', '0B', '302'))
        self.assertFalse(hasattr(redirect, 'opendoor_redirect_classification'))

    def test_debug_response_data_forwards_redirect_malware_and_endpoint_metadata(self):
        """Deferred runtime rendering should preserve new and existing metadata."""

        cfg = self.make_cfg(scan='directories')
        debug = self.make_debug(level=0)
        response_handler = Response(cfg, debug, tpl=MagicMock())

        redirect = self.make_response(status=302, headers={'Location': '/login'})
        redirect.opendoor_redirect_classification = {'type': 'login'}
        response_handler.debug_response_data(
            ('redirect', 'http://example.com/login', '0B', '302'),
            'http://example.com/admin',
            1,
            2,
            redirect,
        )
        self.assertEqual(
            debug.debug_request_uri.call_args.kwargs['redirect_classification'],
            {'type': 'login'},
        )

        malware = self.make_response(status=200)
        malware.opendoor_malware_detection = {'type': 'webshell'}
        response_handler.debug_response_data(
            ('malware', 'http://example.com/shell.php', '1KB', '200'),
            'http://example.com/shell.php',
            1,
            2,
            malware,
        )
        self.assertEqual(
            debug.debug_request_uri.call_args.kwargs['malware_detection'],
            {'type': 'webshell'},
        )

        endpoint = self.make_response(status=200)
        endpoint.opendoor_endpoint_detection = {'type': 'ajax'}
        response_handler.debug_response_data(
            ('endpoint', 'http://example.com/app.js', '1KB', '200'),
            'http://example.com/app.js',
            1,
            2,
            endpoint,
        )
        self.assertEqual(
            debug.debug_request_uri.call_args.kwargs['endpoint_detection'],
            {'type': 'ajax'},
        )

    def test_get_subdomain_ips_should_initialize_missing_cache(self):
        """Response._get_subdomain_ips() should recreate cache when instance state is missing."""

        cfg = self.make_cfg(scan='subdomains')
        debug = self.make_debug(level=0)
        response_handler = Response(cfg, debug, tpl=MagicMock())
        delattr(response_handler, '_Response__subdomain_ip_cache')

        with patch('src.core.http.response.Socket.get_ips_addresses', return_value='[127.0.0.1]') as ips_mock:
            actual = response_handler._get_subdomain_ips('http://api.example.com/admin')

        self.assertEqual(actual, '[127.0.0.1]')
        ips_mock.assert_called_once_with('api.example.com')

    def test_handle_subdomain_appends_ips_and_non_status_response(self):
        """Response.handle() should append IPs for subdomain scans and handle None-status responses."""

        cfg = self.make_cfg(scan='subdomains')
        debug = self.make_debug(level=0)
        response_handler = Response(cfg, debug, tpl=MagicMock())
        response = self.make_response(status=200, body=b'ok', headers={'Content-Length': '2'})

        with patch('src.core.http.response.Socket.get_ips_addresses', return_value='[127.0.0.1]'):
            status, url, size, code = response_handler.handle(response, 'http://sub.example.com', 1, 2, [])
        self.assertEqual((status, size, code), ('success', '2B', '200'))
        self.assertIn('[127.0.0.1]', url)

        no_status = SimpleNamespace(data=b'', headers={})
        with patch('src.core.http.response.Socket.get_ips_addresses', return_value=''):
            status, url, size, code = response_handler.handle(no_status, 'http://sub.example.com', 1, 2, [])
        self.assertEqual((status, url, size, code), ('failed', 'http://sub.example.com', '0B', '-'))

    def test_handle_wraps_detection_errors(self):
        """Response.handle() should wrap detection errors into ResponseError."""

        cfg = self.make_cfg(scan='directories')
        debug = self.make_debug(level=0)
        response_handler = Response(cfg, debug, tpl=MagicMock())
        response = self.make_response(status=999, body=b'', headers={})

        with self.assertRaises(ResponseError):
            response_handler.handle(response, 'http://example.com', 1, 2, [])

    def test_init_loads_plugins_without_debug_output_when_debug_disabled(self):
        """Response should load sniff plugins without debug output when debug level is zero."""

        cfg = self.make_cfg(is_sniff=True, sniffers=['file'])
        debug = self.make_debug(level=0)

        response = Response(cfg, debug, tpl=MagicMock())

        self.assertEqual(len(response._response_plugins), 1)
        debug.debug_load_sniffer_plugin.assert_not_called()

    def test_handle_keeps_header_debug_in_request_layer(self):
        """Response.handle() should not emit raw response headers itself."""

        class JsonableHeaders(dict):
            """Headers mapping whose items() result is JSON-serializable."""

            def items(self):
                """Return list items instead of dict_items."""

                return list(super().items())

        cfg = self.make_cfg(scan='directories')
        debug = self.make_debug(level=3)
        response_handler = Response(cfg, debug, tpl=MagicMock())
        response = SimpleNamespace(
            status=200,
            headers=JsonableHeaders({'Content-Length': '2'}),
            data=b'ok',
        )

        status, url, size, code = response_handler.handle(response, 'http://example.com/path', 1, 2, [])

        self.assertEqual((status, url, size, code), ('success', 'http://example.com/path', '2B', '200'))
        self.assertEqual(response.headers.get('Status'), '200')
        debug.debug_response.assert_not_called()

if __name__ == '__main__':
    unittest.main()
