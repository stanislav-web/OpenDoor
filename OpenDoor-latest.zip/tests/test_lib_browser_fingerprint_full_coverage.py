# -*- coding: utf-8 -*-

import unittest


from src.lib.browser.fingerprint import Fingerprint


class HeaderBag(dict):
    """Header bag with getlist support for cookie extraction tests."""

    def getlist(self, key):
        """
        Return header values as a list.

        :param str key: header name
        :return: list
        """

        value = self.get(key)
        if value is None:
            return []
        if isinstance(value, list):
            return value
        return [value]


class FakeConfig(object):
    """Minimal config stub for Fingerprint tests."""

    DEFAULT_SCHEME = 'http://'
    DEFAULT_HTTP_PORT = 80
    DEFAULT_SSL_PORT = 443

    def __init__(self, host='example.com', scheme='http://', port=80, prefix=''):
        """
        Init config.

        :param str host: target host
        :param str scheme: scheme
        :param int port: port
        :param str prefix: optional scan prefix
        """

        self.host = host
        self.scheme = scheme
        self.port = port
        self.prefix = prefix
        self._method = 'HEAD'


class FakeResponse(object):
    """Fake response object."""

    def __init__(self, status=200, data='', headers=None):
        """
        Init response.

        :param int status: status code
        :param str|bytes data: response body
        :param dict headers: response headers
        """

        self.status = status
        self.data = data.encode('utf-8') if isinstance(data, str) else data
        self.headers = HeaderBag(headers or {})


class FakeClient(object):
    """Fake HTTP client keyed by (method, url)."""

    def __init__(self, config, responses=None):
        """
        Init fake client.

        :param FakeConfig config: config instance
        :param dict responses: response mapping
        """

        self.config = config
        self.responses = responses or {}
        self.calls = []

    def request(self, url):
        """
        Return fake response for the current config method and URL.

        :param str url: target URL
        :return: FakeResponse | None
        """

        method = getattr(self.config, '_method', 'HEAD')
        self.calls.append((method, url))
        return self.responses.get((method, url))


class TestFingerprintFullCoverage(unittest.TestCase):
    """High-coverage tests for Fingerprint."""

    def make_detector(self, responses=None, host='example.com', scheme='http://', port=80, prefix=''):
        """
        Build a detector with fake config and client.

        :param dict responses: fake response mapping
        :param str host: target host
        :param str scheme: scheme
        :param int port: port
        :param str prefix: optional scan prefix
        :return: tuple[Fingerprint, FakeConfig, FakeClient]
        """

        config = FakeConfig(host=host, scheme=scheme, port=port, prefix=prefix)
        client = FakeClient(config=config, responses=responses or {})
        detector = Fingerprint(config=config, client=client)
        return detector, config, client

    def apply_case(
        self,
        body='',
        headers=None,
        cookies=None,
        generator='',
        probes=None,
        final_root_url='http://example.com/',
        not_found_status=0,
        not_found_body='',
        not_found_headers=None,
    ):
        """
        Apply detection rules once and return sorted candidates.

        :param str body: response body
        :param dict headers: response headers
        :param list cookies: cookie names
        :param str generator: generator meta
        :param dict probes: probe status mapping
        :param str final_root_url: final root URL
        :param int not_found_status: 404 probe status
        :param str not_found_body: 404 probe body
        :param dict not_found_headers: 404 probe headers
        :return: tuple[list, list]
        """

        detector, _, _ = self.make_detector()
        headers = headers or {}
        cookies = cookies or []
        probes = probes or {}
        not_found_headers = not_found_headers or {}

        detector._apply_detection_rules(
            body=body,
            body_lower=body.lower(),
            headers=headers,
            cookies=cookies,
            generator=generator,
            probe_statuses=probes,
            final_root_url=final_root_url,
            not_found_status=not_found_status,
            not_found_body=not_found_body,
            not_found_headers=not_found_headers,
        )

        return detector._build_candidates(), detector._build_infrastructure_candidates()

    def test_build_base_url_handles_default_and_custom_ports(self):
        """
        Fingerprint._build_base_url() should format URLs for default and custom ports.

        :return: None
        """

        detector, _, _ = self.make_detector()
        self.assertEqual(detector._build_base_url(), 'http://example.com/')

        detector_ssl, _, _ = self.make_detector(scheme='https://', port=443)
        self.assertEqual(detector_ssl._build_base_url(), 'https://example.com/')

        detector_custom, _, _ = self.make_detector(port=8080)
        self.assertEqual(detector_custom._build_base_url(), 'http://example.com:8080/')

        detector_prefixed, _, _ = self.make_detector(scheme='https://', port=443, prefix='/index.php/fd/')
        self.assertEqual(detector_prefixed._build_base_url(), 'https://example.com/index.php/fd/')

    def test_request_restores_original_method_after_override(self):
        """
        Fingerprint._request() should temporarily override config._method and restore it.

        :return: None
        """

        responses = {
            ('GET', 'http://example.com/'): FakeResponse(status=200, data='ok', headers={})
        }
        detector, config, client = self.make_detector(responses=responses)

        self.assertEqual(config._method, 'HEAD')
        response = detector._request('http://example.com/', method='GET')

        self.assertEqual(response.status, 200)
        self.assertEqual(client.calls, [('GET', 'http://example.com/')])
        self.assertEqual(config._method, 'HEAD')

    def test_follow_redirects_handles_chains_and_missing_location(self):
        """
        Fingerprint._follow_redirects() should follow redirect chains and stop without Location.

        :return: None
        """

        responses = {
            ('GET', 'http://example.com/'): FakeResponse(301, '', {'Location': '/home'}),
            ('GET', 'http://example.com/home'): FakeResponse(302, '', {'Location': '/final'}),
            ('GET', 'http://example.com/final'): FakeResponse(200, 'done', {}),
        }
        detector, _, _ = self.make_detector(responses=responses)

        initial = responses[('GET', 'http://example.com/')]
        response, final_url = detector._follow_redirects(initial, 'http://example.com/', method='GET', max_hops=3)

        self.assertEqual(response.status, 200)
        self.assertEqual(final_url, 'http://example.com/final')

        no_location = FakeResponse(301, '', {})
        response, final_url = detector._follow_redirects(no_location, 'http://example.com/', method='GET', max_hops=2)
        self.assertEqual(response.status, 301)
        self.assertEqual(final_url, 'http://example.com/')

    def test_extract_helpers_cover_headers_body_generator_and_cookies(self):
        """
        Fingerprint helper extractors should normalize headers, body, generator and cookies.

        :return: None
        """

        detector, _, _ = self.make_detector()
        response = FakeResponse(
            status=200,
            data='<meta name="generator" content="WordPress 6.8"><html></html>',
            headers={
                'Server': 'nginx',
                'Set-Cookie': ['a=1; Path=/', 'b=2; HttpOnly'],
            }
        )

        headers = detector._extract_headers(response)
        cookies = detector._extract_cookies(response)
        body = detector._extract_body(response)
        generator = detector._extract_generator(body)

        self.assertEqual(headers['server'], 'nginx')
        self.assertEqual(cookies, ['a', 'b'])
        self.assertIn('generator', body)
        self.assertEqual(generator, 'WordPress 6.8')

        plain_response = FakeResponse(status=200, data=b'bytes')
        self.assertEqual(detector._extract_body(plain_response), 'bytes')
        self.assertEqual(detector._extract_generator('<html></html>'), '')

    def test_probe_endpoints_collects_only_existing_probe_statuses(self):
        """
        Fingerprint._probe_endpoints() should collect statuses for existing fake responses.

        :return: None
        """

        responses = {
            ('HEAD', 'http://example.com/wp-json/'): FakeResponse(200, '', {}),
            ('HEAD', 'http://example.com/_next/static/'): FakeResponse(403, '', {}),
        }
        detector, _, _ = self.make_detector(responses=responses)

        probes = detector._probe_endpoints('http://example.com/')
        self.assertEqual(probes['/wp-json/'], 200)
        self.assertEqual(probes['/_next/static/'], 403)
        self.assertNotIn('/bitrix/', probes)


    def test_probe_not_found_signature_collects_framework_404_response(self):
        """
        Fingerprint._probe_not_found_signature() should return status, body and headers for a missing route.

        :return: None
        """

        responses = {
            ('GET', 'http://example.com{0}'.format(Fingerprint.NOT_FOUND_PROBE_PATH)): FakeResponse(
                404,
                '{"message":"Cannot GET /.well-known/missing-resource.txt","error":"Not Found","statusCode":404}',
                {'X-Powered-By': 'NestJS'},
            ),
        }
        detector, _, _ = self.make_detector(responses=responses)

        status, body, headers = detector._probe_not_found_signature('http://example.com/')

        self.assertEqual(status, 404)
        self.assertIn('Cannot GET', body)
        self.assertEqual(headers['x-powered-by'], 'NestJS')

    def test_detect_returns_default_when_root_response_is_missing(self):
        """
        Fingerprint.detect() should return DEFAULT_RESULT when root response is unavailable.

        :return: None
        """

        detector, _, _ = self.make_detector(responses={})
        result = detector.detect()

        self.assertEqual(result['category'], 'custom')
        self.assertEqual(result['name'], 'Unknown custom stack')
        self.assertEqual(result['infrastructure']['provider'], 'unknown')

    def test_detect_returns_custom_for_weak_application_signal(self):
        """
        Fingerprint.detect() should return custom for weak app-only signals.

        :return: None
        """

        responses = {
            ('GET', 'http://example.com/'): FakeResponse(
                200,
                '<html><body><div id="root"></div></body></html>',
                {'Server': 'nginx'}
            )
        }
        detector, _, _ = self.make_detector(responses=responses)
        result = detector.detect()

        self.assertEqual(result['category'], 'custom')
        self.assertEqual(result['name'], 'Unknown custom stack')
        self.assertGreaterEqual(len(result['candidates']), 1)

    def test_detect_returns_infrastructure_when_application_is_unknown(self):
        """
        Fingerprint.detect() should preserve infrastructure signals even when app is unknown.

        :return: None
        """

        responses = {
            ('GET', 'http://example.com/'): FakeResponse(
                200,
                '<html><body>plain site</body></html>',
                {
                    'Server': 'cloudflare',
                    'CF-Ray': 'abc123',
                    'CF-Cache-Status': 'HIT',
                }
            )
        }
        detector, _, _ = self.make_detector(responses=responses)
        result = detector.detect()

        self.assertEqual(result['category'], 'custom')
        self.assertEqual(result['infrastructure']['provider'], 'Cloudflare')
        self.assertGreaterEqual(result['infrastructure']['confidence'], 90)

    def test_detect_strong_wordpress_on_aws_cloudfront(self):
        """
        Fingerprint.detect() should detect both strong application and infrastructure signatures.

        :return: None
        """

        responses = {
            ('GET', 'http://example.com/'): FakeResponse(
                301,
                '',
                {'Location': '/home'}
            ),
            ('GET', 'http://example.com/home'): FakeResponse(
                200,
                (
                    '<html><head><meta name="generator" content="WordPress 6.8"></head>'
                    '<body>'
                    '<link href="/wp-content/themes/x/style.css">'
                    '<script src="/wp-includes/js/jquery.js"></script>'
                    '</body></html>'
                ),
                {
                    'Server': 'CloudFront',
                    'Via': '1.1 edge.cloudfront.net (CloudFront)',
                    'X-Amz-Cf-Id': 'cf-id',
                    'X-Amz-Cf-Pop': 'WAW50-C1',
                }
            ),
            ('HEAD', 'http://example.com/home/wp-json/'): FakeResponse(200, '', {}),
            ('HEAD', 'http://example.com/home/wp-login.php'): FakeResponse(200, '', {}),
            ('HEAD', 'http://example.com/home/xmlrpc.php'): FakeResponse(405, '', {}),
        }

        detector, _, _ = self.make_detector(responses=responses)
        result = detector.detect()

        self.assertEqual(result['category'], 'cms')
        self.assertEqual(result['candidates'][0]['name'], 'WordPress')
        self.assertEqual(result['infrastructure']['provider'], 'AWS CloudFront')
        self.assertGreaterEqual(result['confidence'], 90)

    def test_build_infrastructure_result_and_confidence_clamps(self):
        """
        Fingerprint infrastructure result builder and confidence clamp should behave predictably.

        :return: None
        """

        detector, _, _ = self.make_detector()

        unknown = detector._build_infrastructure_result([])
        self.assertEqual(unknown['provider'], 'unknown')
        self.assertEqual(unknown['confidence'], 0)

        self.assertEqual(detector._calculate_confidence(0, 0), 35)
        self.assertEqual(detector._calculate_confidence(100, 50), 98)


    def test_helper_edge_cases_cover_fallback_branches(self):
        """
        Fingerprint helper methods should handle secondary candidates and fallback parsing branches.

        :return: None
        """

        class DictWithoutItems(dict):
            """Dictionary that hides items() to exercise the isinstance(dict) branch."""

            def __getattribute__(self, name):
                if name == 'items':
                    raise AttributeError(name)
                return dict.__getattribute__(self, name)

        class HeadersWithoutItems(object):
            """Header object without items() to exercise the empty fallback branch."""


        class BrokenHeaderBag(object):
            """Cookie bag with a failing getlist() implementation."""

            def getlist(self, key):
                raise RuntimeError(key)

        detector, _, _ = self.make_detector()

        headers = detector._extract_headers(FakeResponse(status=200, headers=DictWithoutItems({'Server': 'nginx'})))
        self.assertEqual(headers['server'], 'nginx')

        response_without_items = type('ResponseNoItems', (), {'status': 200, 'data': b'', 'headers': HeadersWithoutItems()})()
        headers = detector._extract_headers(response_without_items)
        self.assertEqual(headers, {})

        self.assertEqual(detector._extract_body(FakeResponse(status=200, data=None)), '')
        self.assertEqual(detector._extract_body(FakeResponse(status=200, data='plain-string')), 'plain-string')

        broken_cookie_response = type('BrokenCookieResponse', (), {'status': 200, 'data': b'', 'headers': BrokenHeaderBag()})()
        cookies = detector._extract_cookies(broken_cookie_response)
        self.assertEqual(cookies, [])

        cookies = detector._extract_cookies(FakeResponse(status=200, headers=HeaderBag({'Set-Cookie': ['flagonly; Path=/', '=empty; Path=/', 'real=1; Path=/']})))
        self.assertEqual(cookies, ['real'])

        redirect_detector, _, _ = self.make_detector()
        response, final_url = redirect_detector._follow_redirects(
            FakeResponse(status=302, headers={'Location': '/lost'}),
            'http://example.com/',
            method='GET',
            max_hops=1,
        )
        self.assertIsNone(response)
        self.assertEqual(final_url, 'http://example.com/lost')

        responses = {
            ('GET', 'http://example.com/'): FakeResponse(
                200,
                '<html><head><meta name="generator" content="WordPress 6.8"></head>'
                '<body><link href="/wp-content/plugins/woocommerce/assets/app.css">'
                '<script src="/wp-includes/js/jquery.js"></script>woocommerce-notices-wrapper</body></html>',
                {'Server': 'cloudflare', 'CF-Ray': 'abc', 'CF-Cache-Status': 'HIT', 'X-Served-By': 'cache-fra', 'X-Fastly-Request-Id': 'fastly'}
            ),
            ('HEAD', 'http://example.com/wp-json/'): FakeResponse(200, '', {}),
            ('HEAD', 'http://example.com/wp-login.php'): FakeResponse(200, '', {}),
            ('HEAD', 'http://example.com/xmlrpc.php'): FakeResponse(405, '', {}),
        }
        detect_detector, _, _ = self.make_detector(responses=responses)
        result = detect_detector.detect()

        self.assertEqual(result['candidates'][0]['name'], 'WordPress')
        self.assertGreater(len(result['candidates']), 1)
        self.assertGreater(len(result['infrastructure']['candidates']), 1)

        top_two = detect_detector._build_infrastructure_candidates()[:2]
        built = detect_detector._build_infrastructure_result(top_two)
        self.assertEqual(built['provider'], top_two[0]['provider'])
        self.assertGreaterEqual(built['confidence'], 35)

    def test_application_matrix_hits_popular_cms_framework_and_builder_rules(self):
        """
        Fingerprint._apply_detection_rules() should classify a wide matrix of application signatures.

        :return: None
        """

        cases = [
            {
                'name': 'WordPress',
                'category': 'cms',
                'generator': 'WordPress 6.8',
                'body': '<link href="/wp-content/themes/x.css"><script src="/wp-includes/js/jquery.js"></script>',
                'cookies': ['wordpress_logged_in_123', 'wp-settings-1'],
                'probes': {'/wp-json/': 200, '/wp-login.php': 200, '/xmlrpc.php': 405},
            },
            {
                'name': 'Drupal',
                'category': 'cms',
                'generator': 'Drupal 10',
                'body': '<script>var drupalSettings={};</script><img src="/sites/default/files/a.png">',
                'probes': {'/user/login': 200},
            },
            {
                'name': 'Joomla',
                'category': 'cms',
                'generator': 'Joomla! - Open Source Content Management',
                'body': '<script src="/media/system/js/core.js"></script><a href="/index.php?option=com_users">x</a>',
                'probes': {'/administrator/': 403},
            },
            {
                'name': 'Magento',
                'category': 'ecommerce',
                'body': '<script src="/static/version1/frontend.js"></script><script src="/skin/frontend/base.js"></script>magento_ui/js mage/cookies <input name="form_key">',
            },
            {
                'name': 'Shopify',
                'category': 'ecommerce',
                'body': '<script src="https://cdn.shopify.com/s/files/a.js"></script><script>Shopify.theme={};</script><div class="shopify-section"></div>',
                'headers': {'x-shopid': '123'},
                'cookies': ['_shopify_y'],
            },
            {
                'name': 'Bitrix',
                'category': 'cms',
                'body': '<script src="/bitrix/cache/main.js"></script><script>window.BX={}; BX.message({}); BX.setCssList([]);</script>',
                'cookies': ['bitrix_sessid'],
                'probes': {'/bitrix/': 200},
            },
            {
                'name': 'Wix',
                'category': 'sitebuilder',
                'body': '<script src="https://static.parastorage.com/x.js"></script><img src="https://static.wixstatic.com/media/x.png">wix-code-sdk wix-image',
                'headers': {'x-wix-request-id': 'req'},
            },
            {
                'name': 'Tilda',
                'category': 'sitebuilder',
                'body': '<div class="tilda-page tilda-blocks-123 tilda-pub-456"></div><script src="https://static.tildacdn.com/js/tilda.js"></script>',
            },
            {
                'name': 'Webflow',
                'category': 'sitebuilder',
                'generator': 'Webflow',
                'body': '<html data-wf-page="abc" data-wf-site="xyz"><link href="/css/webflow.css"><div class="w-webflow-badge"></div>',
            },
            {
                'name': 'Squarespace',
                'category': 'sitebuilder',
                'generator': 'Squarespace',
                'body': '<script src="https://static1.squarespace.com/x.js"></script><div class="sqs-block-content"></div>',
            },
            {
                'name': 'Ghost',
                'category': 'cms',
                'generator': 'Ghost 5.0',
                'body': '<script src="/ghost/api/content/posts/"></script><div class="ghost-content casper"></div>',
                'probes': {'/ghost/api/content/': 403},
            },
            {
                'name': 'WooCommerce',
                'category': 'ecommerce',
                'body': '<script src="/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.js"></script>?wc-ajax=get_refreshed_fragments<div class="woocommerce-notices-wrapper"></div><a class="add_to_cart_button">Buy</a>',
                'cookies': ['woocommerce_cart_hash', 'wp_woocommerce_session_abc'],
            },
            {
                'name': 'OpenCart',
                'category': 'ecommerce',
                'body': '<link href="/catalog/view/theme/default/stylesheet/stylesheet.css"><a href="index.php?route=common/home">Home</a>',
                'cookies': ['ocsessid'],
                'probes': {'/catalog/view/theme/': 403},
            },
            {
                'name': 'PrestaShop',
                'category': 'ecommerce',
                'body': '<script>var prestashop = {};</script><link href="/themes/classic/assets/theme.css"><script src="/modules/ps_shoppingcart/cart.js"></script>',
                'cookies': ['prestashop-abc'],
            },
            {
                'name': 'TYPO3',
                'category': 'cms',
                'body': '<script>TYPO3.settings = {};</script><link href="/typo3conf/ext/site.css"><script src="/typo3temp/assets/app.js"></script>',
                'probes': {'/typo3/': 403},
            },
            {
                'name': 'Strapi',
                'category': 'framework',
                'body': '<script>window.strapi = true;</script><script src="/admin/init"></script><img src="/uploads/logo.png">',
                'headers': {'x-powered-by': 'Strapi'},
                'probes': {'/admin/init': 200, '/admin': 302, '/uploads/': 200},
            },
            {
                'name': 'MkDocs',
                'category': 'static',
                'generator': 'MkDocs 1.6',
                'body': '<script>var mkdocs_page_name = "Home"; var mkdocs_page_input_path = "index.md";</script>',
            },
            {
                'name': 'Jekyll',
                'category': 'static',
                'generator': 'Jekyll v4.4.1',
                'body': '<!-- Begin Jekyll SEO tag v2.8.0 -->',
            },
            {
                'name': 'Hugo',
                'category': 'static',
                'generator': 'Hugo 0.145.0',
            },
            {
                'name': 'VitePress',
                'category': 'static',
                'body': '<div class="vitepress-theme"><div class="VPContent"></div><nav class="VPNav"></nav></div>',
            },
            {
                'name': 'Docusaurus',
                'category': 'static',
                'generator': 'Docusaurus v3',
                'body': '<div data-rh="true"></div><script src="/assets/js/runtime~main.js"></script>docusaurus',
            },
            {
                'name': 'Next.js',
                'category': 'framework',
                'body': '<div id="__next"></div><span next-head-count="3"></span><script id="__NEXT_DATA__">{}</script><script src="/_next/static/chunks/main.js"></script>',
                'probes': {'/_next/static/': 403},
            },
            {
                'name': 'Nuxt',
                'category': 'framework',
                'body': '<div id="__nuxt"></div><script>window.__NUXT__={};</script><script src="/_nuxt/app.js"></script>',
                'probes': {'/_nuxt/': 403},
            },
            {
                'name': 'Gatsby',
                'category': 'framework',
                'body': '<script src="/page-data/sq/d/123.json"></script><script src="/webpack-runtime.js"></script><script>window.___gatsby={};</script>gatsby-script-loader',
            },
            {
                'name': 'Astro',
                'category': 'framework',
                'body': '<astro-island></astro-island><script src="/_astro/index.js"></script>',
            },
            {
                'name': 'Remix',
                'category': 'framework',
                'body': '<script>window.__remixContext={}; window.__remixRoute=true;</script><script src="/build/entry.client.js"></script>',
                'probes': {'/build/': 200},
            },
            {
                'name': 'Angular',
                'category': 'framework',
                'body': '<app-root ng-version="17.0.0"></app-root>',
            },
            {
                'name': 'React',
                'category': 'framework',
                'body': '<div id="root" data-reactroot=""></div>',
            },
            {
                'name': 'Vue',
                'category': 'framework',
                'body': '<div data-server-rendered="true"></div>',
            },
            {
                'name': 'SvelteKit',
                'category': 'framework',
                'body': '<div data-sveltekit-preload-data="hover">sveltekit</div>',
            },
            {
                'name': 'Laravel',
                'category': 'framework',
                'body': '<meta name="csrf-token" content="x">laravel',
                'cookies': ['laravel_session', 'xsrf-token'],
            },
            {
                'name': 'Django',
                'category': 'framework',
                'body': '<input type="hidden" name="csrfmiddlewaretoken" value="x">',
                'cookies': ['csrftoken', 'sessionid'],
            },
            {
                'name': 'Flask',
                'category': 'framework',
                'headers': {'x-powered-by': 'Flask', 'server': 'Werkzeug/3.0'},
            },
            {
                'name': 'Ruby on Rails',
                'category': 'framework',
                'body': '<meta name="csrf-param" content="authenticity_token"><meta name="csrf-token" content="x">',
                'cookies': ['_rails_session'],
            },
            {
                'name': 'Express',
                'category': 'framework',
                'headers': {'x-powered-by': 'Express'},
                'cookies': ['connect.sid'],
                'not_found_status': 404,
                'not_found_body': 'Cannot GET /.well-known/missing-resource.txt',
            },
            {
                'name': 'NestJS',
                'category': 'framework',
                'probes': {'/swagger': 200, '/openapi.json': 200},
                'not_found_status': 404,
                'not_found_body': '{"message":"Cannot GET /.well-known/missing-resource.txt","error":"Not Found","statusCode":404}',
                'not_found_headers': {'x-powered-by': 'NestJS'},
            },
            {
                'name': 'Fastify',
                'category': 'framework',
                'headers': {'server': 'fastify'},
                'not_found_status': 404,
                'not_found_body': 'Route GET:/.well-known/missing-resource.txt not found',
            },
            {
                'name': 'FastAPI',
                'category': 'framework',
                'headers': {'server': 'uvicorn'},
                'probes': {'/openapi.json': 200, '/docs': 200, '/redoc': 200},
                'not_found_status': 404,
                'not_found_body': '{"detail":"Not Found"}',
            },
            {
                'name': 'Koa',
                'category': 'framework',
                'headers': {'x-powered-by': 'Koa'},
                'cookies': ['koa:sess'],
            },
            {
                'name': 'Hapi',
                'category': 'framework',
                'headers': {'x-powered-by': 'hapi'},
                'not_found_status': 404,
                'not_found_body': '{"statusCode":404,"error":"Not Found","message":"Not Found"}',
            },
            {
                'name': 'Symfony',
                'category': 'framework',
                'headers': {'x-powered-by': 'Symfony'},
                'cookies': ['sf_redirect'],
            },
            {
                'name': 'ASP.NET',
                'category': 'framework',
                'body': '<input type="hidden" name="__VIEWSTATE" value="x"><input type="hidden" name="__EVENTVALIDATION" value="y">',
                'headers': {'x-powered-by': 'ASP.NET', 'x-aspnet-version': '4.0'},
                'cookies': ['asp.net_sessionid'],
            },
            {
                'name': 'Spring',
                'category': 'framework',
                'body': '<meta name="generator" content="thymeleaf">thymeleaf spring',
                'cookies': ['jsessionid'],
            },
            {
                'name': 'Phoenix',
                'category': 'framework',
                'body': '<input type="hidden" name="_csrf_token" value="x">phoenix _buildinfo',
                'cookies': ['_app_key'],
            },

            {
                'name': 'Nextcloud',
                'category': 'cms',
                'generator': 'Nextcloud',
                'body': '<div class="nextcloud"><img src="/apps/files/img/app.svg"><link href="/ocs-provider/"></div>',
                'probes': {'/status.php': 200, '/remote.php/dav/': 401},
            },
            {
                'name': 'ownCloud',
                'category': 'cms',
                'generator': 'ownCloud',
                'body': '<script src="/core/js/oc.js"></script><img src="/core/img/actions/share.svg"><div>ownCloud</div>',
                'probes': {'/status.php': 200, '/ocs/v1.php/cloud/capabilities?format=json': 401},
            },
            {
                'name': 'phpMyAdmin',
                'category': 'cms',
                'body': '<html><body>phpMyAdmin<form><input name="pma_username"></form><link href="/themes/pmahomme/css/theme.css"><div id="pma_navigation"></div></body></html>',
                'cookies': ['pma_lang', 'pma_collation_connection'],
            },
            {
                'name': 'phpBB',
                'category': 'cms',
                'body': '<link href="/styles/prosilver/theme/stylesheet.css"><a href="viewtopic.php?t=1">Topic</a><a href="viewforum.php?f=2">Forum</a><div>phpBB prosilver</div>',
                'cookies': ['phpbb3_abcd_u', 'phpbb3_abcd_k'],
            },
            {
                'name': 'Umbraco',
                'category': 'cms',
                'body': '<script>Umbraco.Sys.ServerVariables = {};</script><script src="/umbraco/assets/app.js"></script><umb-app></umb-app>',
                'probes': {'/umbraco/': 302},
            },
            {
                'name': 'Concrete CMS',
                'category': 'cms',
                'generator': 'Concrete CMS',
                'body': '<html><body>'
                        '<link href="/concrete/css/app.css">'
                        '<script src="/concrete/js/jquery.js"></script>'
                        '<div class="ccm-page"><div class="ccm-block-page-title-byline"></div></div>'
                        '</body></html>',
            },
            {
                'name': 'Contao',
                'category': 'cms',
                'generator': 'Contao Open Source CMS',
                'body': '<html><body>'
                        '<link href="/bundles/contaocore/theme.css">'
                        '<img src="/files/contao/logo.svg">'
                        '<div>contao</div>'
                        '</body></html>',
                'probes': {'/contao/': 302},
            },
            {
                'name': 'GravCMS',
                'category': 'cms',
                'generator': 'GravCMS',
                'body': '<html><body>'
                        '<link href="/user/themes/quark/css/custom.css">'
                        '<script src="/system/assets/jquery/jquery-2.x.min.js"></script>'
                        '<div class="grav-language-select">en</div>'
                        '</body></html>',
            },
            {
                'name': 'MediaWiki',
                'category': 'cms',
                'generator': 'MediaWiki 1.41',
                'body': '<html><body>'
                        '<link href="/w/resources/assets/wiki.png">'
                        '<div class="mw-body"><h1 class="mw-page-title-main">Main Page</h1></div>'
                        '</body></html>',
                'probes': {'/api.php': 200},
            },
            {
                'name': 'Open Journal Systems',
                'category': 'cms',
                'generator': 'Open Journal Systems 3.2.1.2',
                'body': '<html><body>'
                        '<div class="pkp_structure_page pkp_page_index"></div>'
                        '<link href="/plugins/themes/default/styles/index.less">'
                        '<script src="/lib/pkp/js/lib/jquery/plugins/jquery.tag-it.js"></script>'
                        '<a href="/index.php/fd/login">Login</a>'
                        '</body></html>',
                'probes': {'/index.php/index/login': 302},
            },
            {
                'name': 'Moodle',
                'category': 'cms',
                'generator': 'Moodle',
                'body': '<html><body>'
                        '<script src="/lib/javascript.php/123/lib/javascript-static.js"></script>'
                        '<img src="/theme/image.php/boost/core/123/u/f1">'
                        '<div class="moodle-dialogue-base">moodle</div>'
                        '</body></html>',
                'cookies': ['moodlesession'],
                'probes': {'/login/index.php': 200},
            },
            {
                'name': 'Craft CMS',
                'category': 'cms',
                'generator': 'Craft CMS',
                'body': '<html><body>'
                        '<link href="/cpresources/abc123/app.css">'
                        '<script src="/cpresources/abc123/app.js"></script>'
                        '<div>craftcms</div>'
                        '</body></html>',
                'cookies': ['craftsessionid', 'craft_csrf_token'],
                'probes': {'/admin': 302},
            },
            {
                'name': 'Pimcore',
                'category': 'cms',
                'generator': 'Pimcore',
                'body': '<html><body>'
                        '<link href="/bundles/pimcoreadmin/css/admin.css">'
                        '<script src="/bundles/pimcorestatic6/js/pimcore.js"></script>'
                        '<a href="/admin/login">Admin</a><div>pimcore</div>'
                        '</body></html>',
                'probes': {'/admin': 302},
            },
            {
                'name': 'Discourse',
                'category': 'cms',
                'generator': 'Discourse',
                'body': '<html><body>'
                        '<div class="discourse-topic"></div>'
                        '<div class="discourse-post"></div>'
                        '<script data-discourse-setup="true"></script>'
                        '<img src="/uploads/default/original/1X/test.png">'
                        '</body></html>',
                'cookies': ['_forum_session'],
            },
            {
                'name': 'Matomo',
                'category': 'cms',
                'generator': 'Matomo',
                'body': '<html><body>'
                        '<script>var _paq = window._paq || []; _paq.push(["trackPageView"]);</script>'
                        '<script src="/matomo.js"></script>'
                        '<img src="/matomo.php?idsite=1&amp;rec=1">'
                        '</body></html>',
                'cookies': ['_pk_id', '_pk_ses'],
            },
            {
                'name': 'Bludit',
                'category': 'cms',
                'generator': 'Bludit',
                'body': '<html><body>'
                        '<link href="/bl-themes/blog/style.css">'
                        '<img src="/bl-content/uploads/logo.png">'
                        '<div>bludit</div>'
                        '</body></html>',
                'probes': {'/admin': 302},
            },
            {
                'name': 'MODX',
                'category': 'cms',
                'generator': 'MODX Revolution',
                'body': '<html><body>'
                        '<link href="/assets/components/example/css/web.css">'
                        '<script src="/assets/components/example/js/web.js"></script>'
                        '<a href="/manager/">manager</a><div>modx revolution</div>'
                        '</body></html>',
                'probes': {'/manager/': 302},
            },
            {
                'name': 'Neos',
                'category': 'cms',
                'generator': 'Neos',
                'body': '<html><body>'
                        '<link href="/_Resources/Static/Packages/Vendor.Site/app.css">'
                        '<script src="/_Resources/Static/Packages/Vendor.Site/app.js"></script>'
                        '<div class="neos-contentcollection">neos</div>'
                        '</body></html>',
            },
            {
                'name': 'Bolt CMS',
                'category': 'cms',
                'generator': 'Bolt',
                'headers': {'x-powered-by': 'Bolt'},
                'body': '<html><body><a href="/bolt">Backend</a><div>bolt cms</div></body></html>',
                'probes': {'/bolt': 302},
            },
            {
                'name': 'Directus',
                'category': 'cms',
                'body': '<html><body>'
                        '<title>Directus</title>'
                        '<script src="/admin/assets/index.abc123.js"></script>'
                        '<link href="/admin/assets/index.abc123.css" rel="stylesheet">'
                        '<div>directus</div>'
                        '</body></html>',
                'probes': {'/admin': 302},
            },
            {
                'name': 'nopCommerce',
                'category': 'ecommerce',
                'body': '<footer>Powered by nopCommerce</footer><div class="nopcommerce-store"></div>',
                'probes': {'/admin': 302},
            },
            {
                'name': 'Shopware',
                'category': 'ecommerce',
                'generator': 'Shopware',
                'body': '<html><body><script>var shopware = {};</script>'
                        '<link href="/theme/frontend/default/css/all.css">'
                        '<div data-url="/widgets/index/menu"></div>'
                        '<meta name="csrf-token" content="x"></body></html>',
                'probes': {'/backend': 302},
            },
            {
                'name': 'OctoberCMS',
                'category': 'cms',
                'generator': 'OctoberCMS',
                'body': '<html><body>'
                        '<link href="/themes/demo/assets/css/theme.css">'
                        '<script src="/modules/system/assets/js/framework.js"></script>'
                        '<div>October CMS</div>'
                        '</body></html>',
                'cookies': ['october_session'],
                'probes': {'/backend': 302},
            },
            {
                'name': 'Sitecore',
                'category': 'cms',
                'generator': 'Sitecore Experience Platform',
                'headers': {'x-sitecore': 'true'},
                'body': '<html><body><script>window.Sitecore = { context: {} };</script>'
                        '<link href="/sitecore/shell/client/Applications/Launchpad.css">'
                        '<input type="hidden" name="sc_site" value="website">'
                        '</body></html>',
                'cookies': ['sitecore_device'],
            },
            {
                'name': 'Microsoft SharePoint',
                'category': 'cms',
                'generator': 'Microsoft SharePoint',
                'headers': {
                    'microsoftsharepointteamservices': '16.0.0.0000',
                    'x-sharepointhealthscore': '0',
                },
                'body': '<html><body><script src="/_layouts/15/sp.js"></script>'
                        '<div class="ms-webpartzone-cell"></div></body></html>',
                'cookies': ['fedauth', 'rtfa'],
            },
            {
                'name': 'BigCommerce',
                'category': 'ecommerce',
                'generator': 'BigCommerce',
                'body': '<html><body><script src="https://cdn11.bigcommerce.com/store/hash/stencil.js"></script>'
                        '<script>window.stencilUtils = {};</script></body></html>',
            },
            {
                'name': 'RoundCube Webmail',
                'category': 'cms',
                'generator': 'RoundCube Webmail',
                'body': '<html><body><div id="rcmail"></div>'
                        '<script src="/program/js/app.js"></script></body></html>',
                'cookies': ['roundcube_sessid'],
            },
        ]

        for case in cases:
            with self.subTest(case=case['name']):
                candidates, _ = self.apply_case(
                    body=case.get('body', ''),
                    headers=case.get('headers', {}),
                    cookies=case.get('cookies', []),
                    generator=case.get('generator', ''),
                    probes=case.get('probes', {}),
                    not_found_status=case.get('not_found_status', 0),
                    not_found_body=case.get('not_found_body', ''),
                    not_found_headers=case.get('not_found_headers', {}),
                )

                self.assertGreater(len(candidates), 0)
                self.assertEqual(candidates[0]['name'], case['name'])
                self.assertEqual(candidates[0]['category'], case['category'])

    def test_infrastructure_matrix_hits_aws_and_other_providers(self):
        """
        Fingerprint._apply_detection_rules() should classify a broad infrastructure matrix.

        :return: None
        """

        cases = [
            {
                'provider': 'AWS CloudFront',
                'headers': {
                    'server': 'CloudFront',
                    'via': '1.1 edge.cloudfront.net (CloudFront)',
                    'x-cache': 'Miss from cloudfront',
                    'x-amz-cf-id': 'cf-id',
                    'x-amz-cf-pop': 'WAW50-C1',
                },
            },
            {
                'provider': 'AWS S3',
                'headers': {
                    'server': 'AmazonS3',
                    'x-amz-request-id': 'rid',
                    'x-amz-id-2': 'id2',
                },
                'url': 'https://bucket.s3.amazonaws.com/',
            },
            {
                'provider': 'AWS ELB / ALB',
                'headers': {
                    'server': 'awselb/2.0',
                    'x-amzn-trace-id': 'Root=1-abc',
                },
            },
            {
                'provider': 'AWS API Gateway',
                'headers': {
                    'x-amz-apigw-id': 'gw',
                },
            },
            {
                'provider': 'AWS Amplify',
                'headers': {
                    'x-amplify-id': 'amp',
                },
            },
            {
                'provider': 'Plesk',
                'headers': {
                    'server': 'nginx',
                    'x-powered-by': 'PleskLin',
                },
            },
            {
                'provider': 'Cloudflare',
                'headers': {
                    'server': 'cloudflare',
                    'cf-ray': 'abc',
                    'cf-cache-status': 'HIT',
                },
            },
            {
                'provider': 'QRATOR',
                'headers': {
                    'server': 'QRATOR',
                },
            },
            {
                'provider': 'QRATOR',
                'headers': {
                    'x-qrator-requestid': 'f4b16a6bf0bcc8bebc394a2824d5d569',
                    'x-q-domid': '12345',
                },
            },
            {
                'provider': 'Vercel',
                'headers': {
                    'server': 'Vercel',
                    'x-vercel-id': 'cdg1::abc',
                    'x-vercel-cache': 'HIT',
                },
            },
            {
                'provider': 'Netlify',
                'headers': {
                    'server': 'Netlify',
                    'x-nf-request-id': 'nf-id',
                },
            },
            {
                'provider': 'GitHub Pages',
                'headers': {
                    'server': 'GitHub-Pages',
                    'x-github-request-id': 'gh',
                },
            },
            {
                'provider': 'GitLab Pages',
                'headers': {
                    'server': 'GitLab Pages',
                },
            },
            {
                'provider': 'Heroku',
                'headers': {
                    'x-request-id': 'rid',
                    'via': '1.1 vegur, 1.1 heroku-router',
                    'x-heroku-dynos-in-use': '1',
                },
            },
            {
                'provider': 'Microsoft Azure',
                'headers': {
                    'x-azure-ref': 'az',
                    'x-ms-request-id': 'ms-id',
                },
                'url': 'https://example.azurewebsites.net/',
            },
            {
                'provider': 'Google Cloud',
                'headers': {
                    'x-cloud-trace-context': 'trace',
                },
            },
            {
                'provider': 'Google Cloud / Google Frontend',
                'headers': {
                    'server': 'gse',
                },
            },
            {
                'provider': 'Google Cloud Run',
                'headers': {},
                'url': 'https://demo-12345.run.app/',
            },
            {
                'provider': 'Google App Engine',
                'headers': {},
                'url': 'https://demo.appspot.com/',
            },
            {
                'provider': 'Fastly',
                'headers': {
                    'x-served-by': 'cache-fra-etou8220030-FRA',
                    'x-fastly-request-id': 'fastly-id',
                },
            },
            {
                'provider': 'Akamai',
                'headers': {
                    'server': 'AkamaiGHost',
                    'akamai-grn': '0.123',
                },
            },
            {
                'provider': 'OpenResty',
                'headers': {
                    'server': 'openresty',
                },
            },
        ]

        for case in cases:
            with self.subTest(case=case['provider']):
                _, infra_candidates = self.apply_case(
                    headers=case.get('headers', {}),
                    final_root_url=case.get('url', 'http://example.com/'),
                )

                self.assertGreater(len(infra_candidates), 0)
                self.assertEqual(infra_candidates[0]['provider'], case['provider'])

    def test_qrator_keeps_application_detection_and_wins_exact_server_edge(self):
        """
        QRATOR should be classified as infrastructure without replacing CMS/runtime signals.

        :return: None
        """

        candidates, infra_candidates = self.apply_case(
            body='<html><script>window.BX = {};</script><a href="/bitrix/">Bitrix</a></html>',
            headers={
                'server': 'QRATOR',
                'x-powered-cms': 'Bitrix Site Manager',
            },
            cookies=['bitrix_sessid'],
            probes={'/bitrix/': 200},
        )

        self.assertGreater(len(candidates), 0)
        self.assertEqual(candidates[0]['name'], 'Bitrix')
        self.assertGreater(len(infra_candidates), 0)
        self.assertEqual(infra_candidates[0]['provider'], 'QRATOR')

    def test_qrator_supporting_headers_do_not_override_stronger_edge_provider(self):
        """
        Weak QRATOR support headers should not hide stronger edge infrastructure evidence.

        :return: None
        """

        _, infra_candidates = self.apply_case(
            headers={
                'server': 'cloudflare',
                'cf-ray': 'abc',
                'cf-cache-status': 'HIT',
                'x-qrator-requestid': 'f4b16a6bf0bcc8bebc394a2824d5d569',
            },
        )

        self.assertGreater(len(infra_candidates), 1)
        self.assertEqual(infra_candidates[0]['provider'], 'Cloudflare')
        self.assertEqual(infra_candidates[1]['provider'], 'QRATOR')

    def test_qrator_challenge_cookie_and_error_page_are_supporting_signals(self):
        """
        QRATOR bot-protection and error-page markers should identify the security edge.

        :return: None
        """

        detector, _, _ = self.make_detector()
        body = '<html><script>document.cookie="qrator_jsid=abc";</script><img src="/qrerror/logo.svg"></html>'
        not_found_body = '<html><img src="/qrerror/blocked.svg">Qrator Labs</html>'

        detector._apply_detection_rules(
            body=body,
            body_lower=body.lower(),
            headers={},
            cookies=['qrator_jsid'],
            generator='',
            probe_statuses={},
            final_root_url='http://example.com/',
            not_found_headers={'server': 'QRATOR'},
            not_found_body=not_found_body,
        )

        infra_candidates = detector._build_infrastructure_candidates()
        self.assertGreater(len(infra_candidates), 0)
        self.assertEqual(infra_candidates[0]['provider'], 'QRATOR')
        result = detector._build_infrastructure_result(infra_candidates)
        signal_values = [item['value'] for item in result['signals']]
        self.assertIn('qrator_jsid', signal_values)
        self.assertIn('/qrerror/', signal_values)

    def test_collision_regressions_do_not_false_positive_on_generic_admin_routes(self):
        """
        Generic admin-like routes should not trigger CMS false positives without family hints.

        :return: None
        """

        cases = [
            {
                'forbidden': 'Bolt CMS',
                'body': '<html><body><a href="/bolt">Backend</a></body></html>',
                'probes': {'/bolt': 302},
            },
            {
                'forbidden': 'Directus',
                'body': '<html><body>'
                        '<script src="/admin/assets/index.js"></script>'
                        '<link href="/admin/assets/index.css" rel="stylesheet">'
                        '</body></html>',
                'probes': {'/admin': 302},
            },
            {
                'forbidden': 'Discourse',
                'body': '<html><body>'
                        '<h1>Discourse migration guide</h1>'
                        '<img src="/uploads/default/original/1X/test.png">'
                        '</body></html>',
            },
            {
                'forbidden': 'Matomo',
                'body': '<html><body>'
                        '<h1>How to migrate from matomo</h1>'
                        '<code>/matomo.js</code>'
                        '<code>/matomo.php</code>'
                        '</body></html>',
            },
            {
                'forbidden': 'Neos',
                'body': '<html><body>'
                        '<h1>Neos deployment notes</h1>'
                        '<link href="/_Resources/Static/Packages/Vendor.Site/app.css">'
                        '</body></html>',
            },
            {
                'forbidden': 'MODX',
                'body': '<html><body>'
                        '<a href="/manager/">manager</a>'
                        '<script src="/assets/components/example.js"></script>'
                        '</body></html>',
                'probes': {'/manager/': 302},
            },
            {
                'forbidden': 'Craft CMS',
                'body': '<html><body>'
                        '<script src="/cpresources/abc/app.js"></script>'
                        '<link href="/cpresources/abc/app.css" rel="stylesheet">'
                        '</body></html>',
                'probes': {'/admin': 302},
            },
            {
                'forbidden': 'Shopware',
                'body': '<html><body>'
                        '<link href="/theme/frontend/default/css/all.css">'
                        '<div data-url="/widgets/index/menu"></div>'
                        '<meta name="csrf-token" content="x">'
                        '</body></html>',
                'probes': {'/backend': 302},
            },
            {
                'forbidden': 'OctoberCMS',
                'body': '<html><body>'
                        '<link href="/themes/demo/assets/css/theme.css">'
                        '<script src="/modules/system/assets/js/framework.js"></script>'
                        '</body></html>',
                'probes': {'/backend': 302},
            },
            {
                'forbidden': 'Pimcore',
                'body': '<html><body>'
                        '<link href="/bundles/pimcoreadmin/css/admin.css">'
                        '<script src="/bundles/pimcorestatic6/js/app.js"></script>'
                        '<a href="/admin/login">Admin</a>'
                        '</body></html>',
                'probes': {'/admin': 302},
            },
            {
                'forbidden': 'Directus',
                'body': '<html><body>'
                        '<h1>How to migrate from directus to another CMS</h1>'
                        '<script src="/admin/assets/index.js"></script>'
                        '<link href="/admin/assets/index.css" rel="stylesheet">'
                        '</body></html>',
                'probes': {'/admin': 302},
            },
            {
                'forbidden': 'Craft CMS',
                'body': '<html><body><div id="root"></div></body></html>',
                'cookies': ['craftsessionid'],
            },
        ]

        for case in cases:
            with self.subTest(case=case['forbidden']):
                candidates, _ = self.apply_case(
                    body=case.get('body', ''),
                    cookies=case.get('cookies', []),
                    probes=case.get('probes', {}),
                )

                top_names = [candidate['name'] for candidate in candidates[:3]]
                self.assertNotIn(case['forbidden'], top_names)


    def test_modx_revolution_header_detects_modx(self):
        """MODX Revolution X-Powered-By header should be strong passive CMS evidence."""

        detector, _, _ = self.make_detector()
        detector._apply_detection_rules(
            body='',
            body_lower='',
            headers={'x-powered-by': 'MODX Revolution'},
            cookies=[],
            generator='',
            probe_statuses={},
            final_root_url='https://example.com/',
        )

        candidates = detector._build_candidates()
        runtime = detector._build_runtime_result(detector._build_runtime_candidates())

        self.assertEqual(candidates[0]['name'], 'MODX')
        self.assertEqual(candidates[0]['category'], 'cms')
        self.assertEqual(candidates[0]['score'], 8.0)
        self.assertEqual(runtime['name'], 'PHP')
        self.assertEqual(
            detector._Fingerprint__signals['MODX'][0]['value'],
            'x-powered-by=MODX Revolution',
        )

    def test_generator_extractor_skips_generator_meta_without_content(self):
        """Generator extraction should continue past incomplete generator meta tags."""

        body = '<meta name="generator"><meta name="generator" content="Grav CMS">'

        self.assertEqual(Fingerprint._extract_generator(body), 'Grav CMS')

    def test_melbis_shop_collects_lower_confidence_cookie_route_signal(self):
        """Melbis Shop should accept cookie plus route corroboration without strong branding."""

        detector, _, _ = self.make_detector()

        detector._apply_melbis_shop_rules(
            'plain link goods.php?id=42',
            ['MS_MSS'],
            '',
        )

        signals = getattr(detector, '_Fingerprint__signals')['Melbis Shop Platform']
        self.assertEqual(signals[0]['type'], 'cookie+route')
        self.assertIn('MS_MSS+dir/goods/news.php?id', signals[0]['value'])

    def test_melbis_shop_collects_source_and_quoted_route_markers(self):
        """Melbis Shop collector should capture source markers and quoted route URLs."""

        signals = Fingerprint._collect_melbis_shop_signals(
            '<script>DefineSession("MELBIS_SHOP")</script><a href="/news.php?id=7">',
            [],
            'Melbis Shop 6',
        )

        signal_values = [value for _, value in signals]
        self.assertIn('generator=Melbis Shop', signal_values)
        self.assertIn('DefineSession("MELBIS_SHOP")', signal_values)
        self.assertIn('dir/goods/news.php?id', signal_values)

    def test_camaleon_cookie_only_pair_is_lower_confidence_signal(self):
        """Camaleon CMS should require paired cookies for cookie-only detection."""

        detector, _, _ = self.make_detector()

        detector._apply_camaleon_cms_rules('', ['auth_token', '_cms_session'], '')

        signals = getattr(detector, '_Fingerprint__signals')['Camaleon CMS']
        self.assertEqual(signals[0]['type'], 'cookie')
        self.assertEqual(signals[0]['value'], 'auth_token+_cms_session')

    def test_camaleon_repeated_brand_with_rails_csrf_is_markup_signal(self):
        """Camaleon CMS should accept repeated branding when Rails CSRF is present."""

        body = (
            '<meta name="csrf-token" content="abc">'
            '<meta name="csrf-param" content="authenticity_token">'
            '<p>Camaleon CMS</p><p>camaleoncms</p>'
        ).lower()

        signals = Fingerprint._collect_camaleon_cms_signals(body, [], '')

        self.assertIn(('markup', 'Camaleon CMS repeated+Rails CSRF'), signals)

    def test_una_cms_collects_asset_fallbacks_and_structural_rule(self):
        """UNA CMS should cover weaker asset fallbacks and structural corroboration."""

        weak_signals = Fingerprint._collect_una_cms_root_signals(
            'gzip_loader.php image_transcoder.php bx-main bx-toolbar-content',
            '',
        )
        self.assertIn(('asset', 'gzip_loader.php'), weak_signals)
        self.assertIn(('asset', 'image_transcoder.php'), weak_signals)

        detector, _, _ = self.make_detector()
        detector._apply_una_cms_rules(
            'gzip_loader.php?file=bx_ image_transcoder.php?o=1 bx-main bx-toolbar-content',
            '',
        )

        signals = getattr(detector, '_Fingerprint__signals')['UNA CMS']
        self.assertEqual(signals[0]['type'], 'markup')
        self.assertIn('gzip_loader.php?file=bx_', signals[0]['value'])

    def test_datalife_engine_covers_brand_corroborated_script_and_min_asset(self):
        """DataLife Engine should cover brand-corroborated weak runtime branches."""

        detector, _, _ = self.make_detector()

        detector._apply_datalife_engine_rules(
            'DataLife Engine window.dle_root engine/classes/min/index.php dle_root+"engine/ajax/"',
            '',
        )

        signal_types = [signal['type'] for signal in getattr(detector, '_Fingerprint__signals')['DataLife Engine']]
        self.assertIn('script+brand', signal_types)
        self.assertIn('asset+script', signal_types)
        self.assertIn('ajax', signal_types)

    def test_grav_single_asset_is_accepted_with_generator_corroboration(self):
        """GravCMS should accept a single public asset marker when generator corroborates it."""

        candidates, _ = self.apply_case(
            body='<link href="/user/themes/quark/css/theme.css">',
            generator='Grav CMS',
        )

        self.assertTrue(any(candidate['name'] == 'GravCMS' for candidate in candidates))
        detector, _, _ = self.make_detector()
        detector._apply_detection_rules(
            body='<link href="/user/themes/quark/css/theme.css">',
            body_lower='<link href="/user/themes/quark/css/theme.css">',
            headers={},
            cookies=[],
            generator='Grav CMS',
            probe_statuses={},
            final_root_url='http://example.com/',
            not_found_status=0,
            not_found_body='',
            not_found_headers={},
        )
        signal_types = [signal['type'] for signal in getattr(detector, '_Fingerprint__signals')['GravCMS']]
        self.assertIn('asset', signal_types)

    def test_melbis_shop_strong_signal_without_route_does_not_add_route_signal(self):
        """Melbis Shop strong evidence should not add optional route metadata when absent."""

        detector, _, _ = self.make_detector()

        detector._apply_melbis_shop_rules('powered by Melbis Shop', [], '')

        signal_types = [signal['type'] for signal in getattr(detector, '_Fingerprint__signals')['Melbis Shop Platform']]
        self.assertEqual(signal_types, ['markup'])

    def test_camaleon_meta_signal_and_single_cookie_negative_branch(self):
        """Camaleon should cover generator evidence and avoid single-cookie-only detection."""

        signals = Fingerprint._collect_camaleon_cms_signals('', [], 'CamaleonCMS')
        self.assertIn(('meta', 'generator=Camaleon CMS'), signals)

        detector, _, _ = self.make_detector()
        detector._apply_camaleon_cms_rules('', ['auth_token'], '')

        self.assertNotIn('Camaleon CMS', getattr(detector, '_Fingerprint__signals'))

    def test_una_cms_meta_generator_is_standalone_signal(self):
        """UNA CMS generator evidence should produce a standalone meta signal."""

        detector, _, _ = self.make_detector()

        detector._apply_una_cms_rules('', 'UNA Platform')

        signals = getattr(detector, '_Fingerprint__signals')['UNA CMS']
        self.assertEqual(signals[0]['type'], 'meta')
        self.assertEqual(signals[0]['value'], 'generator=UNA')

    def test_cms_s3_structural_signal_without_vendor_stays_markup_only(self):
        """CMS.S3 structural evidence should not add vendor metadata when vendor markers are absent."""

        detector, _, _ = self.make_detector()

        detector._apply_cms_s3_rules('/my/s3/ $ite.start')

        signal_types = [signal['type'] for signal in getattr(detector, '_Fingerprint__signals')['CMS.S3 / Megagroup']]
        self.assertEqual(signal_types, ['markup'])

    def test_wordpress_probe_evidence_rejects_invalid_status_values(self):
        """WordPress probe evidence should ignore non-numeric probe statuses defensively."""

        self.assertFalse(Fingerprint._is_wordpress_probe_up(
            {'/wp-json/': object()},
            '/wp-json/',
            404,
            True,
            [200],
            [401, 403],
        ))

    def test_detect_reports_progress_events(self):
        """
        Fingerprint.detect() should report deterministic progress steps.

        :return: None
        """

        config = FakeConfig()
        responses = {
            ('GET', 'http://example.com/'): FakeResponse(
                status=200,
                data='<html><body><script src="/wp-content/themes/app/theme.js"></script></body></html>',
                headers={},
            )
        }
        client = FakeClient(config=config, responses=responses)
        events = []
        detector = Fingerprint(
            config=config,
            client=client,
            progress_callback=lambda current, total, label: events.append((current, total, label)),
        )

        result = detector.detect()
        progress_total = len(Fingerprint.PROBES) + 4

        self.assertEqual(result['candidates'][0]['name'], 'WordPress')
        self.assertEqual(events[0], (0, progress_total, 'start'))
        self.assertEqual(events[-1], (progress_total, progress_total, 'done'))
        self.assertTrue(any(event[2].startswith('probe 1/') for event in events))

    def test_extended_catalog_has_no_foreign_prefix_names(self):
        """
        Extended CMS catalog constants should use OpenDoor-native names.

        :return: None
        """

        exported_names = dir(Fingerprint)

        self.assertTrue(any(name.startswith('EXTENDED_CMS_') for name in exported_names))
        foreign_prefix = ''.join(['CMS', 'EEK_'])

        self.assertFalse(any(name.startswith(foreign_prefix) for name in exported_names))
