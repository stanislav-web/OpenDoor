# -*- coding: utf-8 -*-

"""
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Development: Stanislav WEB
"""

import unittest
from unittest.mock import patch

from src.core.logger.logger import Logger
from src.lib.browser.threadpool import ThreadPool


class TestBrowserThreadPool(unittest.TestCase):
    """TestBrowserThreadPool class."""

    THREADS = 2

    def __test_function(self, arg):
        """
        Dummy worker callback.

        :param arg: Arbitrary argument.
        :return: None
        """

    def setUp(self):
        """
        Prepare thread pool.

        :return: None
        """
        self._pool = ThreadPool(num_threads=self.THREADS, total_items=10, timeout=0)

    def tearDown(self):
        """
        Cleanup logger handlers and join the pool.

        :return: None
        """
        logger = Logger.log()

        for handler in logger.handlers:
            logger.removeHandler(handler)

        self._pool.join()
        self._pool.close()

    def test_size(self):
        """ThreadPool.size test."""

        self.assertIs(type(self._pool.size), int)
        self.assertEqual(self._pool.size, 0)

    def test_worker_size(self):
        """ThreadPool.worker_size test."""

        self.assertIs(type(self._pool.workers_size), int)
        self.assertEqual(self._pool.workers_size, self.THREADS)

    def test_items_size(self):
        """ThreadPool.items_size test."""

        self.assertIs(type(self._pool.items_size), int)
        self.assertEqual(self._pool.items_size, 0)

    def test_extend_total_items_should_increase_total_items_size(self):
        """ThreadPool.extend_total_items() should increase total_items_size."""

        pool = ThreadPool(1, 10, 0)

        pool.extend_total_items(5)

        self.assertEqual(pool.total_items_size, 15)

    def test_extend_total_items_should_ignore_non_positive_values(self):
        """ThreadPool.extend_total_items() should ignore non-positive values."""

        pool = ThreadPool(1, 10, 0)

        pool.extend_total_items(0)
        self.assertEqual(pool.total_items_size, 10)

        pool.extend_total_items(-3)
        self.assertEqual(pool.total_items_size, 10)

    def test_add(self):
        """ThreadPool.add() test."""

        self.assertIs(self._pool.add(self.__test_function, 1), None)

    def test_add_rechecks_runtime_state_after_pause_request(self):
        """ThreadPool.add() should not enqueue when pause handling stops the pool."""

        pool = ThreadPool(num_threads=1, total_items=1, timeout=0)

        def stop_pool():
            pool.is_started = False

        with patch.object(pool, '_ThreadPool__pause_if_requested', side_effect=stop_pool), \
                patch.object(pool, '_ThreadPool__enqueue_with_pause_resume') as enqueue_mock:
            self.assertIsNone(pool.add(self.__test_function, 1))

        enqueue_mock.assert_not_called()
        pool.close()

    def test_record_worker_error_keeps_first_exception(self):
        """ThreadPool should preserve the first worker error for deterministic propagation."""

        pool = ThreadPool(num_threads=1, total_items=1, timeout=0)
        first = RuntimeError('first')
        second = RuntimeError('second')

        pool._ThreadPool__record_worker_error(first)
        pool._ThreadPool__record_worker_error(second)

        self.assertIs(getattr(pool, '_ThreadPool__worker_error'), first)
        pool.close()

    def test_close_stops_worker_threads(self):
        """ThreadPool.close() should stop idle worker threads instead of leaving them blocked."""

        pool = ThreadPool(num_threads=2, total_items=2, timeout=0)
        pool.join()

        pool.close()

        workers = getattr(pool, '_ThreadPool__workers')
        self.assertTrue(all(worker.is_alive() is False for worker in workers))

    def test_close_is_idempotent(self):
        """ThreadPool.close() should tolerate repeated cleanup calls."""

        pool = ThreadPool(num_threads=1, total_items=1, timeout=0)
        pool.close()

        self.assertIsNone(pool.close())

    def pause(self):
        """
        Call pause helper.

        :return: Any
        """
        return self._pool.pause()

    def test_pause(self):
        """ThreadPool.pause() test."""

        with self.assertRaises(KeyboardInterrupt) as context:
            with patch('builtins.input', return_value='e') as input_mock:
                self.assertEqual(self.pause(), 'e')
                input_mock.assert_called_once_with('e')

        self.assertTrue(KeyboardInterrupt == context.expected)

    def test_resume(self):
        """ThreadPool.resume() test."""

        self._pool.is_started = False
        self.assertIs(self._pool.resume(), None)


    def test_pause_should_resume_on_uppercase_continue(self):
        """ThreadPool.pause() should accept uppercase continue answer."""

        with patch('src.lib.browser.threadpool.tpl.prompt', return_value='C'):
            with patch('src.lib.browser.threadpool.tpl.info') as info_mock:
                self.assertIsNone(self._pool.pause())

        info_mock.assert_called_with(key='resume_threads')

    def test_pause_should_abort_on_uppercase_exit(self):
        """ThreadPool.pause() should accept uppercase exit answer."""

        with patch('src.lib.browser.threadpool.tpl.prompt', return_value='E'):
            with self.assertRaises(KeyboardInterrupt):
                self._pool.pause()


if __name__ == "__main__":
    unittest.main()
