# -*- coding: utf-8 -*-

import os
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from urllib3.response import HTTPResponse

from src.core import CoreConfig, helper
from src.core.http.plugins.response import shadow
from src.core.http.plugins.response.shadow import ShadowResponsePlugin
from src.core.http.response import Response
from src.lib.browser.browser import Browser
from src.lib.browser.config import Config
from src.lib.browser.shadow import ShadowProbe
from src.lib.browser.debug import Debug


class TestShadowProbe(unittest.TestCase):
    """Active shadow-copy probe tests."""

    def make_response(self, body=b'hello', status=200, content_type='text/html'):
        """
        Build a response object for shadow tests.

        :param bytes body: response body
        :param int status: HTTP status
        :param str content_type: Content-Type header value
        :return: HTTP response
        """

        return HTTPResponse(
            status=status,
            body=body,
            headers={'Content-Type': content_type, 'Content-Length': str(len(body))},
        )

    def test_response_package_exports_shadow_plugin_alias(self):
        """Should resolve the shadow sniffer alias without passive classification."""

        response = self.make_response()
        plugin = ShadowResponsePlugin(None)

        self.assertIs(shadow, ShadowResponsePlugin)
        self.assertIsNone(plugin.process(response))

    def test_load_suffixes_keeps_clean_deduplicated_order(self):
        """Should load a clean suffix dictionary and ignore duplicates/empty lines."""

        with tempfile.NamedTemporaryFile('w', delete=False, encoding='utf-8') as handler:
            handler.write('.bak\n.old\n.bak\n\n~\n')
            path = handler.name

        try:
            with patch.dict(CoreConfig.get('data'), {'shadow_suffixes': path}):
                self.assertEqual(ShadowProbe.load_suffixes(), ['.bak', '.old', '~'])
        finally:
            os.unlink(path)

    def test_should_enable_only_when_shadow_sniffer_is_selected(self):
        """Should keep shadow runtime fully gated behind --sniff shadow."""

        self.assertFalse(ShadowProbe.is_enabled(SimpleNamespace(is_sniff=False, sniffers=[])))
        self.assertFalse(ShadowProbe.is_enabled(SimpleNamespace(is_sniff=True, sniffers=['secret'])))
        self.assertTrue(ShadowProbe.is_enabled(SimpleNamespace(is_sniff=True, sniffers=['shadow'])))

    def test_control_suffix_should_not_expose_tool_name(self):
        """Should keep negative-control URLs neutral for target logs."""

        self.assertNotIn('opendoor', ShadowProbe.CONTROL_SUFFIX.lower())
        self.assertNotIn('shadow', ShadowProbe.CONTROL_SUFFIX.lower())
        self.assertTrue(ShadowProbe.CONTROL_SUFFIX.startswith('.'))
        self.assertTrue(ShadowProbe.CONTROL_SUFFIX.endswith('__'))

    def test_should_identify_file_like_seed_urls(self):
        """Should probe source/config-like files and skip directories/binary assets."""

        self.assertTrue(ShadowProbe.is_file_like_url('https://example.com/index.php'))
        self.assertTrue(ShadowProbe.is_file_like_url('https://example.com/app.py'))
        self.assertTrue(ShadowProbe.is_file_like_url('https://example.com/package.json'))
        self.assertTrue(ShadowProbe.is_file_like_url('https://example.com/.env'))
        self.assertFalse(ShadowProbe.is_file_like_url('https://example.com/admin/'))
        self.assertFalse(ShadowProbe.is_file_like_url('https://example.com/api/users'))
        self.assertFalse(ShadowProbe.is_file_like_url('https://example.com/logo.png'))

    def test_should_generate_postfix_candidates_with_limit(self):
        """Should generate bounded postfix candidates from one file-like hit."""

        suffixes = ['.s{0}'.format(index) for index in range(20)]
        candidates = ShadowProbe.build_candidates('https://example.com/index.php?x=1', suffixes)

        self.assertEqual(len(candidates), ShadowProbe.MAX_CANDIDATES_PER_HIT)
        self.assertEqual(candidates[0], ('https://example.com/index.php.s0?x=1', '.s0'))
        self.assertEqual(candidates[-1], ('https://example.com/index.php.s15?x=1', '.s15'))

    def test_should_generate_template_candidates_with_query_and_variant_metadata(self):
        """Should render path-aware template variants without weakening match metadata."""

        candidates = ShadowProbe.build_candidates(
            'https://example.com/admin/index.php?x=1',
            ['tpl:{path}2.{ext}'],
        )

        self.assertEqual(candidates, [('https://example.com/admin/index2.php?x=1', 'tpl:{path}2.{ext}')])

        metadata = ShadowProbe.build_metadata(
            'https://example.com/admin/index.php',
            'https://example.com/admin/index2.php',
            'tpl:{path}2.{ext}',
            {'size': 100},
            {'size': 105, 'similarity': 0.94, 'content_type': 'text/html'},
        )

        detection = metadata['shadow_detection']
        self.assertEqual(detection['variant'], 'tpl:{path}2.{ext}')
        self.assertEqual(detection['variant_type'], 'template')

    def test_should_skip_invalid_template_variants_and_deduplicate_candidates(self):
        """Should keep template expansion bounded, valid and duplicate-free."""

        candidates = ShadowProbe.build_candidates(
            'https://example.com/index.php',
            [
                '',
                'tpl:{path}.{ext}.bak',
                '.bak',
                'tpl:{path}',
                'tpl:{path}2.{missing}',
                '.old',
            ],
        )

        self.assertEqual(
            candidates,
            [
                ('https://example.com/index.php.bak', 'tpl:{path}.{ext}.bak'),
                ('https://example.com/index.php.old', '.old'),
            ],
        )
        self.assertIsNone(ShadowProbe.build_template_path('/.env', '{path}2.{ext}'))
        self.assertIsNone(ShadowProbe.build_template_path('/admin/index', '{path}2.{ext}'))

    def test_should_normalize_shadow_probe_delay_values(self):
        """Should coerce active shadow delay to a safe non-negative float."""

        self.assertEqual(ShadowProbe.normalize_delay(None), 0.0)
        self.assertEqual(ShadowProbe.normalize_delay('bad'), 0.0)
        self.assertEqual(ShadowProbe.normalize_delay(-1), 0.0)
        self.assertEqual(ShadowProbe.normalize_delay(0), 0.0)
        self.assertEqual(ShadowProbe.normalize_delay('1.25'), 1.25)

    def test_should_honor_configured_delay_before_probe_request(self):
        """Should respect scan delay before every active shadow probe request."""

        base_response = self.make_response(body=b'base stable body line\n' * 5)
        candidate_response = self.make_response(body=(b'base stable body line\n' * 5) + b'changed\n')
        base_signature = ShadowProbe.response_signature(base_response)
        request = MagicMock(return_value=candidate_response)
        probe = ShadowProbe(request, MagicMock(), delay=1.25)

        with patch('src.lib.browser.shadow.time.sleep') as sleep_mock:
            getattr(probe, '_ShadowProbe__process_task')(
                (
                    'https://example.com/index.php',
                    base_signature,
                    'https://example.com/index.php.bak',
                    '.bak',
                    1,
                )
            )

        sleep_mock.assert_called_once_with(1.25)
        request.assert_called_once_with('https://example.com/index.php.bak')

    def test_should_ignore_identical_shadow_copy_and_classify_near_copy_diff(self):
        """Should report changed near-copies and ignore byte-identical copies."""

        base = self.make_response(body=(b'<?php echo "stable"; ?>\n' * 10))
        matches = []
        progress = []

        def request(url):
            if url.endswith('.bak'):
                return self.make_response(body=(b'<?php echo "stable"; ?>\n' * 10))
            if url.endswith('.old'):
                return self.make_response(body=(b'<?php echo "stable"; ?>\n' * 10) + b'<!-- backup marker -->\n')
            return self.make_response(body=b'not the same')

        probe = ShadowProbe(request, lambda url, response, metadata: matches.append((url, metadata)), lambda *args: progress.append(args))
        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak', '.old', '.tmp']):
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 3)
            probe.drain()

        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0][0], 'https://example.com/index.php.old')
        detection = matches[0][1]['shadow_detection']
        self.assertEqual(detection['type'], 'backup_copy')
        self.assertEqual(detection['reason'], 'content_diff')
        self.assertEqual(detection['base_url'], 'https://example.com/index.php')
        self.assertEqual(detection['variant'], '.old')
        self.assertEqual(detection['confidence'], 90)
        self.assertGreater(detection['similarity'], 0.90)
        self.assertLess(detection['similarity'], 1.0)
        self.assertGreaterEqual(len(progress), 1)

    def test_should_ignore_unrelated_shadow_candidate(self):
        """Should skip unrelated 200 OK candidates even when the suffix matches."""

        base = self.make_response(body=b'<?php echo "stable"; ?>')
        probe = ShadowProbe(lambda url: self.make_response(body=b'<html>generic fallback</html>'), MagicMock())

        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak']):
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 1)
            probe.drain()

        self.assertEqual(probe.findings, 0)

    def test_should_ignore_js_cookie_gate_base_and_candidate_responses(self):
        """Should not build shadow signatures from JavaScript cookie-gate bootstrap pages."""

        cookie_gate_body = (
            b'<html><body><script>document.cookie="bpc=abc;Domain=www.familytree.ru;Path=/";'
            b'document.location.href="http://www.familytree.ru/wp-login.php.tmp";'
            b'</script></body></html>'
        )
        cookie_gate_response = self.make_response(body=cookie_gate_body)

        self.assertIsNone(ShadowProbe.response_signature(cookie_gate_response))

        request = MagicMock(return_value=cookie_gate_response)
        probe = ShadowProbe(request, MagicMock())
        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak']):
            self.assertEqual(probe.enqueue('https://www.familytree.ru/wp-login.php', cookie_gate_response, 'success'), 0)

        base = self.make_response(body=b'<?php echo "stable application body"; ?>\n' * 8)
        probe = ShadowProbe(request, MagicMock())
        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak']):
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 1)
            probe.drain()

        self.assertEqual(probe.findings, 0)

    def test_should_suppress_shadow_burst_when_control_matches_fallback(self):
        """Should suppress fallback-like shadow bursts without lowering real matching rules."""

        base_body = b'<html><title>dashboard</title><main>same dynamic fallback body</main></html>'
        base = self.make_response(body=base_body)
        seen_urls = []
        matches = []

        def request(url):
            seen_urls.append(url)
            if url.endswith(ShadowProbe.CONTROL_SUFFIX):
                return self.make_response(body=base_body.replace(b'dashboard', b'dashboard '))
            return self.make_response(body=base_body + b'<!-- would be a false shadow -->')

        probe = ShadowProbe(request, lambda url, response, metadata: matches.append((url, metadata)))
        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak', '.old', '.tmp']):
            self.assertEqual(probe.enqueue('https://example.com/register-site-admin.php', base, 'success'), 3)
            probe.drain()

        self.assertEqual(seen_urls, ['https://example.com/register-site-admin.php{0}'.format(ShadowProbe.CONTROL_SUFFIX)])
        self.assertEqual(matches, [])
        self.assertEqual(probe.submitted, 3)
        self.assertEqual(probe.completed, 3)
        self.assertEqual(probe.findings, 0)

    def test_should_keep_real_shadow_candidate_when_control_does_not_match(self):
        """Should preserve real shadow findings when the negative control is not fallback-like."""

        base_body = b'<?php echo "stable application body"; ?>\n' * 8
        shadow_body = base_body + b'// backup-only marker\n'
        base = self.make_response(body=base_body, content_type='text/plain')
        matches = []

        def request(url):
            if url.endswith(ShadowProbe.CONTROL_SUFFIX):
                return self.make_response(body=b'not found', status=404, content_type='text/plain')
            if url.endswith('.bak'):
                return self.make_response(body=shadow_body, content_type='text/plain')
            return self.make_response(body=base_body, content_type='text/plain')

        probe = ShadowProbe(request, lambda url, response, metadata: matches.append((url, metadata)))
        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak', '.old']):
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 2)
            probe.drain()

        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0][0], 'https://example.com/index.php.bak')
        self.assertEqual(matches[0][1]['shadow_detection']['reason'], 'content_diff')
        self.assertEqual(probe.submitted, 2)
        self.assertEqual(probe.completed, 2)
        self.assertEqual(probe.findings, 1)

    def test_should_skip_non_success_non_file_like_binary_and_shadow_buckets(self):
        """Should keep active probing limited to success 200 file-like responses."""

        request = MagicMock(return_value=self.make_response())
        match = MagicMock()
        probe = ShadowProbe(request, match)

        self.assertEqual(probe.enqueue('https://example.com/index.php', self.make_response(status=403), 'success'), 0)
        self.assertEqual(probe.enqueue('https://example.com/admin/', self.make_response(), 'success'), 0)
        self.assertEqual(probe.enqueue('https://example.com/logo.png', self.make_response(), 'success'), 0)
        self.assertEqual(probe.enqueue('https://example.com/index.php', self.make_response(), 'shadow'), 0)
        self.assertEqual(probe.enqueue('https://example.com/archive.zip', self.make_response(content_type='application/zip'), 'success'), 0)
        self.assertEqual(request.call_count, 0)
        self.assertEqual(match.call_count, 0)

    def test_should_deduplicate_shadow_candidates_globally(self):
        """Should never submit the same generated shadow URL twice."""

        request = MagicMock(return_value=self.make_response(body=b'different'))
        probe = ShadowProbe(request, MagicMock())
        base = self.make_response(body=b'base')

        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak']):
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 1)
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 0)
            probe.drain()

        self.assertEqual(request.call_count, 1)

    def test_should_cover_shadow_helper_edge_paths(self):
        """Should cover shadow helper edge paths and defensive fallbacks."""

        with patch.dict(CoreConfig.get('data'), {'shadow_suffixes': None}):
            self.assertEqual(ShadowProbe.load_suffixes(), [])

        self.assertFalse(ShadowProbe.is_file_like_url('http://[::1'))
        self.assertFalse(ShadowProbe.is_file_like_url('https://example.com/.'))
        self.assertEqual(ShadowProbe.build_candidates('http://[::1', ['.bak']), [])
        self.assertEqual(ShadowProbe.build_candidates('https://example.com/admin/', ['.bak']), [])

        none_body = SimpleNamespace(status=200, data=None, headers={})
        string_body = SimpleNamespace(status=200, data='  stable text  ', headers={'content-type': 'text/plain; charset=utf-8'})
        empty_body = SimpleNamespace(status=200, data=b'   ', headers={})
        bad_status = SimpleNamespace(status='bad', data=b'stable', headers={})
        binary = SimpleNamespace(status=200, data=b'stable', headers={'Content-Type': 'image/png'})

        self.assertIsNone(ShadowProbe.response_signature(none_body))
        self.assertEqual(ShadowProbe.response_signature(string_body)['size'], len('  stable text  '))
        self.assertIsNone(ShadowProbe.response_signature(empty_body))
        self.assertFalse(ShadowProbe.is_supported_response(bad_status))
        self.assertFalse(ShadowProbe.is_supported_response(binary))
        self.assertIsNone(ShadowProbe.is_match(None, string_body))
        self.assertIsNone(ShadowProbe.is_match({'hash': 'missing'}, none_body))

    def test_should_cover_shadow_content_type_fallbacks(self):
        """Should normalize content-type from mapping-like and invalid headers."""

        class HeaderPairs(object):
            def __iter__(self):
                return iter([('content-type', 'Application/JSON; charset=utf-8')])

        pair_response = SimpleNamespace(headers=HeaderPairs())
        invalid_response = SimpleNamespace(headers=object())

        self.assertEqual(ShadowProbe.content_type(pair_response), 'application/json')
        self.assertEqual(ShadowProbe.content_type(invalid_response), '')

    def test_should_stop_enqueueing_after_total_probe_limit(self):
        """Should stop queueing candidates when the global probe limit is reached."""

        request = MagicMock(return_value=self.make_response(body=b'different'))
        probe = ShadowProbe(request, MagicMock())
        base = self.make_response(body=b'base')

        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak']), \
                patch.object(ShadowProbe, 'MAX_TOTAL_PROBES', 0):
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 0)

    def test_should_count_completed_and_findings_and_ignore_request_errors(self):
        """Should keep worker counters stable for matches and request failures."""

        responses = {
            'https://example.com/index.php.bak': self.make_response(body=(b'base stable body line\n' * 5) + b'changed\n'),
        }

        def request(url):
            if url.endswith('.old'):
                raise RuntimeError('network failed')
            return responses[url]

        matches = []
        probe = ShadowProbe(request, lambda url, response, metadata: matches.append(metadata))
        base = self.make_response(body=b'base stable body line\n' * 5)

        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak', '.old']):
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 2)
            probe.drain()

        self.assertEqual(probe.completed, 2)
        self.assertEqual(probe.findings, 1)
        self.assertEqual(len(matches), 1)

    def test_config_reports_shadow_sniffer_state(self):
        """Should expose active shadow probing state only for the shadow sniffer."""

        enabled = Config({'sniff': 'shadow'})
        disabled = Config({'sniff': 'secret'})
        empty = Config({})

        self.assertTrue(enabled.is_shadow_sniff)
        self.assertFalse(disabled.is_shadow_sniff)
        self.assertFalse(empty.is_shadow_sniff)

    def test_response_debug_data_forwards_shadow_detection(self):
        """Should pass shadow detection metadata into runtime debug renderers."""

        debug = SimpleNamespace(debug_request_uri=MagicMock(), debug_classification=MagicMock())
        response_debug = Response(SimpleNamespace(is_sniff=False), debug)
        shadow_response = SimpleNamespace(opendoor_shadow_detection={'variant': '.bak'})
        secret_response = SimpleNamespace(opendoor_secret_detection={'type': 'generic'})
        stacktrace_response = SimpleNamespace(opendoor_stacktrace_detection={'runtime': 'python'})

        response_debug.debug_response_data(('shadow', 'https://example.com/index.php.bak', '4B', '200'),
                                           'https://example.com/index.php.bak', 1, 1, response=shadow_response)
        response_debug.debug_response_data(('secret', 'https://example.com/config.php', '4B', '200'),
                                           'https://example.com/config.php', 1, 1, response=secret_response)
        response_debug.debug_response_data(('stacktrace', 'https://example.com/debug', '4B', '500'),
                                           'https://example.com/debug', 1, 1, response=stacktrace_response)

        self.assertEqual(debug.debug_request_uri.call_args_list[0].kwargs['shadow_detection'], {'variant': '.bak'})
        self.assertEqual(debug.debug_classification.call_args_list[0].kwargs['shadow_detection'], {'variant': '.bak'})
        self.assertEqual(debug.debug_request_uri.call_args_list[1].kwargs['secret_detection'], {'type': 'generic'})
        self.assertEqual(debug.debug_request_uri.call_args_list[2].kwargs['stacktrace_detection'], {'runtime': 'python'})

    def test_debug_classification_renders_shadow_detection(self):
        """Should render shadow metadata in debug level 3 classification details."""

        cfg = SimpleNamespace(DEFAULT_SCAN='directories', scan='directories', debug=3, method='GET')
        debug = Debug(cfg)

        with patch('src.lib.browser.debug.tpl.debug') as debug_mock:
            debug.debug_classification(
                status='shadow',
                code='200',
                size='21B',
                shadow_detection={'base_url': 'https://example.com/index.php', 'variant': '.bak', 'confidence': 95},
            )

        rendered = [call.kwargs.get('msg') for call in debug_mock.call_args_list]
        self.assertTrue(any('Shadow detection:' in str(item) for item in rendered))

    def test_shadow_template_and_candidate_edge_branches(self):
        """Shadow template helpers should reject malformed rendered paths."""

        self.assertIsNone(ShadowProbe.build_template_path('/index.', '{path}2.{ext}'))
        self.assertIsNone(ShadowProbe.build_template_path('/index.php', '{path}{bad}.{ext}'))
        self.assertIsNone(ShadowProbe.build_template_path('/index.php', '{path}.{ext}'))
        self.assertEqual(ShadowProbe.build_candidates('https://example.com/index.php', ['.bak', '.bak']), [
            ('https://example.com/index.php.bak', '.bak'),
        ])

    def test_shadow_control_candidate_and_fallback_edges(self):
        """Shadow negative-control helpers should cover parse and mismatch guards."""

        self.assertIsNone(ShadowProbe.build_control_candidate('http://[::1'))
        self.assertIsNone(ShadowProbe.build_control_candidate('https://example.com/admin/'))

        identical = self.make_response(body=b'body', content_type='text/html')
        base = ShadowProbe.response_signature(identical)
        different_type = self.make_response(body=b'body', content_type='application/json')
        self.assertFalse(ShadowProbe.is_fallback_like_control(base, different_type))

        self.assertTrue(ShadowProbe.is_fallback_like_control(base, identical))
        self.assertFalse(ShadowProbe.is_fallback_like_control(None, identical))

    def test_shadow_enqueue_control_candidate_guards(self):
        """Shadow control enqueue should skip short, invalid and duplicate states."""

        probe = ShadowProbe(MagicMock(), MagicMock())
        base_signature = {'hash': 'h', 'normalized': 'body', 'size': 10, 'content_type': 'text/html'}
        enqueue_control = getattr(probe, '_ShadowProbe__enqueue_control_candidate')

        enqueue_control('https://example.com/index.php', base_signature, [
            ('https://example.com/index.php.bak', '.bak'),
        ])
        self.assertEqual(getattr(probe, '_ShadowProbe__queue').qsize(), 0)

        enqueue_control('https://example.com/admin/', base_signature, [
            ('https://example.com/admin/.bak', '.bak'),
            ('https://example.com/admin/.old', '.old'),
        ])
        self.assertEqual(getattr(probe, '_ShadowProbe__queue').qsize(), 0)

        enqueue_control('https://example.com/index.php', base_signature, [
            ('https://example.com/index.php.bak', '.bak'),
            ('https://example.com/index.php.old', '.old'),
        ])
        enqueue_control('https://example.com/index.php', base_signature, [
            ('https://example.com/index.php.tmp', '.tmp'),
            ('https://example.com/index.php.save', '.save'),
        ])
        self.assertEqual(getattr(probe, '_ShadowProbe__queue').qsize(), 1)

    def test_shadow_process_control_task_delay_exception_and_state(self):
        """Control probes should honor delay and mark allowed on request errors."""

        probe = ShadowProbe(MagicMock(side_effect=RuntimeError('offline')), MagicMock(), delay=0.5)
        base_signature = {'hash': 'h', 'normalized': 'body', 'size': 10, 'content_type': 'text/html'}

        with patch('src.lib.browser.shadow.time.sleep') as sleep_mock:
            getattr(probe, '_ShadowProbe__process_control_task')(
                'https://example.com/index.php',
                base_signature,
                'https://example.com/index.php{0}'.format(ShadowProbe.CONTROL_SUFFIX),
            )

        sleep_mock.assert_called_once_with(0.5)
        self.assertFalse(getattr(probe, '_ShadowProbe__is_base_suppressed')('https://example.com/index.php'))
        self.assertFalse(getattr(ShadowProbe, '_ShadowProbe__is_control_task')(None))

    def test_shadow_enqueue_stops_when_probe_limit_is_reached_mid_batch(self):
        """Shadow enqueue should stop cleanly once the total probe limit is reached mid-batch."""

        request = MagicMock(return_value=self.make_response(body=b'different'))
        probe = ShadowProbe(request, MagicMock())
        base = self.make_response(body=b'base stable body line\n' * 5)

        with patch.object(probe, '_ShadowProbe__suffixes', ['.bak', '.old', '.tmp']), \
                patch.object(ShadowProbe, 'MAX_TOTAL_PROBES', 1):
            self.assertEqual(probe.enqueue('https://example.com/index.php', base, 'success'), 1)
            probe.drain()

        self.assertLessEqual(probe.submitted, 1)



class TestBrowserShadowIntegration(unittest.TestCase):
    """Browser integration tests for active shadow probe plumbing."""

    def make_browser(self):
        """Build a minimal Browser instance for private method coverage."""

        br = Browser.__new__(Browser)
        setattr(br, '_Browser__result', {'total': helper.counter(), 'items': helper.list(), 'report_items': helper.list()})
        setattr(br, '_Browser__shadow_probe', None)
        setattr(br, '_Browser__pool', SimpleNamespace(items_size=1, total_items_size=3, workers_size=1))
        setattr(br, '_Browser__response', SimpleNamespace(
            _get_content_size=MagicMock(return_value='21B'),
            debug_response_data=MagicMock(),
        ))
        return br


    def test_browser_passes_scan_delay_to_shadow_probe(self):
        """Browser should pass the base scan delay into the active shadow probe worker."""

        reader = MagicMock()
        reader.total_lines = 3
        cfg = SimpleNamespace(
            scan='directories',
            DEFAULT_SCAN='directories',
            _method='HEAD',
            method='GET',
            method_override_items=[],
            proxy_list='',
            is_random_list=False,
            is_extension_filter=False,
            is_ignore_extension_filter=False,
            is_external_wordlist=False,
            wordlist=None,
            is_standalone_proxy=False,
            is_external_proxy_list=False,
            prefix='',
            is_external_reports_dir=False,
            reports_dir=None,
            extensions=[],
            ignore_extensions=[],
            threads=1,
            delay=1.5,
            timeout=10,
            DEFAULT_SOCKET_TIMEOUT=10,
            is_session_enabled=False,
            session_save=None,
            session_autosave_sec=20,
            session_autosave_items=200,
        )

        with patch('src.lib.browser.browser.Config', return_value=cfg), \
                patch('src.lib.browser.browser.Debug', return_value=MagicMock()), \
                patch('src.lib.browser.browser.Reader', return_value=reader), \
                patch('src.lib.browser.browser.Filter.__init__', return_value=None), \
                patch('src.lib.browser.browser.ThreadPool', return_value=MagicMock()), \
                patch('src.lib.browser.browser.response', return_value=MagicMock()), \
                patch('src.lib.browser.browser.SnifferEngine.active_names_from_config', return_value={'shadow'}), \
                patch('src.lib.browser.browser.ShadowProbe') as shadow_cls:
            Browser({'host': 'test.local'})

        shadow_cls.assert_called_once()
        self.assertEqual(shadow_cls.call_args.kwargs['delay'], 1.5)

    def test_browser_enqueue_shadow_probes_defensive_and_enabled_paths(self):
        """Should cover shadow enqueue guards and enabled delegation."""

        br = self.make_browser()
        response = HTTPResponse(status=200, body=b'base', headers={'Content-Type': 'text/html'})
        shadow_probe = SimpleNamespace(enqueue=MagicMock(return_value=2))
        setattr(br, '_Browser__shadow_probe', shadow_probe)

        self.assertEqual(br._Browser__enqueue_shadow_probes(None, response), 0)
        self.assertEqual(br._Browser__enqueue_shadow_probes(('success',), response), 0)
        self.assertEqual(br._Browser__enqueue_shadow_probes(('shadow', 'https://example.com/index.php'), response), 0)
        self.assertEqual(br._Browser__enqueue_shadow_probes(('success', 'https://example.com/index.php'), response), 2)

        shadow_probe.enqueue.assert_called_once_with('https://example.com/index.php', response, 'success')

    def test_browser_emits_shadow_probe_progress_and_fallback_size(self):
        """Should render shadow probe progress for misses and tolerate bad response objects."""

        br = self.make_browser()
        emit_mock = MagicMock(return_value=True)
        setattr(br, '_Browser__emit_filtered_progress', emit_mock)
        response = HTTPResponse(status=404, body=b'missing', headers={'Content-Type': 'text/html'})

        self.assertTrue(br._Browser__emit_shadow_probe_progress('https://example.com/index.php.bak', response, 1, 3))
        self.assertEqual(emit_mock.call_args_list[0].args[0], 'shadow-probe')
        self.assertEqual(emit_mock.call_args_list[0].args[2]['calibration_score'], '1/3')

        getattr(br, '_Browser__response')._get_content_size.side_effect = AttributeError('bad response')
        self.assertTrue(br._Browser__emit_shadow_probe_progress('https://example.com/index.php.old', object(), 2, 3))
        self.assertEqual(emit_mock.call_args_list[1].args[1], ('shadow-probe', 'https://example.com/index.php.old', '-', '-'))

    def test_browser_shadow_match_handles_missing_metadata_and_setattr_errors(self):
        """Should keep shadow match handling robust for partial metadata and frozen responses."""

        class FrozenResponse(object):
            status = 200

            def __setattr__(self, name, value):
                if name == 'opendoor_shadow_detection':
                    raise AttributeError('frozen')
                object.__setattr__(self, name, value)

        br = self.make_browser()
        response = FrozenResponse()

        br._Browser__handle_shadow_match('https://example.com/index.php.bak', response, {'shadow_detection': {'variant': '.bak'}})
        br._Browser__handle_shadow_match('https://example.com/index.php.old', response, {})

        self.assertFalse(hasattr(response, 'opendoor_shadow_detection'))
        self.assertEqual(getattr(br, '_Browser__result')['total']['shadow'], 2)

    def test_browser_shadow_match_skips_non_callable_debug_renderer(self):
        """Should persist shadow findings even when debug renderer is unavailable."""

        br = self.make_browser()
        setattr(br, '_Browser__response', SimpleNamespace(_get_content_size=MagicMock(return_value='21B'), debug_response_data=None))

        br._Browser__handle_shadow_match('https://example.com/index.php.bak', SimpleNamespace(status=200), {})

        self.assertEqual(getattr(br, '_Browser__result')['total']['shadow'], 1)

    def test_browser_shadow_drain_noop_and_zero_counter_paths(self):
        """Should no-op without a shadow queue and avoid empty probe counters."""

        br = self.make_browser()
        self.assertTrue(br._Browser__drain_shadow_probes())
        self.assertNotIn('shadow_probes', getattr(br, '_Browser__result')['total'])

        shadow_probe = SimpleNamespace(drain=MagicMock(), submitted=0)
        setattr(br, '_Browser__shadow_probe', shadow_probe)
        self.assertTrue(br._Browser__drain_shadow_probes())
        self.assertNotIn('shadow_probes', getattr(br, '_Browser__result')['total'])
        shadow_probe.drain.assert_called_once_with()

    def test_browser_preserves_shadow_detection_metadata(self):
        """Should store shadow metadata as one nested report object."""

        br = self.make_browser()
        detection = {'type': 'backup_copy', 'base_url': 'https://example.com/index.php', 'variant': '.bak'}

        br._Browser__catch_report_data(
            'shadow',
            'https://example.com/index.php.bak',
            '21B',
            '200',
            metadata={'shadow_detection': detection},
        )

        result = getattr(br, '_Browser__result')
        self.assertEqual(result['total']['shadow'], 1)
        self.assertEqual(result['items']['shadow'], ['https://example.com/index.php.bak'])
        self.assertEqual(result['report_items']['shadow'][0]['shadow_detection'], detection)

    def test_browser_does_not_enqueue_when_shadow_is_disabled(self):
        """Should leave normal success flow untouched when --sniff shadow is absent."""

        br = self.make_browser()
        response = HTTPResponse(status=200, body=b'base', headers={'Content-Type': 'text/html'})

        self.assertEqual(br._Browser__enqueue_shadow_probes(('success', 'https://example.com/index.php'), response), 0)

    def test_browser_drains_shadow_before_summary_and_records_probe_counter(self):
        """Should drain shadow queue before summary/report generation."""

        br = self.make_browser()
        shadow_probe = SimpleNamespace(drain=MagicMock(), submitted=3)
        setattr(br, '_Browser__shadow_probe', shadow_probe)

        br._Browser__drain_shadow_probes()

        shadow_probe.drain.assert_called_once_with()
        self.assertEqual(getattr(br, '_Browser__result')['total']['shadow_probes'], 3)

    def test_browser_shadow_match_renders_and_records_shadow_bucket(self):
        """Should render OK - Shadow progress and persist the shadow bucket."""

        br = self.make_browser()
        response = HTTPResponse(status=200, body=b'base', headers={'Content-Type': 'text/html'})
        metadata = {
            'shadow_detection': {
                'type': 'backup_copy',
                'base_url': 'https://example.com/index.php',
                'variant': '.bak',
            }
        }

        br._Browser__handle_shadow_match('https://example.com/index.php.bak', response, metadata)

        debug_response_data = getattr(br, '_Browser__response').debug_response_data
        debug_response_data.assert_called_once()
        self.assertEqual(debug_response_data.call_args.kwargs['response'], response)
        self.assertEqual(response.opendoor_shadow_detection, metadata['shadow_detection'])
        self.assertEqual(getattr(br, '_Browser__result')['total']['shadow'], 1)

        item = getattr(br, '_Browser__result')['report_items']['shadow'][0]
        self.assertIn('passive_finding', item)
        self.assertEqual(item['passive_finding']['bucket'], 'shadow')
        self.assertEqual(item['passive_finding']['type'], 'backup_copy')
        self.assertEqual(item['passive_finding']['reason'], 'backup_copy_exposed')
        self.assertEqual(item['passive_finding']['source']['signal'], 'active_followup_response')

    def test_shadow_passive_finding_confidence_edges_and_invalid_inputs(self):
        """Should normalize shadow passive finding confidence and reject bad inputs."""

        medium = Browser._Browser__passive_shadow_metadata(
            url='https://example.com/index.php.old',
            code='not-a-status',
            method='POST',
            detection={
                'type': 'backup_copy',
                'confidence': 70,
                'base_url': 'https://example.com/index.php',
                'variant': '.old',
            },
        )
        low = Browser._Browser__passive_shadow_metadata(
            url='https://example.com/index.php.tmp',
            code='200',
            method='GET',
            detection={'type': 'backup_copy', 'confidence': 69},
        )

        self.assertEqual(medium['passive_finding']['confidence'], 'medium')
        self.assertEqual(medium['passive_finding']['source']['request_method'], 'POST')
        self.assertEqual(medium['passive_finding']['source']['status'], 'not-a-status')
        self.assertEqual(low['passive_finding']['confidence'], 'low')
        self.assertEqual(low['passive_finding']['source']['status'], 200)
        self.assertEqual(Browser._Browser__passive_shadow_metadata('', '200', 'GET', {'confidence': 90}), {})
        self.assertEqual(Browser._Browser__passive_shadow_metadata('https://example.com/x', '200', 'GET', None), {})

    def test_debug_request_uri_renders_shadow_marker(self):
        """Should render shadow findings as OK plus red Shadow marker."""

        cfg = SimpleNamespace(DEFAULT_SCAN='directories', scan='directories', debug=0, method='GET')
        debug = Debug(cfg)

        with patch('src.lib.browser.debug.tpl.line') as line_mock, \
                patch('src.lib.browser.debug.tpl.info') as info_mock, \
                patch('src.lib.browser.debug.sys.writels'):
            line_mock.side_effect = lambda **kwargs: kwargs.get('msg') or kwargs.get('key') or kwargs.get('url')
            debug.debug_request_uri(
                status='shadow',
                request_uri='https://example.com/index.php.bak',
                items_size=1,
                total_size=1,
                content_size='21B',
                response_code='200',
            )

        rendered_item = info_mock.call_args.kwargs['item']
        self.assertIn('OK', rendered_item)
        self.assertIn('Shadow', rendered_item)

    def test_shadow_helpers_cover_empty_similarity_size_and_header_iteration_paths(self):
        """Shadow helpers should cover empty signatures and header fallbacks."""

        class HeaderPairsWithoutContentType(object):
            """Iterable headers without Content-Type."""

            def __iter__(self):
                """Return unrelated header pairs."""

                return iter([('Server', 'nginx')])

        self.assertEqual(ShadowProbe.content_type(SimpleNamespace(headers=HeaderPairsWithoutContentType())), '')
        self.assertEqual(ShadowProbe.similarity_ratio({'normalized': ''}, {'normalized': 'body'}), 0.0)
        self.assertEqual(ShadowProbe.size_delta_ratio({'size': 0}, {'size': 10}), 1.0)

    def test_shadow_process_task_handles_match_without_callback(self):
        """ShadowProbe should count matches even when no match callback is configured."""

        base_body = b'base stable body line\n' * 5
        candidate_body = base_body + b'changed\n'
        base_response = HTTPResponse(status=200, body=base_body, headers={'Content-Type': 'text/html'})
        candidate_response = HTTPResponse(status=200, body=candidate_body, headers={'Content-Type': 'text/html'})
        base_signature = ShadowProbe.response_signature(base_response)
        probe = ShadowProbe(lambda _url: candidate_response, match_callback=None)

        getattr(probe, '_ShadowProbe__process_task')(
            (
                'https://example.com/index.php',
                base_signature,
                'https://example.com/index.php.bak',
                '.bak',
                1,
            )
        )

        self.assertEqual(probe.findings, 1)


if __name__ == '__main__':
    unittest.main()
