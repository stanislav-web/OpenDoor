# -*- coding: utf-8 -*-

"""
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Development: Stanislav WEB
"""

import re

from .provider import ResponsePluginProvider


class StacktraceResponsePlugin(ResponsePluginProvider):
    """Detect exposed stack traces and debug error details."""

    DESCRIPTION = 'Stacktrace (detect exposed debug stack traces and internal error details)'
    RESPONSE_INDEX = 'stacktrace'

    TEXTUAL_CONTENT_TYPES = (
        '',
        'text/html',
        'text/plain',
        'text/json',
        'application/json',
        'application/problem+json',
        'application/xml',
        'text/xml',
        'application/xhtml+xml',
    )
    BINARY_CONTENT_TYPES = (
        'application/octet-stream',
        'application/zip',
        'application/x-zip-compressed',
        'application/gzip',
        'application/x-gzip',
        'application/pdf',
        'image/',
        'audio/',
        'video/',
    )
    SIGNALS = (
        {
            'runtime': 'python',
            'signal': 'python-traceback',
            'confidence': 95,
            'pattern': re.compile(r'Traceback \(most recent call last\)', re.IGNORECASE),
        },
        {
            'runtime': 'node',
            'signal': 'node-anonymous-stack-frame',
            'confidence': 90,
            'pattern': re.compile(r'at\s+Object\.<anonymous>.+?\.js:\d+:\d+', re.IGNORECASE | re.DOTALL),
        },
        {
            'runtime': 'node',
            'signal': 'node-stack-frame',
            'confidence': 90,
            'pattern': re.compile(r'at\s+.+?\.js:\d+:\d+', re.IGNORECASE | re.DOTALL),
        },
        {
            'runtime': 'nestjs',
            'signal': 'nestjs-error',
            'confidence': 85,
            'pattern': re.compile(r'(NestJS|\[Nest\]).{0,240}(Error:|Exception)', re.IGNORECASE | re.DOTALL),
        },
        {
            'runtime': 'php',
            'signal': 'php-error',
            'confidence': 90,
            'pattern': re.compile(
                r'(?<![A-Za-z0-9_-])(?:<b>\s*)?(?:PHP\s+)?'
                r'(?:Fatal\s+error|Parse\s+error)(?:\s*</b>)?\s*:'
                r'|(?<![A-Za-z0-9_-])(?:<b>\s*)?(?:PHP\s+)?'
                r'(?:Warning|Notice|Deprecated)(?:\s*</b>)?\s*:\s*'
                r'(?=.{0,360}(?:'
                r'\b(?:Undefined\s+(?:index|variable|offset|array\s+key)|'
                r'Trying\s+to\s+(?:access|get|read)|'
                r'failed\s+to\s+open\s+stream|'
                r'include(?:_once)?\s*\(|require(?:_once)?\s*\(|'
                r'mysql|mysqli|PDO|expects\s+parameter|'
                r'Use\s+of\s+undefined\s+constant|Division\s+by\s+zero|'
                r'non-numeric\s+value)\b|'
                r'\bin\s+(?:<b>\s*)?[^<\s]+\.php(?:\s*</b>)?'
                r'\s+on\s+line\s+(?:<b>\s*)?\d+'
                r'))',
                re.IGNORECASE,
            ),
        },
        {
            'runtime': 'mysql',
            'signal': 'mysql-error',
            'confidence': 90,
            'pattern': re.compile(
                r'mysql_(connect|query|fetch_array|fetch_assoc|fetch_row|fetch_object|'
                r'close|select_db|real_connect|prepare|execute|'
                r'num_rows|affected_rows|error|errno|'
                r'pconnect|real_query|store_result|use_result)\s*\(.*?\)',
                re.IGNORECASE
            ),
        },
        {
            'runtime': 'database',
            'signal': 'database-connection-disclosure',
            'confidence': 85,
            'pattern': re.compile(
                r'(?<![A-Za-z0-9_-])Error\s*:\s*'
                r'Could\s+not\s+make\s+a\s+database\s+connection\s+using\s+'
                r'[^\s<>\"\']+@[^\s<>\"\']+',
                re.IGNORECASE,
            ),
        },
        {
            'runtime': 'pdo',
            'signal': 'pdo-exception',
            'confidence': 90,
            'pattern': re.compile(
                r'(?:PDOException|PDO::\w+)\s*[:\\(]?\s*(?:SQLSTATE\[[A-Z0-9]+\])?',
                re.IGNORECASE
            ),
        },
        {
            'runtime': 'java',
            'signal': 'java-exception',
            'confidence': 90,
            'pattern': re.compile(r'java\.lang\.[A-Za-z0-9_.$]+Exception', re.IGNORECASE),
        },
        {
            'runtime': 'sql',
            'signal': 'sqlstate-error',
            'confidence': 85,
            'pattern': re.compile(r'SQLSTATE\[[A-Z0-9]+\]', re.IGNORECASE),
        },
        {
            'runtime': 'oracle',
            'signal': 'oracle-error',
            'confidence': 85,
            'pattern': re.compile(r'\bORA-\d{5}\b', re.IGNORECASE),
        },
    )

    def __init__(self, _void):
        """
        ResponsePluginProvider constructor.

        :param void: unused plugin value
        """

        ResponsePluginProvider.__init__(self)

    def _is_textual_response(self):
        """
        Decide whether the response body is safe and useful for text scanning.

        :return: True when response content type can contain text stack traces
        :rtype: bool
        """

        content_type = self._extract_content_type()

        for item in self.BINARY_CONTENT_TYPES:
            if content_type.startswith(item):
                return False

        if content_type in self.TEXTUAL_CONTENT_TYPES:
            return True

        if content_type.endswith(('+json', '+xml')):
            return True

        return False

    @staticmethod
    def _build_detection(signal):
        """
        Build stacktrace detection metadata.

        :param dict signal: matched signal definition
        :return: stacktrace detection metadata
        :rtype: dict
        """

        return {
            'type': 'stacktrace',
            'runtime': signal.get('runtime'),
            'signal': signal.get('signal'),
            'confidence': int(signal.get('confidence', 0)),
        }

    def process(self, response):
        """
        Process data.

        :param response: HTTP response
        :return: str | None
        """

        if not hasattr(response, 'status'):
            return None

        super().process(response)

        if len(self._body) <= 0:
            return None

        if self._is_textual_response() is False:
            return None

        for signal in self.SIGNALS:
            if signal.get('pattern').search(self._body):
                setattr(response, 'opendoor_stacktrace_detection', self._build_detection(signal))
                return self.RESPONSE_INDEX

        return None
