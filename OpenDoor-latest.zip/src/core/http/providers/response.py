# -*- coding: utf-8 -*-

"""
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Development: Stanislav WEB
"""

import re
from src.core import filesystem
from src.core import helper


class ResponseProvider(object):
    """ ResponseProvider class"""

    HTTP_DBG_LEVEL = 3
    DEFAULT_WAF_STATUS = 'blocked'

    DEFAULT_WAF_BLOCK_STATUSES = [
        222, 401, 403, 405, 406, 409, 412, 415, 418, 423, 429, 430, 451,
        493, 494, 495, 496, 497, 499, 500, 501, 502, 503, 511,
        520, 521, 522, 523, 524, 525, 526, 527, 530
    ]

    DEFAULT_WAF_SIGNATURES = [
        {
            'name': 'Anubis',
            'confidence': 95,
            'strong_header_markers': [
                'techaro.lol-anubis-cookie-verification',
                'techaro.lol-anubis-auth=;',
            ],
            'header_markers': [
                'server: anubis',
            ],
            'strong_body_markers': [
                'making sure you\'re not a bot',
                'proof-of-work',
            ],
            'body_markers': [
                'anubis',
                'proof-of-work',
                'making sure you\'re not a bot',
            ],
        },
        {
            'name': 'Cloudflare',
            'confidence': 92,
            'strong_header_markers': [
                'cf-mitigated: challenge',
            ],
            'header_markers': [
                'cf-ray',
                'cf-chl-',
                'server: cloudflare',
                '__cf_bm',
                'cf-cache-status',
            ],
            'strong_body_markers': [
                'checking your browser before accessing',
                'cf-browser-verification',
                'attention required! | cloudflare',
            ],
            'body_markers': [
                'checking your browser',
                'checking your browser before accessing',
                'just a moment',
                'cf-browser-verification',
                'cloudflare ray id',
                'attention required! | cloudflare',
            ],
        },
        {
            'name': 'SEnginx',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'senginx-robot-mitigation',
            ],
            'body_markers': [
                'senginx-robot-mitigation',
                'senginx',
            ],
        },
        {
            'name': 'SiteLock TrueShield',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'sitelock incident id',
                'sitelock-site-verification',
                'sitelock_shield_logo',
            ],
            'body_markers': [
                'sitelock incident id',
                'sitelock-site-verification',
                'sitelock_shield_logo',
                'trueshield',
            ],
        },
        {
            'name': 'SonicWALL',
            'confidence': 82,
            'strong_header_markers': [
                'sonicwall',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'this request is blocked by the sonicwall',
                '#nsa_banner',
            ],
            'body_markers': [
                'sonicwall',
                '#shd',
                '#nsa_banner',
            ],
        },
        {
            'name': 'Sophos UTM Web Protection',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'powered by utm web protection',
            ],
            'body_markers': [
                'utm web protection',
                'sophos',
            ],
        },
        {
            'name': 'Stingray Application Firewall',
            'confidence': 81,
            'strong_header_markers': [],
            'header_markers': [
                'x-mapping-',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'stingray application firewall',
            ],
        },
        {
            'name': 'Sucuri',
            'confidence': 90,
            'strong_header_markers': [
                'x-sucuri-block',
                'x-sucuri-id',
            ],
            'header_markers': [
                'server: sucuri/cloudproxy',
            ],
            'strong_body_markers': [
                'access denied - sucuri website firewall',
            ],
            'body_markers': [
                'sucuri website firewall',
                'access denied - sucuri website firewall',
            ],
        },
        {
            'name': 'Akamai',
            'confidence': 88,
            'strong_header_markers': [
                'akamai-grn',
            ],
            'header_markers': [
                'x-akamai-',
                'server: akamai',
            ],
            'strong_body_markers': [
                'access denied reference #',
                'generated by akamai',
            ],
            'body_markers': [
                'akamai bot manager',
                'access denied reference #',
                'generated by akamai',
            ],
        },
        {
            'name': 'Imperva',
            'confidence': 88,
            'strong_header_markers': [
                'x-iinfo',
                'visid_incap',
                'incap_ses',
            ],
            'header_markers': [
                'x-cdn: imperva',
            ],
            'strong_body_markers': [
                'incapsula incident id',
                'powered by imperva',
            ],
            'body_markers': [
                'incident id',
                'request unsuccessful',
                'powered by imperva',
                'incapsula incident id',
            ],
        },
        {
            'name': 'DenyAll',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'condition intercepted',
            ],
            'body_markers': [
                'condition intercepted',
                'denyall',
            ],
        },
        {
            'name': 'Distil',
            'confidence': 85,
            'strong_header_markers': [
                'x-distil-cs',
            ],
            'header_markers': [
                'x-distil-',
                'distil_r_captcha',
            ],
            'strong_body_markers': [
                'distil networks',
            ],
            'body_markers': [
                'distil networks',
            ],
        },
        {
            'name': 'F5 BIG-IP ASM',
            'confidence': 84,
            'strong_header_markers': [
                'x-wa-info',
            ],
            'header_markers': [
                'bigip',
                'f5avr',
            ],
            'strong_body_markers': [
                'the requested url was rejected',
                'request rejected',
            ],
            'body_markers': [
                'the requested url was rejected',
                'support id',
                'request rejected',
            ],
        },
        {
            'name': 'AWS WAF',
            'confidence': 86,
            'strong_header_markers': [
                'x-amzn-requestid',
                'x-amz-cf-id',
            ],
            'header_markers': [
                'server: awselb/2.0',
                'x-amzn-errortype',
            ],
            'strong_body_markers': [
                'aws waf',
            ],
            'body_markers': [
                'request blocked',
                'generated by cloudfront',
                'aws waf',
            ],
        },
        {
            'name': 'Azure Front Door',
            'confidence': 85,
            'strong_header_markers': [
                'x-azure-ref',
                'x-azure-fdid',
            ],
            'header_markers': [
                'server: envoy',
                'via: 1.1 azure',
            ],
            'strong_body_markers': [
                'azure front door',
            ],
            'body_markers': [
                'azure front door',
                'request blocked',
                'the request has been blocked',
            ],
        },
        {
            'name': 'Fastly',
            'confidence': 82,
            'strong_header_markers': [
                'x-served-by: cache-',
                'x-cache: hit from fastly',
                'x-cache: miss from fastly',
            ],
            'header_markers': [
                'via: 1.1 varnish',
                'fastly-debug',
            ],
            'strong_body_markers': [
                'fastly error',
            ],
            'body_markers': [
                'fastly error',
                'guru mediation',
            ],
        },
        {
            'name': 'ModSecurity',
            'confidence': 80,
            'strong_header_markers': [
                'mod_security',
                'modsecurity',
            ],
            'header_markers': [
                'server: mod_security',
            ],
            'strong_body_markers': [
                'modsecurity action',
            ],
            'body_markers': [
                'mod_security',
                'modsecurity action',
                'not acceptable',
            ],
        },
        {
            'name': 'DataDome',
            'confidence': 87,
            'strong_header_markers': [
                'x-datadome',
                'datadome=',
            ],
            'header_markers': [
                'server: datadome',
            ],
            'strong_body_markers': [
                'captcha delivery network',
                'datadome',
            ],
            'body_markers': [
                'datadome',
                'please enable js',
                'captcha delivery network',
            ],
        },
        {
            'name': 'PerimeterX / HUMAN',
            'confidence': 85,
            'strong_header_markers': [
                '_pxhd',
                '_pxvid',
                'x-px',
            ],
            'header_markers': [
                'perimeterx',
                'humansecurity',
            ],
            'strong_body_markers': [
                'access to this page has been denied',
                'perimeterx',
            ],
            'body_markers': [
                'perimeterx',
                'human security',
                'access to this page has been denied',
            ],
        },
        {
            'name': 'Kasada',
            'confidence': 84,
            'strong_header_markers': [
                'x-kpsdk-',
                'x-kasada-',
            ],
            'header_markers': [
                'kpsdk',
            ],
            'strong_body_markers': [
                'kasada',
                'kpsdk',
            ],
            'body_markers': [
                'kasada',
                'kpsdk',
            ],
        },
        {
            'name': 'Barracuda',
            'confidence': 82,
            'strong_header_markers': [
                'barra_counter_session',
            ],
            'header_markers': [
                'barracuda',
            ],
            'strong_body_markers': [
                'barracuda web application firewall',
            ],
            'body_markers': [
                'barracuda web application firewall',
                'you have been blocked',
            ],
        },
        {
            'name': 'Radware',
            'confidence': 81,
            'strong_header_markers': [
                'x-sl-compstate',
            ],
            'header_markers': [
                'x-slid',
                'x-sl-compstate',
            ],
            'strong_body_markers': [
                'appwall',
                'radware',
            ],
            'body_markers': [
                'radware',
                'appwall',
            ],
        },

        {
            'name': 'FortiWeb',
            'confidence': 84,
            'strong_header_markers': [
                'fortiweb',
                'x-forti-cache',
            ],
            'header_markers': [
                'server: fortiweb',
                'fortiwafsid',
            ],
            'strong_body_markers': [
                'fortiweb web application firewall',
            ],
            'body_markers': [
                'fortiweb',
                'fortinet',
                'web page blocked',
            ],
        },
        {
            'name': 'Reblaze',
            'confidence': 83,
            'strong_header_markers': [
                'rbzid',
                'x-rbzid',
            ],
            'header_markers': [
                'reblaze',
                'x-rbz-',
            ],
            'strong_body_markers': [
                'reblaze secure web gateway',
            ],
            'body_markers': [
                'reblaze',
                'secure web gateway',
                'access denied',
            ],
        },
        {
            'name': 'NetScaler / Citrix WAF',
            'confidence': 85,
            'strong_header_markers': [
                'ns_af=',
                'citrix_ns_id',
            ],
            'header_markers': [
                'netscaler',
                'citrix',
                'x-citrix-application',
            ],
            'strong_body_markers': [
                'request denied by netscaler',
            ],
            'body_markers': [
                'netscaler',
                'citrix adc',
                'request denied',
            ],
        },
        {
            'name': 'AppTrana',
            'confidence': 82,
            'strong_header_markers': [
                'x-apptrana-',
            ],
            'header_markers': [
                'apptrana',
                'x-request-protection',
            ],
            'strong_body_markers': [
                'apptrana',
            ],
            'body_markers': [
                'apptrana',
                'request blocked',
                'website protection',
            ],
        },
        {
            'name': 'SW JS Challenge',
            'confidence': 90,
            'strong_header_markers': [],
            'header_markers': [
                'server: sw',
                'set-cookie: __js_p_=',
                        'content-type: text/html; charset=utf-8',
                'cache-control: no-cache',
            ],
            'strong_body_markers': [
                'meta name="robots" content="noindex, noarchive"',
                        'document.cookie = "__jua_="',
                'get_jhash(',
            ],
            'body_markers': [
                'gorizontal-vertikal',
                'ajaxload.info',
                'data:image/gif;base64',
                'construct_utm_uri',
            ],
        },
        {
            'name': 'CityHost Secure Page',
            'confidence': 88,
            'strong_header_markers': [
                'cityhost_secure_page=security_page_have_not_pass',
            ],
            'header_markers': [],
            'strong_body_markers': [
                'security_page_have_not_pass',
            ],
            'body_markers': [
                'cityhost secure page',
                'security page have not pass',
            ],
        },
        {
            'name': 'Huawei Cloud WAF',
            'confidence': 83,
            'strong_header_markers': [
                'x-hwwaf-',
                'hwwafsesid',
            ],
            'header_markers': [
                'huaweicloud',
                'huawei cloud waf',
            ],
            'strong_body_markers': [
                'huawei cloud waf',
            ],
            'body_markers': [
                'huawei cloud',
                'cloud waf',
                'request blocked',
            ],
        },
        {
            'name': 'DDoS-GUARD',
            'confidence': 83,
            'strong_header_markers': [
                'server: ddos-guard',
                'ddos-guard',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'ddos-guard',
            ],
            'body_markers': [
                'ddos-guard',
                'ddos protection',
            ],
        },
        {
            'name': 'Google Cloud Armor',
            'confidence': 83,
            'strong_header_markers': [],
            'header_markers': [
                'server: google frontend',
                'x-cloud-trace-context',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'google cloud armor',
                'denied by cloud armor',
            ],
            'body_markers': [
                'cloud armor',
                'google cloud armor',
                'denied by cloud armor',
            ],
        },
        {
            'name': 'SafeLine',
            'confidence': 84,
            'strong_header_markers': [
                'x-safeline',
                'safeline',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'blocked by safeline',
                'chaitin safeline',
                'safeline waf',
            ],
            'body_markers': [
                'safeline',
                'blocked by safeline',
                'chaitin safeline',
            ],
        },
        {
            'name': 'Teros / Citrix Application Firewall',
            'confidence': 81,
            'strong_header_markers': [],
            'header_markers': [
                'st8id',
                'st8_wat',
                'st8_wlf',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'teros',
            ],
        },
        {
            'name': 'TrafficShield',
            'confidence': 81,
            'strong_header_markers': [
                'f5-trafficshield',
                'asinfo=',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'trafficshield',
            ],
        },
        {
            'name': 'Tencent Cloud WAF',
            'confidence': 83,
            'strong_header_markers': [
                'x-qcloud-waf',
                'server: tencent cloud waf',
            ],
            'header_markers': [
                'qcloudwaf',
                'tencent cloud waf',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'tencent cloud waf',
                'qcloud waf',
            ],
            'body_markers': [
                'tencent cloud waf',
                'qcloud waf',
                'request has been blocked',
            ],
        },
        {
            'name': 'UrlScan',
            'confidence': 82,
            'strong_header_markers': [
                'rejected-by-urlscan',
            ],
            'header_markers': [],
            'strong_body_markers': [
                'rejected-by-urlscan',
            ],
            'body_markers': [
                'urlscan',
                'rejected-by-urlscan',
            ],
        },
        {
            'name': 'USP Secure Entry Server',
            'confidence': 81,
            'strong_header_markers': [],
            'header_markers': [
                'secure entry server',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'secure entry server',
            ],
        },
        {
            'name': 'Varnish WAF',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'request rejected by xvarnish-waf',
                'xvarnish-waf',
            ],
            'body_markers': [
                'xvarnish-waf',
            ],
        },
        {
            'name': 'Vercel WAF',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'vercel security checkpoint',
                'vercel waf',
                'request blocked by vercel',
            ],
            'body_markers': [
                'vercel security checkpoint',
                'vercel waf',
                'request blocked by vercel',
            ],
        },
        {
            'name': 'Wallarm',
            'confidence': 84,
            'strong_header_markers': [
                'x-wallarm',
                'wallarm',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'blocked by wallarm',
                'wallarm blocked',
            ],
            'body_markers': [
                'wallarm',
                'blocked by wallarm',
                'wallarm blocked',
            ],
        },
        {
            'name': 'Yundun',
            'confidence': 81,
            'strong_header_markers': [
                'yundun',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'yundun',
            ],
        },
        {
            'name': 'Zenedge',
            'confidence': 82,
            'strong_header_markers': [
                'zenedge',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'zenedge/assets/',
            ],
            'body_markers': [
                'zenedge/assets/',
                'zenedge',
            ],
        },
        {
            'name': 'Wordfence',
            'confidence': 83,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'generated by wordfence',
                'wordfence security',
                'this response was generated by wordfence',
            ],
            'body_markers': [
                'wordfence',
                'wordfence security',
                'generated by wordfence',
            ],
        },
        {
            'name': '360 WAF',
            'confidence': 84,
            'strong_header_markers': [
                'wzws-ray',
                'x-powered-by-360wzb',
            ],
            'header_markers': [
                'server: qianxin-waf',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'wzws-waf-cgi/',
                'wangshan.360.cn',
            ],
            'body_markers': [
                'your access has been intercepted because your links may threaten website security',
                'wzws-waf-cgi/',
                'wangshan.360.cn',
            ],
        },
        {
            'name': 'Airlock',
            'confidence': 82,
            'strong_header_markers': [
                'al-sess',
                'al-lb',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'server detected a syntax error in your request',
                'check your request and all parameters',
            ],
            'body_markers': [
                'airlock',
                'syntax error in your request',
            ],
        },
        {
            'name': 'Aliyun WAF',
            'confidence': 84,
            'strong_header_markers': [],
            'header_markers': [
                'aliyun',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'errors.aliyun.com',
                'your request has been blocked as it may cause potential threats',
            ],
            'body_markers': [
                'errors.aliyun.com',
                'potential threats to the server',
            ],
        },
        {
            'name': 'Anquanbao',
            'confidence': 84,
            'strong_header_markers': [
                'x-powered-by-anquanbao',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                '/aqb_cc/error/',
                'hidden_intercept_time',
            ],
            'body_markers': [
                'anquanbao',
                '/aqb_cc/error/',
                'hidden_intercept_time',
            ],
        },
        {
            'name': 'BinarySec',
            'confidence': 82,
            'strong_header_markers': [
                'x-binarysec-via',
                'x-binarysec-nocache',
            ],
            'header_markers': [
                'server: binarysec',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'binarysec',
            ],
        },
        {
            'name': 'BitNinja',
            'confidence': 84,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'security check by bitninja',
                'visitor anti-robot validation',
            ],
            'body_markers': [
                'bitninja',
                'your ip will be removed from bitninja',
                'you will be challenged by a recaptcha page',
            ],
        },
        {
            'name': 'Bluedon WAF',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [
                'server: bdwaf',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'bluedon web application firewall',
            ],
            'body_markers': [
                'bdwaf',
                'bluedon web application firewall',
            ],
        },
        {
            'name': 'BunkerWeb',
            'confidence': 88,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [],
            'body_markers': [
                'this website is protected with',
                'bunkerweb',
                'bunkerweb.io',
                'bunker-svg',
                'bunker-cls-',
                'bw_error_gradient_',
                'your client</div><p class="status-text"> forbidden',
                'bunkerweb</div><p class="status-text">working',
                'web server</div><p class="status-text"> working',
            ],
        },
        {
            'name': 'ChinaCache',
            'confidence': 81,
            'strong_header_markers': [
                'powered-by-chinacache',
            ],
            'header_markers': [
                'chinacache',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'chinacache',
            ],
        },
        {
            'name': 'aeSecure',
            'confidence': 82,
            'strong_header_markers': [
                'aesecure-code',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'aesecure_denied.png',
            ],
            'body_markers': [
                'aesecure_denied.png',
                'aesecure',
            ],
        },
        {
            'name': 'Armor Protection',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'this request has been blocked by website protection from armor',
            ],
            'body_markers': [
                'website protection from armor',
            ],
        },
        {
            'name': 'Baidu Yunjiasu',
            'confidence': 81,
            'strong_header_markers': [],
            'header_markers': [
                'server: yunjiasu-nginx',
                'yunjiasu-nginx',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'yunjiasu',
            ],
        },
        {
            'name': 'BlockDoS',
            'confidence': 81,
            'strong_header_markers': [],
            'header_markers': [
                'blockdos.net',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'blockdos.net',
            ],
        },
        {
            'name': 'Cisco ACE XML Gateway',
            'confidence': 81,
            'strong_header_markers': [],
            'header_markers': [
                'ace xml gateway',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'ace xml gateway',
            ],
        },
        {
            'name': 'Cloudbric',
            'confidence': 83,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'malicious code detected',
            ],
            'body_markers': [
                'cloudbric',
                'malicious code detected',
            ],
        },
        {
            'name': 'CrawlProtect',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'this site is protected by crawlprotect',
            ],
            'body_markers': [
                'crawlprotect',
            ],
        },
        {
            'name': 'Comodo WAF',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [
                'server: protected by comodo waf',
                'protected by comodo waf',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'protected by comodo waf',
            ],
            'body_markers': [
                'comodo waf',
            ],
        },
        {
            'name': 'DoSArrest',
            'confidence': 82,
            'strong_header_markers': [
                'x-dis-request-id',
            ],
            'header_markers': [
                'server: dosarrest',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'dosarrest',
            ],
        },
        {
            'name': 'DotDefender',
            'confidence': 84,
            'strong_header_markers': [
                'x-dotdefender-denied',
            ],
            'header_markers': [],
            'strong_body_markers': [
                'dotdefender blocked your request',
            ],
            'body_markers': [
                'dotdefender',
                'blocked your request',
            ],
        },
        {
            'name': 'GoDaddy Website Firewall',
            'confidence': 84,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'access denied - godaddy website firewall',
            ],
            'body_markers': [
                'godaddy website firewall',
            ],
        },
        {
            'name': 'GreyWizard',
            'confidence': 83,
            'strong_header_markers': [],
            'header_markers': [
                'server: greywizard',
                'greywizard',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'contact the website owner or grey wizard',
                "we\'ve detected attempted attack or non standard traffic",
            ],
            'body_markers': [
                'grey wizard',
                'attempted attack or non standard traffic',
            ],
        },
        {
            'name': 'IBM DataPower',
            'confidence': 80,
            'strong_header_markers': [],
            'header_markers': [
                'x-backside-transport',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'datapower',
            ],
        },
        {
            'name': 'Imunify360',
            'confidence': 83,
            'strong_header_markers': [],
            'header_markers': [
                'server: imunify360-webshield',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'protected by imunify360',
                'powered by imunify360',
            ],
            'body_markers': [
                'imunify360',
                'imunify360 preloader',
            ],
        },
        {
            'name': 'Instart DX',
            'confidence': 82,
            'strong_header_markers': [
                'x-instart-request-id',
                'x-instart-wl',
                'x-instart-cache',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'the requested url was rejected. please consult with your administrator.',
            ],
            'body_markers': [
                'instart',
                'the requested url was rejected',
            ],
        },
        {
            'name': 'NAXSI',
            'confidence': 84,
            'strong_header_markers': [
                'x-data-origin: naxsi/waf',
                'server: naxsi/waf',
            ],
            'header_markers': [
                'naxsi/waf',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'this request has been blocked by naxsi',
                'naxsi blocked information',
            ],
            'body_markers': [
                'naxsi',
                'this request has been blocked by naxsi',
            ],
        },
        {
            'name': 'NinjaFirewall',
            'confidence': 82,
            'strong_header_markers': [],
            'header_markers': [],
            'strong_body_markers': [
                'ninjafirewall: 403 forbidden',
                'for security reasons, it was blocked and logged',
            ],
            'body_markers': [
                'ninjafirewall',
                'blocked and logged',
            ],
        },
        {
            'name': 'Profense',
            'confidence': 81,
            'strong_header_markers': [
                'plbsid',
            ],
            'header_markers': [
                'server: profense',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'profense',
            ],
        },
        {
            'name': 'WatchGuard',
            'confidence': 81,
            'strong_header_markers': [
                'watchguard',
            ],
            'header_markers': [],
            'header_requires_blocked_status': True,
            'strong_body_markers': [],
            'body_markers': [
                'watchguard technologies',
            ],
        },
        {
            'name': 'WebKnight',
            'confidence': 82,
            'strong_header_markers': [
                'server: webknight/',
            ],
            'header_markers': [
                'webknight',
            ],
            'header_requires_blocked_status': True,
            'strong_body_markers': [
                'webknight application firewall alert',
            ],
            'body_markers': [
                'webknight',
            ],
        },
        {
            'name': 'NemesidaWAF',
            'confidence': 95,
            'status_markers': [222],
            'strong_header_markers': [
                'nemesidawaf-bt',
                'nemesidawaf-cc',
            ],
            'header_markers': [
                'x-request-id',
                'x-remote-ip',
            ],
            'strong_body_markers': [
                'suspicious activity detected',
                'access to the site is blocked',
                'подозрительная активность',
                'доступ запрещен',
            ],
            'body_markers': [
                '@nemesida.com',
                'nemesida-security.com',
                'nwaf@',
                'suspicious activity',
                'request id',
                'try again in 10 minutes',
            ],
        },
    ]

    DEFAULT_WAF_HEADER_MARKERS = [
        'techaro.lol-anubis-cookie-verification',
        'techaro.lol-anubis-auth=;',
        'cf-chl-',
        'cf-mitigated: challenge',
        'aesecure-code',
        'yunjiasu-nginx',
        'blockdos.net',
        'ace xml gateway',
        'sonicwall',
        'x-mapping-',
        'st8id',
        'st8_wat',
        'st8_wlf',
        'f5-trafficshield',
        'asinfo=',
        'rejected-by-urlscan',
        'secure entry server',
        'watchguard',
        'yundun',
        'zenedge',
        'x-sucuri-block',
        'x-sucuri-id',
        'x-distil-cs',
        'x-iinfo',
        'visid_incap',
        'incap_ses',
        'akamai-grn',
        'x-wa-info',
        'mod_security',
        'modsecurity',
        'x-datadome',
        '_pxhd',
        '_pxvid',
        'x-kpsdk-',
        'x-kasada-',
        'fortiweb',
        'x-forti-cache',
        'fortiwafsid',
        'rbzid',
        'x-rbzid',
        'x-rbz-',
        'ns_af=',
        'citrix_ns_id',
        'x-citrix-application',
        'x-apptrana-',
        'apptrana',
        'x-hwwaf-',
        'hwwafsesid',
        'server: ddos-guard',
        'ddos-guard',
        'server: google frontend',
        'x-cloud-trace-context',
        'x-safeline',
        'safeline',
        'x-qcloud-waf',
        'server: tencent cloud waf',
        'qcloudwaf',
        'tencent cloud waf',
        'x-wallarm',
        'wallarm',
        'wzws-ray',
        'x-powered-by-360wzb',
        'al-sess',
        'al-lb',
        'x-powered-by-anquanbao',
        'x-binarysec-via',
        'x-binarysec-nocache',
        'x-dis-request-id',
        'x-dotdefender-denied',
        'x-instart-request-id',
        'x-instart-wl',
        'x-instart-cache',
        'x-data-origin: naxsi/waf',
        'server: naxsi/waf',
        'naxsi/waf',
        'plbsid',
        'server: webknight/',
        'webknight',
        'nemesidawaf-bt',
        'nemesidawaf-cc',
        'nemesidawaf',
    ]

    DEFAULT_WAF_PASSIVE_HEADER_MARKERS_REQUIRE_BLOCKED_STATUS = [
        'aesecure-code',
        'yunjiasu-nginx',
        'server: yunjiasu-nginx',
        'blockdos.net',
        'ace xml gateway',
        'sonicwall',
        'x-mapping-',
        'st8id',
        'st8_wat',
        'st8_wlf',
        'f5-trafficshield',
        'asinfo=',
        'secure entry server',
        'watchguard',
        'yundun',
        'zenedge',
        'server: ddos-guard',
        'ddos-guard',
        'server: google frontend',
        'x-cloud-trace-context',
        'x-safeline',
        'safeline',
        'x-qcloud-waf',
        'server: tencent cloud waf',
        'qcloudwaf',
        'tencent cloud waf',
        'x-wallarm',
        'wallarm',
        'wzws-ray',
        'x-powered-by-360wzb',
        'al-sess',
        'al-lb',
        'x-powered-by-anquanbao',
        'x-binarysec-via',
        'x-binarysec-nocache',
        'x-dis-request-id',
        'x-instart-request-id',
        'x-instart-wl',
        'x-instart-cache',
        'x-data-origin: naxsi/waf',
        'server: naxsi/waf',
        'plbsid',
        'server: webknight/',
        'naxsi/waf',
        'server: naxsi',
        'webknight',
        'server: webknight',
    ]

    DEFAULT_WAF_BODY_MARKERS = [
        'anubis',
        'making sure you\'re not a bot',
        'proof-of-work',
        'checking your browser',
        'just a moment',
        'cf-browser-verification',
        'cloudflare ray id',
        'aesecure_denied.png',
        'website protection from armor',
        'yunjiasu',
        'blockdos.net',
        'ace xml gateway',
        'cloudbric',
        'malicious code detected',
        'crawlprotect',
        'condition intercepted',
        'senginx-robot-mitigation',
        'sitelock incident id',
        'sitelock-site-verification',
        'sitelock_shield_logo',
        'sonicwall',
        'powered by utm web protection',
        'teros',
        'trafficshield',
        'rejected-by-urlscan',
        'secure entry server',
        'xvarnish-waf',
        'watchguard technologies',
        'yundun',
        'zenedge/assets/',
        'sucuri website firewall',
        'akamai bot manager',
        'distil networks',
        'request blocked',
        'access denied reference #',
        'the requested url was rejected',
        'modsecurity',
        'datadome',
        'perimeterx',
        'human security',
        'kasada',
        'barracuda web application firewall',
        'appwall',
        'fortiweb',
        'fortinet',
        'reblaze',
        'secure web gateway',
        'netscaler',
        'citrix adc',
        'apptrana',
        'website protection',
        'huawei cloud waf',
        'cloud waf',
        'ddos-guard',
        'cloud armor',
        'google cloud armor',
        'denied by cloud armor',
        'safeline',
        'blocked by safeline',
        'tencent cloud waf',
        'qcloud waf',
        'vercel security checkpoint',
        'vercel waf',
        'wallarm',
        'blocked by wallarm',
        'wordfence security',
        'generated by wordfence',
        'wzws-waf-cgi/',
        'wangshan.360.cn',
        'server detected a syntax error in your request',
        'errors.aliyun.com',
        'hidden_intercept_time',
        'security check by bitninja',
        'visitor anti-robot validation',
        'bluedon web application firewall',
        'protected by comodo waf',
        'dotdefender blocked your request',
        'access denied - godaddy website firewall',
        'contact the website owner or grey wizard',
        'protected by imunify360',
        'this request has been blocked by naxsi',
        'naxsi blocked information',
        'ninjafirewall: 403 forbidden',
        'for security reasons, it was blocked and logged',
        'webknight application firewall alert',
        'suspicious activity detected',
        'access to the site is blocked',
        'suspicious activity',
        'подозрительная активность',
        'доступ запрещен',
    ]

    DEFAULT_HTTP_SUCCESS_STATUSES = [100, 101, 200, 201, 202, 203, 204, 205, 206, 207, 208]
    DEFAULT_HTTP_REDIRECT_STATUSES = [300, 301, 302, 303, 304, 307, 308]
    DEFAULT_HTTP_FAILED_STATUSES = [404, 406, 410, 408, 409, 411, 412, 424, 425, 429, 440, 477, 500, 501, 502, 503, 504, 507, 509, 511, 520, 522, 523]
    DEFAULT_SSL_CERT_REQUIRED_STATUSES = [423, 496, 525]
    DEFAULT_HTTP_FORBIDDEN_STATUSES = [222, 403, 405]
    DEFAULT_HTTP_AUTH_STATUSES = [401]
    DEFAULT_HTTP_BAD_REQUEST_STATUSES = [400, 415, 505, 508]

    def __init__(self, config):
        """
        Response instance
        :param src.lib.browser.config.Config config: configurations
        """

        self._cfg = config
        self._response_plugins = []
        self._last_waf_detection = None

    @property
    def waf_detection(self):
        """
        Return last detected WAF payload.

        :return: dict | None
        """

        return self._last_waf_detection

    @classmethod
    def _get_redirect_url(cls, url, response):
        """
        Get redirect url
        :param str url: redirect url
        :param urllib3.response.HTTPResponse response: response object
        :return: str
        """

        redirect_url = None
        location = response.get_redirect_location()

        if location is not False:
            matches = re.search(r"(?P<url>https?://[^\s]+)", location)
            if matches is not None:
                redirect_url = matches.group("url")
            else:
                urlp = helper.parse_url(url)
                location = location if True is location.startswith('/') else ''.join(('/', location))
                redirect_url = urlp.scheme + '://' + urlp.netloc + location

        return redirect_url

    def detect(self, request_url, response):
        """
        Detect response by status code
        :param str request_url: request url
        :param urllib3.response.HTTPResponse response: response object
        :raise Exception
        :return: str
        """

        status = None
        self._last_waf_detection = None

        try:
            setattr(response, 'opendoor_request_url', request_url)
        except (AttributeError, TypeError):
            pass

        if True is getattr(self._cfg, 'is_waf_detect', False):
            waf_detection = self.__detect_waf(response)
            if waf_detection is not None:
                self._last_waf_detection = waf_detection
                return self.DEFAULT_WAF_STATUS

        for _, resp_plugin in enumerate(self._response_plugins):
            status = resp_plugin.process(response)
            if None is not status:
                break

        if None is status:
            if response.status in self.DEFAULT_HTTP_SUCCESS_STATUSES:
                return 'success'
            elif response.status in self.DEFAULT_HTTP_FAILED_STATUSES:
                return 'failed'
            elif response.status in self.DEFAULT_SSL_CERT_REQUIRED_STATUSES:
                return 'certificate'
            elif response.status in self.DEFAULT_HTTP_REDIRECT_STATUSES:
                return self.__is_redirect(response, request_url)
            elif response.status in self.DEFAULT_HTTP_BAD_REQUEST_STATUSES:
                return 'bad'
            elif response.status in self.DEFAULT_HTTP_FORBIDDEN_STATUSES:
                return 'forbidden'
            elif response.status in self.DEFAULT_HTTP_AUTH_STATUSES:
                return 'auth'
            else:
                raise Exception('Unknown response status : `{0}`'.format(response.status))
        else:
            return status

    def handle(self, response, request_url, items_size, total_size, ignore_list):
        """
        Response handler
        :param urllib3.response.HTTPResponse response: response object
        :param str request_url: url from request
        :param int items_size: current items sizes
        :param int total_size: response object
        :param list ignore_list: ignore list
        :raise ResponseError
        :return: dict
        """


    @staticmethod
    def _get_content_size(response):
        """
        Get content size
        :param urllib3.response.HTTPResponse response: response object
        :return: str
        """

        size = 0

        try:
            size = 0 if not hasattr(response, 'headers') else int(response.headers['Content-Length'])
        except (KeyError, ValueError):
            size = len(response.data)
        finally:
            size = filesystem.human_size(size, 0)
        return size

    @staticmethod
    def __is_redirect(response, request_url):
        """
        Return redirect status
        :param str request_url: request url
        :param urllib3.response.HTTPResponse response: response object
        :return: str
        """

        location = response.get_redirect_location()
        if location is not False and location is not None:
            urlfrag = helper.parse_url(request_url)
            redirect_url = location.rstrip('/')

            redirectfrag = helper.parse_url(redirect_url)
            url = "{0}://{1}".format(urlfrag.scheme, urlfrag.netloc)
            if url == redirect_url \
                    or (0 < len(redirectfrag.query) and redirectfrag.query in urlfrag.path):
                return 'failed'
            return 'redirect'
        else:
            return 'failed'

    @staticmethod
    def __collect_header_blob(response):
        """
        Normalize response headers into a lower-case searchable blob.

        :param urllib3.response.HTTPResponse response: response object
        :return: str
        """

        try:
            headers = response.headers
        except AttributeError:
            headers = {}

        try:
            items = dict(headers).items()
        except Exception:
            try:
                items = headers.items()
            except Exception:
                items = []

        return ' '.join([
            '{0}: {1}'.format(key, value)
            for key, value in items
        ]).lower()

    @staticmethod
    def __collect_body_blob(response):
        """
        Normalize response body into a lower-case searchable blob.

        :param urllib3.response.HTTPResponse response: response object
        :return: str
        """

        try:
            return helper.decode(response.data).lower()
        except (AttributeError, TypeError, UnicodeDecodeError):
            return ''

    @staticmethod
    def __match_markers(source_name, blob, markers):
        """
        Collect matching markers from a normalized blob.

        :param str source_name:
        :param str blob:
        :param list markers:
        :return: list[str]
        """

        signals = []
        for marker in markers:
            if marker in blob:
                signals.append('{0}:{1}'.format(source_name, marker))
        return signals

    @classmethod
    def __looks_like_blocked_status(cls, response):
        """
        Return True when response status looks like a block/challenge flow.

        :param urllib3.response.HTTPResponse response: response object
        :return: bool
        """

        try:
            return int(response.status) in cls.DEFAULT_WAF_BLOCK_STATUSES
        except (AttributeError, TypeError, ValueError):
            return False

    @staticmethod
    def __score_detection(strong_header_signals, header_signals, strong_body_signals, body_signals):
        """
        Score WAF signals with stronger priority for header and strong body markers.

        :param list strong_header_signals:
        :param list header_signals:
        :param list strong_body_signals:
        :param list body_signals:
        :return: int
        """

        return (
            (len(strong_header_signals) * 60) +
            (len(header_signals) * 35) +
            (len(strong_body_signals) * 30) +
            (len(body_signals) * 20)
        )

    @staticmethod
    def __match_status_markers(response, markers):
        """
        Match explicit WAF status-code fingerprints.

        Some WAF deployments use non-standard status codes for internal block
        pages. NemesidaWAF custom pages commonly map 403 blocks to 222.

        :param urllib3.response.HTTPResponse response: response object
        :param list markers: status codes treated as vendor fingerprints
        :return: list[str]
        """

        try:
            status = int(response.status)
        except (AttributeError, TypeError, ValueError):
            return []

        result = []
        for marker in markers:
            try:
                marker_status = int(marker)
            except (TypeError, ValueError):
                continue

            if status == marker_status:
                result.append('status:{0}'.format(marker_status))

        return result

    @staticmethod
    def __dedupe_signals(signals):
        """
        Preserve signal order while removing duplicate evidence markers.

        :param list signals:
        :return: list[str]
        """

        result = []
        seen = set()
        for signal in signals:
            if signal in seen:
                continue
            seen.add(signal)
            result.append(signal)
        return result

    def __build_waf_result(self, signature, signals):
        """
        Build normalized WAF detection payload.

        :param dict signature:
        :param list signals:
        :return: dict
        """

        return {
            'name': signature.get('name'),
            'confidence': int(signature.get('confidence', 80)),
            'signals': self.__dedupe_signals(signals)[:5],
        }

    @classmethod
    def __filter_passive_header_signals(cls, signals):
        """Drop passive WAF presence headers unless the status is block-like.

        Header matchers can return either exact marker values or expanded
        strings such as ``header:server: webknight/4.6``. Use exact and
        embedded-marker checks so passive gateway/WAF presence does not turn a
        normal 200 response into ``blocked`` through vendor scoring or the
        Generic WAF fallback.
        """
        filtered = []

        for signal in signals:
            normalized = str(signal or '').lower().strip()
            if normalized.startswith('header:'):
                normalized = normalized[len('header:'):].strip()

            is_passive = False
            for marker in cls.DEFAULT_WAF_PASSIVE_HEADER_MARKERS_REQUIRE_BLOCKED_STATUS:
                passive_marker = str(marker or '').lower().strip()
                if not passive_marker:
                    continue

                if normalized == passive_marker or passive_marker in normalized:
                    is_passive = True
                    break

            if not is_passive:
                filtered.append(signal)

        return filtered

    @staticmethod
    def __cloudflare_has_active_block_signal(
            response,
            strong_header_signals,
            header_signals,
            strong_body_signals,
            body_signals,
    ):
        """
        Return True when Cloudflare signals describe an active block/challenge.

        Passive CDN headers such as cf-ray or server: cloudflare are not enough
        to mark an otherwise normal response as blocked.

        :param urllib3.response.HTTPResponse response: response object
        :param list strong_header_signals:
        :param list header_signals:
        :param list strong_body_signals:
        :param list body_signals:
        :return: bool
        """

        if len(strong_header_signals) > 0 or len(strong_body_signals) > 0:
            return True

        if 'header:cf-chl-' in header_signals:
            return True

        active_body_signals = [
            signal for signal in body_signals
            if signal not in ['body:cloudflare ray id']
        ]
        if len(active_body_signals) > 0:
            return True

        try:
            return int(response.status) == 429 and len(header_signals) > 0
        except (AttributeError, TypeError, ValueError):
            return False

    @staticmethod
    def __sw_js_challenge_has_active_signal(header_blob, body_blob):
        """
        Return True only for the active SW __js_p_ JavaScript challenge page.

        Passive `server: sw` or a leftover `__js_p_` cookie must not be enough
        to mark a normal 200 response as blocked.

        :param str header_blob:
        :param str body_blob:
        :return: bool
        """

        header_blob = str(header_blob or '')
        body_blob = str(body_blob or '')

        if '__js_p_=' not in header_blob:
            return False

        if 'server: sw' not in header_blob:
            return False

        strong_body_markers = [
            'meta name="robots" content="noindex, noarchive"',
            'document.cookie = "__jhash_="',
            'document.cookie = "__jua_="',
            'get_jhash(',
        ]
        body_markers = [
            'gorizontal-vertikal',
            'ajaxload.info',
            'data:image/gif;base64',
            'construct_utm_uri',
            'window.location.href',
        ]

        strong_hits = sum(1 for marker in strong_body_markers if marker in body_blob)
        body_hits = sum(1 for marker in body_markers if marker in body_blob)

        return strong_hits >= 2 and body_hits >= 2

    def __detect_waf(self, response):
        """
        Detect known WAF or anti-bot vendors.

        Detection rules:
        - any strong header marker is enough
        - two strong body markers are enough even on 200 OK
        - one strong body marker plus another body/header marker is enough
        - header markers are enough when score is high enough
        - body-only detections without strong markers still require blocked-like status
        - generic fallback is stricter than vendor-specific matching

        :param urllib3.response.HTTPResponse response: response object
        :return: dict | None
        """

        header_blob = self.__collect_header_blob(response)
        body_blob = self.__collect_body_blob(response)
        blocked_like_status = self.__looks_like_blocked_status(response)

        for signature in self.DEFAULT_WAF_SIGNATURES:
            status_signals = self.__match_status_markers(
                response,
                signature.get('status_markers', [])
            )
            strong_header_signals = self.__match_markers(
                'header',
                header_blob,
                signature.get('strong_header_markers', [])
            )
            header_signals = self.__match_markers(
                'header',
                header_blob,
                signature.get('header_markers', [])
            )
            strong_body_signals = self.__match_markers(
                'body',
                body_blob,
                signature.get('strong_body_markers', [])
            )
            body_signals = self.__match_markers(
                'body',
                body_blob,
                signature.get('body_markers', [])
            )

            if blocked_like_status is False:
                strong_header_signals = self.__filter_passive_header_signals(strong_header_signals)
                header_signals = self.__filter_passive_header_signals(header_signals)

            if blocked_like_status is False and signature.get('header_requires_blocked_status') is True:
                strong_header_signals = []
                header_signals = []

            if signature.get('name') == 'SW JS Challenge' and not self.__sw_js_challenge_has_active_signal(
                    header_blob,
                    body_blob
            ):
                continue

            if signature.get('name') == 'Cloudflare' and not self.__cloudflare_has_active_block_signal(
                    response,
                    strong_header_signals,
                    header_signals,
                    strong_body_signals,
                    body_signals
            ):
                continue

            if len(status_signals) > 0:
                return self.__build_waf_result(
                    signature,
                    status_signals + strong_header_signals + header_signals + strong_body_signals + body_signals
                )

            if len(strong_header_signals) > 0:
                return self.__build_waf_result(
                    signature,
                    strong_header_signals + header_signals + strong_body_signals + body_signals
                )

            if len(strong_body_signals) >= 1:
                return self.__build_waf_result(
                    signature,
                    strong_body_signals + header_signals + body_signals
                )

            score = self.__score_detection(
                strong_header_signals,
                header_signals,
                strong_body_signals,
                body_signals
            )

            if len(header_signals) > 0 and score >= 35:
                return self.__build_waf_result(
                    signature,
                    header_signals + strong_body_signals + body_signals
                )

            if blocked_like_status is True and len(body_signals) >= 2 and score >= 40:
                return self.__build_waf_result(
                    signature,
                    strong_body_signals + body_signals
                )

            if blocked_like_status is True and len(header_signals) >= 1 and len(body_signals) >= 1:
                return self.__build_waf_result(
                    signature,
                    header_signals + strong_body_signals + body_signals
                )

        generic_header_markers = self.DEFAULT_WAF_HEADER_MARKERS
        if blocked_like_status is False:
            generic_header_markers = [
                marker for marker in generic_header_markers
                if marker not in self.DEFAULT_WAF_PASSIVE_HEADER_MARKERS_REQUIRE_BLOCKED_STATUS
            ]

        generic_header_signals = self.__match_markers('header', header_blob, generic_header_markers)
        generic_body_signals = self.__match_markers('body', body_blob, self.DEFAULT_WAF_BODY_MARKERS)

        if blocked_like_status is False:
            generic_header_signals = self.__filter_passive_header_signals(generic_header_signals)

        if len(generic_header_signals) > 0:
            return {
                'name': 'Generic WAF',
                'confidence': 80,
                'signals': (generic_header_signals + generic_body_signals)[:5],
            }

        if blocked_like_status is True and len(generic_body_signals) >= 2:
            return {
                'name': 'Generic WAF',
                'confidence': 78,
                'signals': generic_body_signals[:5],
            }

        return None
